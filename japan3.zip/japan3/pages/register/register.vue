<!-- 注册 -->
<template>
	<view style="display: flex;
	flex-direction: column;
	align-items: center;
	padding-top: 2vh;">
		<view style="display: flex;flex-direction: column;align-items: center;justify-content: center;width: 75%;">
			<image mode="aspectFit" src="/static/chuanggai/logo1.png" :style="$util.calcImageSize(240)"></image>
			<view style="height: 30px; text-align: center;font-size: 18px;font-weight: bold;">機関プレミアムシステム</view>
			<u--input shape="circle" :placeholder="$lang.USER_NAME" prefixIcon="account-fill" color='#121212'
				placeholderStyle="font-size: 13px;color: #999"
				prefixIconStyle="font-size: 28px;color: #999;margin-left:9px;" v-model="value1" type="number"
				maxlength="11" style="margin-top:20px;background-color: rgba(255,255,255,0.75);"></u--input>
			<view class="item">

				<!-- <view class="ipt flex flex-b" style="margin-top: 20px;width: 60%;margin-left: 60px;border: 2px #e8e6ec solid;">
		    <u-input :placeholder="$t('index.E-mail')" prefixIcon="/static/code.png" border="none" v-model="email" placeholderStyle="margin-left:-1px;"prefixIconStyle="font-size: 28px;color: #999;margin-left:5px;width:30px;height:30px" >
			<template slot="suffix" >
			<u-code ref="uCode" @change="codeChange"  seconds="20" :changeText="$t('index.60mhcxhq')"></u-code>
		<u-button @tap="getCode" :text="tips"  type="success" size="mini">{{$t('index.yzm')}}</u-button>
										</template>
									</u-input>
								</view>
							</view> -->

				<!-- <u--input shape="circle" :placeholder="$t('index.E-mail')" prefixIcon="/static/code.png" color='#121212'
					placeholderStyle="font-size: 13px;color: #999"
					prefixIconStyle="font-size: 28px;color: #999;margin-left:9px;width:30px;height:25px"
					v-model="email" style="margin-top:20px;background-color: rgba(255,255,255,0.75);">
					<template slot="suffix">
						<u-code ref="uCode" @change="codeChange" seconds="20"
							:changeText="$t('index.60mhcxhq')"></u-code>
						<u-button @tap="getCode" :text="tips" type="success" size="mini">{{$t('index.yzm')}}</u-button>
					</template></u--input> -->

				<!-- <u--input shape="circle" :placeholder="$t('index.yxyzm')" prefixIcon="/static/code.png" color='#121212'
					placeholderStyle="font-size: 13px;color: #999"
					prefixIconStyle="font-size: 28px;color: #999;margin-left:9px;width:30px;height:25px"
					v-model="smscode" type="password"
					style="margin-top:20px;background-color: rgba(255,255,255,0.75);"></u--input> -->


				<u--input shape="circle" :placeholder="$lang.PASSWORD2" prefixIcon="lock-fill" color='#121212'
					placeholderStyle="font-size: 13px;color: #999"
					prefixIconStyle="font-size: 28px;color: #999;margin-left:10px" v-model="value2" type="password"
					style="margin-top:20px;background-color: rgba(255,255,255,0.75);"></u--input>

				<u--input shape="circle" :placeholder="$lang.PASSWORD_CONFIRM" prefixIcon="lock-fill" color='#121212'
					placeholderStyle="font-size: 13px;color: #999"
					prefixIconStyle="font-size: 28px;color: #909399;margin-left:10px" v-model="value3" type="password"
					style="margin-top:20px;background-color: rgba(255,255,255,0.75);"></u--input>

				<u--input shape="circle" :placeholder="$lang.INVITATION_CODE" prefixIcon="attach" color='#121212'
					placeholderStyle="font-size: 13px;color: #999"
					prefixIconStyle="font-size: 28px;color: #999;margin-left:10px" v-model="code"
					style="margin-top:20px;background-color: rgba(255,255,255,0.75);"></u--input>

				<!-- <view style="width: 60%;margin-top:8px;line-height: 20px;height: 20px;position: relative;">
				<view
					style="font-size: 16px;color: #fff;position: absolute;top: 50%;transform: translateY(-50%);right: 0;"
					@tap="signIn()">
					{{$lang.SIGN_IN}}
					<u-icon name="arrow-right" color="#fff" size="14" :bold="true"
						style="display: inline-block;"></u-icon>
				</view>
			</view> -->

				<view class="common_btn" style="width:93%;margin-top: 15px; background-color: #ff0000;font-size: 15px;"
					@click="gain_register">{{$lang.SIGN_UP}}</view>
				<view style="width: 90%;margin-top:8px;line-height: 30px;height: 60px;position: relative;">
					<view
						style="font-size: 20px;color: #ff0000;position: absolute;top: 50%;transform: translateY(-50%);right: 0; margin-right: 85px;"
						@tap="signIn()">
						{{$lang.SIGN_IN}}
						<u-icon name="arrow-right" color="#ff0000" size="14" :bold="true"
							style="display: inline-block; margin-left: 10px;"></u-icon>
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				nick_name: '',
				value1: '',
				value2: '',
				value3: '',
				email: "",
				code: '',
				smscode: "",
				smscode2: ""
			};
		},
		methods: {
			// 跳转到登录
			signIn() {
				uni.navigateTo({
					url: '/pages/signin/signin'
				});
			},
			codeChange(text) {
				this.tips = text;
			},
			async getCode() {
				if (!this.email) {
					uni.$u.toast(this.$t('index.qsryx'));
					return
				}
				if (this.$refs.uCode.canGetCode) {
					// 模拟向后端请求验证码
					uni.showLoading({
						title: this.$t('index.hqyzm')
					})
					let list = await this.$http.post('api/app/sendSmsCode', {
						mobile: this.email,

					})
					uni.hideLoading();
					// 这里此提示会被this.start()方法中的提示覆盖
					uni.$u.toast(this.$t('index.yzmyfs'));
					// 通知验证码组件内部开始倒计时
					this.$refs.uCode.start();

				} else {
					// uni.$u.toast('倒计时结束后再发送');
				}
			},
			//注册
			async gain_register() {
				if (this.value1 == '') {
					uni.$u.toast('電話番号を入力してください。');
				} else if (this.value2 == '') {
					uni.$u.toast('パスワードを入力してください');
				} else if (this.value3 == '') {
					uni.$u.toast('パスワードを入力してください');
				} else if (this.value3 != this.value2) {
					uni.$u.toast('2 つのパスワードが一致しません');
				} else if (!this.code) {
					uni.$u.toast('認証番号を入力してください');
				} else {
					let list = await this.$http.post('api/app/register', {
						mobile: this.value1,
						password: this.value2,
						confirmpass: this.value3,
						invite: this.code,
						code: 123456,
						email: this.email,
						code: this.smscode,
					})
					// console.log(list.data.code);
					if (list.data.code == 0) {
						uni.$u.toast('登録が完了しました。 ログインしてください。');
						setTimeout(() => {
							uni.navigateTo({
								url: '/pages/signin/signin'
							});
						}, 1000)
					} else {
						uni.$u.toast(list.data.message);
					}
				}
			},

		},

	}
</script>

<style lang="scss">

</style>