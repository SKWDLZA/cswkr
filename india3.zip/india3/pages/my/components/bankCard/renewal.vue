<!-- 绑定银行卡 -->
<template>
	<view class="page">
		<view>
			<view class="header flex flex-b" style="background: linear-gradient(148deg,#ffeed4,#aaaaff);">
				<view class="icon jiantou" @click="$u.route({type:'navigateBack'});"></view>
				<view class="header-center flex-1">Bank Account Details</view><!---->
				<!-- <view class="icon ss" @click="$u.route({url:'/pages/searchFor/searchFor'});"></view> -->
			</view>
		</view>
		<view class="bankInfo-box">
			<view class="bank-name">
				<view class="list flex flex-b">
					<input placeholder="Enter your full name" v-model="value" class="flex-2"> </input>
				</view>
			</view>
			<view class="bank-name">
				<view class="list flex flex-b">
					<input placeholder="Enter your bank name" v-model="value2" class="flex-2"> </input>
				</view>
			</view>
			<view class="bank-name">
				<view class="list flex flex-b">
					<input placeholder="Enter your bank account number" v-model="value4" class="flex-2"> </input>
				</view>
			</view>
			<view class="bank-name">
				<view class="list flex flex-b">
					<input placeholder="Enter your IFSC code" v-model="value3" class="flex-2"> </input>
				</view>
			</view>
			
		</view>

		<view class="purchase" @click="replaceBank()">Submit</view>
		<view class="point-out">
			<view>
				<text>Standard Disclaimers:</text>
				</view>
			<view>
In order to ensure the absolute security of your account and the accuracy of transaction processes, it is imperative that you provide your genuine and detailed information when filling out your banking details. We emphasize the seriousness of this matter, as any inaccuracies in the provided information may lead to severe financial losses, for which our company holds no responsibility. All withdrawals will strictly be processed to the account held in the name of the account holder, ensuring the safety and compliance of transactions.</view>
<view style="margin-top: 10px;">
Please treat this step with utmost seriousness, as errors in filling out this information may result in extremely serious consequences. Our company disclaims any responsibility for losses incurred due to inaccuracies in the information provided. To safeguard your interests, we strongly advise a thorough review and confirmation before submitting your banking details. If you have any doubts or concerns, please contact our customer service team promptly for assistance.
This measure is implemented to provide the utmost security for your financial well-being, and we appreciate your understanding and cooperation. Rest assured, we are committed to ensuring the highest level of protection for your funds and personal information.</view>
		</view>



	</view>
</template>

<script>
	export default {
		data() {
			return {

				value: '',
				value2: '',
				value3: '',
				value4: ''

			};
		},
		methods: {
			home() {
				uni.switchTab({
					url: '/pages/my/my'
				});
			},
			//跟换银行卡
			async replaceBank() {
				let list = await this.$http.post('api/user/bindBankCard', {
					//value2和value3反了
					//value2应该是bank_name  
					//value3应该是bank_sub_name
					realname: this.value,
					bank_name: this.value2,
					bank_sub_name: this.value3,
					card_sn: this.value4,
				})
				if (list.data.code == 0) {
					uni.$u.toast('Your bank card information has been successfully submitted.');
					setTimeout(() => {
						uni.switchTab({
							url: '/pages/my/my'
						});
					}, 1000)
				} else {
					uni.$u.toast(list.data.message);
				}

			},
		},
		// mounted() {
		// 	this.replaceBank()
		// },
	}
</script>

<style lang="scss">
	uni-view, uni-text {
	    box-sizing: border-box;
	}
	.page {
	    padding: 50px 0 0;
	}
	.header{
	    height: 55px;
	    background: #fff;
	    box-shadow: 0px 1px 4px 0px rgba(0,0,0,.1);
	    padding: 0 16px;
	    width: 100vw;
	    position: fixed;
	    top: 0;
	    left: 0;
	    z-index: 999;
	
		.header-left {
		    position: absolute;
		    top: 18px;
		    left: 16px;
		    width: 10px;
		    height: 18px;
		}
		.header-center {
		    font-size: 16px;
		    font-weight: 700;
		    color: #333;
		    text-align: center;
		}
	}
	.bankInfo-box {
	    padding: 16px;
	    background: #fff;
	}
	.list{
	    padding: 0 22px;
	    margin-bottom: 16px;
	    height: 48px;
	    background: #f6f6f6;
	    border-radius: 24px;
	}
	.college-bg {
		padding: 20rpx;
		height: 80rpx;
		background-color: #eb333b;
		// background-image: linear-gradient(to right, #1a73e8, #014b8d);
		display: flex;
		justify-content: space-between;
		align-items: center;
		text-align: center;

		image {
			width: 20rpx;
			height: 40rpx;
		}

		.college-text {

			color: #fff;
			font-weight: 800;
			font-size: 36rpx;
		}

	}

	.college-content {
		margin: 30rpx 0;
		padding: 10rpx 30rpx;
		// background: #f5f5f5;

		.bank-name {
			padding: 0 22px;
			margin-bottom: 16px;
			height: 48px;
			background: #f6f6f6;
			border-radius: 24px;
			view {
				width: 22%;
			}

			input {
				margin-left: 60rpx;
				font-weight: 400;
				font-size: 28rpx;
			}
		}

		.xian {
			height: 2rpx;
			width: 100%;
			background: #fff;
		}
	}

	.purchase {
		// background-image: linear-gradient(to right, #1a73e8, #014b8d);
		background-color: #eb333b;
		margin: 60rpx 30rpx;
		border-radius: 24px;
		padding: 20rpx 0;
		text-align: center;
		color: #fff;
		// font-weight: 600;
		font-size: 28rpx;
	}
	.point-out {
		margin: 40rpx;
		color: #666;
		font-size: 28rpx;
	
		text {
			color: #cb1a1e;
			font-size: 40rpx;
		}
		
	}
</style>