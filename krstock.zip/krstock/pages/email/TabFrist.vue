<template>
	<view>
		<view style="border-radius: 10px;background: #fff;margin: 10px;box-shadow: rgba(0, 0, 0, 0.15) 1.95px 1.95px 2.6px;">
			<!-- <view>This is Email</view> -->
			
			<view style="width: 100%;display:flex;flex-direction: column;justify-items: center;align-items: center;padding: 23vh 0;" v-if="!searchList">
				<u-image src="/static/email.png" width="411px" mode="aspectFit"></u-image>
				<view class="text-center" style="color: #6D6D6D;font-size: 14px;padding-top:30px">메시지 없음</view>
			</view>
		</view>	
	</view>
</template>

<script>
	export default {
		name:'TabFrist',
		components: {},
		props: {},
		data() {
			return {
				searchList: '',
			};
		},
		onReachBottom() {
			this.status = 'loading';
		},
		onLoad() {
			
		},
		methods: {
			home() {
				uni.switchTab({
					url: '/pages/index/index'
				});
			},
		}
	}
</script>

<style lang="scss">

	view,
	text {
		box-sizing: border-box;
	}
	.page{
		min-height: 100vh;
		background-color: #F3F4F8;
	}	

</style>