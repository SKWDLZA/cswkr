<!-- 실시간 이체 -->
<template>
	<view :style="$util.setPageBG('bg_common')">
		<CustomHeader :title="$lang.WITHDRAW" @action="handleBack()"></CustomHeader>
		<view class="withdraw_info"
			style="display: flex;flex-direction: column; align-items: center;justify-content: space-around;">
			<view style="display: flex;align-items: center;padding:4px 20px;margin-top: 10px;">
				<image src="/static/kr.png" mode="aspectFit" :style="$util.calcImageSize(30)"
					style="border-radius: 100px;background-color:#bdd8ffa1;padding:6px;"></image>
				<view style="padding-left: 10px;color:#FFFFFF;">KRW</view>
				<view style="width: 240px;"></view>
			</view>
			<view style="font-size: 64rpx;font-weight: 700;color:#FFFFFF;">
				{{$util.formatNumber(userInfo.money)}}<text style="padding:0 4px">원</text>
			</view>
			<view style="color:#f5f5f5;margin-bottom: 10px;">{{$lang.TIP_AMOUNT_AVAIL}}</view>
		</view>

		<view style="padding:4px 10px;display: flex;flex-wrap: nowrap;align-items: center;margin-left: 10px;">
			<image mode="aspectFit" src="/static/stock_all.png" :style="$util.setImageSize(6,36)"></image>
			<view style="padding-left: 10px; font-size:36rpx;" :style="{color:$util.THEME.TITLE}">
				{{ $lang.WITHDRAW}}
			</view>
		</view>

		<view class="common_block" style="padding:20px;margin-top: 10px;margin-bottom: 20px;">
			<!-- <view style="text-align:center;font-size: 16px;" :style="{color:$util.THEME.TIP}"> 실시간이체 </view> -->

			<view class="common_input_wrapper" style="background-color: rgba(198, 198, 198,0.2);border: 1px solid #C6C6C6;">
				<!-- <image mode="aspectFit" src='/static/money.png' :style="$util.calcImageSize(20)">
				</image> -->
				<input v-model="amount" :placeholder="$lang.TIP_AMOUNT_WITHDRAW" type="text" :placeholder-style="$util.setPlaceholder()" @input="shuru" style="flex: auto;margin-left: 20px;"></input>
				
				
				<!-- <view @click="handleAllAmount(userInfo.money)" class="btn_small">{{$lang.TIP_AMOUNT_ALL}}</view> -->
			</view>

			<view class="common_input_wrapper" style="background-color: rgba(198, 198, 198,0.2);border: 1px solid #C6C6C6;">
				<!-- <image mode="aspectFit" src='/static/password.png' :style="$util.calcImageSize(20)">
				</image> -->
				<input v-model="password" :placeholder="$lang.TIP_WITHDRAW_PWD" type="password" :placeholder-style="$util.setPlaceholder()" style="margin-left: 20px;"></input>
			</view>
		</view>

		<view class="common_btn btn_primary" style="width: 90%;margin:auto;" @click="handleWithdraw()">
			출금신청</view>
		<view style="margin:10px; padding: 20px;" :style="{color:$util.THEME.TIP}">
			<block v-for="(item,index) in $util.TIP_WITHDRAW_CONDITION" :key="index">
				<view style="padding-bottom: 6px;" :style="{color:index==5?'red':$util.THEME.TIP}">
					{{item}}</view>
			</block>
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components: {
			CustomHeader,
		},
		data() {
			return {
				amount: '',
				number:"",
				password: '',
				userInfo: {},
			};
		},
		onShow() {
			this.getInfo()
		},
		methods: {
			shuru(item){
				console.log();
				this.number = parseFloat(this.amount.replace(/,/g, ''));
				this.amount = this.number.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
			},
			handleBack() {
				uni.navigateBack({
					delta: 1
				});
			},
			handleAllAmount(val) {
				this.number = val;
				this.amount = val.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")
			},
			async handleWithdraw() {
				uni.showLoading({
					title: this.$lang.TIP_WITHDRAWING,
					mask: true, // 显示透明蒙层，防止触摸穿透
				});
				// this.number=setInterval(this.number);
				console.log(9999,this.number);

				if(this.number<=0){
					uni.hideLoading();
					uni.$u.toast('금액을 잘못 입력했습니다.');
					return;
				}
				const result = await this.$http.post(this.$http.API_URL.APP_WITHDRAW, {
					type: 1,
					total: this.number,
					pay_pass: this.password,
					remakes: "",
				})
				if (result.data.code == 0) {
					uni.$u.toast(result.data.message);
					setTimeout(() => {
						uni.switchTab({
							url: this.$util.PAGE_URL.ACCOUNT_CENTER
						});
						uni.hideLoading();
					}, 500)
				} else {
					uni.hideLoading();
					uni.$u.toast(result.data.message);
				}
			},
			async getInfo() {
				uni.showLoading({
					title: this.$lang.LOADING,
				})
				const result = await this.$http.get(this.$http.API_URL.USER_INFO, {})
				if (result.data.code == 0) {
					this.userInfo = result.data.data;
					uni.hideLoading()
				} else {
					uni.$u.toast(result.data.message);
					uni.hideLoading()
				}
			},
		},
	}
</script>