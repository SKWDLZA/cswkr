// 统一语言转换
const LANGUAGE_DATA = {
	SIGN_IN: "ログイン", // 登入
	SIGN_UP:'今すぐ登録',//创建账户
	SIMGN_OUT: "", // 登出
	USER_NAME:'電話番号を入力してください',//请输入账户
	PASSWORD: 'パスワード', // 请输入密码
	PASSWORD2: 'パスワードを設定してください', // 请输入密码
	PASSWORD_CONFIRM: '再度パスワードを入力してください', // 请再次输入密码
	INVITATION_CODE:'機関コードを入力ください',//输入邀请码
	// 底部导航
	HOME: 'ホーム', // 主页
	FAVORITES: '国内市場', // 感兴趣的
	MARKET_QUOTATION:'市場概要',//行政
	POSITION:'保有銘柄一覧',//盈亏/余额
	USER_CENTER: 'もっと見る', // 个人中心
	//主页按钮组
	TRADE_SHORT:'スキャルピング', // 短打交易
	TRADE_LARGE: '大口・OTC', // 大宗交易
	TRADE_IPO: 'ブロックディール', // 新股申购
	TRADE_MARKET: '日中取引', // 日内交易
	TRADE_DISCOUNT: '割引取引', // 折价交易
	TRADE_SALE:'「新株販売」',//新股配售
	
	SERVICE: 'カスタマーサービス', // 客服
	CHANGE_PWD: 'ログインパスワードの変更', // 更改登入密码
	CHANGE_PAY_PWD:'決済パスワードの変更',//更改支付密码
	CARD_MANAGEMENT: '入出金口座の提携', // 存款/取款账户联动
	ABOUT:'「会社紹介」',//关于我们
	SEARCH:'検索', // 检索
	DETAIL:'購入', // 详情
	
	// =============== 2024.03.04 ==============
	WITHDRAWAL:'「資金引き出し」',// 提款 Withdrawal
	AUTH:'「実名認証」',//身份验证/实名登记
	
	
	ORDER: 'スマートオーダー', // 智能订单
	NEW_SHARE: '公母州', // 公开发行股
	CREATE_BANK: 'お金を引き出す',//提款
	
	
	ENPTY_DATA: '履歴なし', // 暂无记录
	ALL_MSG: '銘柄', // 实时事件
	PRODUCT_DEATIL:'「株式の詳細」',//库存详情
	FULL_INFO: '市況', // 完整摘要
	HOT_GOODS:'「人気種目」',//热门商品
	MARKET_INDICATORS: '市場指標', // 市场指标
	MARKET_ISSUES:'ニュース',//市场问题
	CAPITAL_DETAIL:'取引履歴',//资金明细/存取款记录/资金流水
	VERIFIED:'確認済み[未認証]', // 已验证[未验证]
	AUDIT: '本人確認', // 已确认[审核中]
	AUDIT_FAILED:'「確認済み[監査失敗]」',//已确认[审核失败]
	
};
export default LANGUAGE_DATA;