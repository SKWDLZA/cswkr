<template>
	<!-- 주주들은 지분을 줄인다 -->
	<view>
		<view class="white-background">
			<view class="notes">
				<view class="purchase" @tap="blockTransactions()">
					<image src="../../static/erceng/shengou.png" mode=""></image>
					<view class="">Transaction records</view>
				</view>
			</view>
			<view class="take-notes">
				<view class="purchase">Name</view>
				<view class="purchase">Price</view>
				<view class="purchase">Details</view>
			</view>
		</view>
		<!-- 产品列表-->
		<view class="science" v-for="(item,index) in business" :key="index">
			<view class="display" style="margin: 20rpx 0;">
				<view class="">
					<view class="corporation">{{item.goods.name}}</view>
					<view class="area" v-if="item.goods.locate=='Deep'">
						<view class="deep">{{item.goods.locate}}</view>
						<view class="deep-number">{{item.goods.code}}</view>
					</view>
					<view class="area" v-if="item.goods.locate=='North'">
						<view class="north">{{item.goods.locate}}</view>
						<view class="north-number">{{item.goods.code}}</view>
					</view>
					<view class="area" v-if="item.goods.locate=='Shanghai'">
						<view class="shanghai">{{item.goods.locate}}</view>
						<view class="shanghai-number">{{item.goods.code}}</view>
					</view>
				</view>
				<view class="price">
					{{item.price}}
				</view>
				<view class="detailed" @click="detail(item)">Details</view>
			</view>
		</view>


		<u-popup :show="show" @close="close" :round="20" mode="bottom" :closeable='closeable'>
			<view class="largeAmount">
				<view class="business">Shareholders reduce their stake</view>
				<view class="price">Subscription price</view>
				<view class="purchase-price">{{detailId.price}}</view>
				<view class="purchase-text">
					<u-input type="number" placeholder="Enter your subscription quantity" v-model="value1"></u-input>
					<view class="hand">Share</view>
				</view>
				<view class="amount">Price<text>{{detailId.price*this.value1|addZero}} </text> </view>
				<view class="available">
					<u-input type="password" placeholder="Please enter your fund password" v-model="value2"></u-input>
				</view>
				
				<!-- <view class="available">
					<u-input type="password" placeholder="请输入주주들은 지분을 줄인다密码" v-model="value3"></u-input>
				</view> -->
				
				<view class="fund">Funds available<text>{{availableFunds.money}}</text>
				</view>
				<view class="purchase" @click="bulkPurchase(detailId.id)">Buy</view>
			</view>
		</u-popup>


	</view>
</template>

<script>
	export default {
		data() {
			return {
				show: false,
				closeable: true,
				business: "",
				detailed: '',
				value1: '',
				value2: '',
				value3: '',
				availableFunds: '',
				detailId: ''
			}
		},
		methods: {


			close() {
				this.show = false
				// console.log('close');
			},
			detail(item) {
				this.show = true
				this.bulkDetails(item)
				// console.log(this.bulkDetails, '987654');
			},
			blockTransactions() {
				uni.navigateTo({
					url: '/pages/index/components/newShares/blockTransactions/blockTransactions'
				});
			},
			//列表
			async largeAmount() {
				let list = await this.$http.get('api/goods-bigbill/list', {})
				this.business = list.data.data
			},
			//세부
			async bulkDetails(item) {
				let list = await this.$http.get('api/goods-bigbill/detail', {
					id: item.id
				})
				this.detailed = list.data.data.goods
				this.detailId = list.data.data

			},

			//点击购买
			async bulkPurchase(id) {
				let list = await this.$http.post('api/goods-bigbill/doOrder', {
					id: id,
					num: this.value1,
					pay_pass: this.value2,
					// password: this.value3,
				})
				if (list.data.code == 0) {
					this.show = false
					uni.$u.toast(list.data.message);
					this.value1 = ''
					this.value2 = ''
					this.value3 = ''
					this.available()
					setTimeout(() => {
						uni.navigateTo({
							url: '/pages/index/components/newShares/blockTransactions/blockTransactions'
						});
					}, 1000)
				} else {
					// if (list.data.code == 1) {
					// 	setTimeout(() => {
					// 		uni.navigateTo({
					// 			url: '/pages/my/components/certificateBank/silver'
					// 		});
					// 	}, 1000)
					// }

					if (this.value1 == '') {
						this.show = false
						uni.$u.toast('Please enter the purchase quantity.');
						setTimeout(() => {
							this.show = true
						}, 1000)
					} else if (this.value2 == '') {
						this.show = false
						uni.$u.toast('Please enter your fund password');
						setTimeout(() => {
							this.show = true
						}, 1000)
					} 
					// else if (this.value3 == '') {
					// 	this.show = false
					// 	uni.$u.toast('请填写주주들은 지분을 줄인다密码');
					// 	setTimeout(() => {
					// 		this.show = true
					// 	}, 1000)
					// } 
					else {
						this.show = false
						uni.$u.toast(list.data.message);
						setTimeout(() => {
							this.show = true
						}, 1000)
					}
				}
			},
			//사용 가능한 자금
			async available() {
				let list = await this.$http.get('api/user/info', {})
				this.availableFunds = list.data.data
			},

		},

		//取小数点之后的2位
		filters: {
			addZero: function(data) {
				return data.toFixed(2)
			}
		},
		mounted() {
			this.largeAmount()
			this.available()
			// this.bulkDetails()
		},
		onShow() {
			this.bulkDetails()
			this.available()
		}
	}
</script>

<style lang="scss">
	/deep/.uni-input-placeholder {
		font-size: 28rpx !important;
	}

	.white-background {
		background: #fff;
		margin-top: -50rpx;
		border-radius: 20rpx 20rpx 0 0;

		.notes {
			text-align: center;
			padding: 30rpx 30rpx 30rpx;
			border-bottom: 1rpx solid #e0e0e0;

			.purchase {
				font-size: 28rpx;

				image {
					width: 40rpx;
					height: 40rpx;
				}
			}

		}

		.take-notes {
			display: flex;
			justify-content: space-between;
			align-items: center;
			text-align: center;
			padding: 30rpx 30rpx 30rpx;
			border-bottom: 1rpx solid #e0e0e0;
			font-size: 28rpx;


		}
	}

	.science {
		margin: 30rpx;
		padding-bottom: 30rpx;
		border-bottom: 0.037037rem solid #e0e0e0;

		.corporation {
			font-size: 30rpx;
			font-weight: 600;
			color: #333;

		}

		.price {
			color: #f85252;
			font-size: 28rpx;
		}

		.detailed {
			background-image: linear-gradient(to right, #1a73e8, #014b8d);
			color: #fff;
			border-radius: 40rpx;
			padding: 6rpx 40rpx;
			font-size: 26rpx
		}

		.find {
			width: 45%;

			view:nth-child(2) {
				color: #f85252;
			}
		}

		.ration {
			width: 45%;

			view:nth-child(2) {
				color: #f85252;
			}
		}
	}

	//弹窗
	.largeAmount {
		padding: 30rpx;

		.business {
			text-align: center;
			font-size: 30rpx;
			color: #333;
			border-bottom: 1rpx solid #e0e0e0;
			padding-bottom: 30rpx;

		}

		.price {
			color: #333;
			font-weight: 500;
			margin: 30rpx 0;
		}

		.purchase-price {
			color: #ea3544;
			margin: 10rpx;
			font-weight: 600;
		}

		.purchase-text {
			display: flex;
			justify-content: space-between;
			align-items: center;
			border: 1rpx solid #ffdcdc;
			padding: 0 20rpx;
			border-radius: 10rpx;
			margin: 20rpx 0;

			.hand {
				border-left: 1rpx solid #e0e0e0;
				padding-left: 30rpx;
			}
		}

		.amount {
			color: #999;
			font-size: 24rpx;

			text {
				color: #f33030;
				margin-left: 20rpx;
			}
		}

		.available {
			border: 1rpx solid #ebebeb;
			padding: 0 20rpx;
			border-radius: 10rpx;
			margin: 20rpx 0;
		}

		.fund {
			color: #999;
			font-size: 24rpx;

			text {
				color: #f33030;
				margin-left: 20rpx;
			}
		}

		.purchase {
			background-image: linear-gradient(to right, #1a73e8, #014b8d);
			margin: 30rpx;
			border-radius: 20rpx;
			padding: 20rpx 0;
			text-align: center;
			color: #fff;
			font-weight: 600;

		}

	}
</style>
