<template>
	<view>
		<view class="header_wrapper_10">
			<Header></Header>
		</view>

		<view style="display: flex; align-items: center;flex-wrap: nowrap;padding:10px;">
			<block v-for="(item,index) in best" :key="index">
				<view @click="productDetails(item.goods.code,item.id)" 
					style="flex:33.33%;margin:6px;padding:4px 0 4px 10px;"
					:style="{backgroundImage:`linear-gradient(#F5F5F5, ${item.goods.rate>0?'#FFA1AE':'#99edff'}`}">
					<view style="display: flex; align-items: center;justify-content: space-between;">
						<view style="font-weight: 900;padding-right: 16px;"
							:style="$util.calcStyleRiseFall(item.goods.rate>0)">{{item.goods.code}}</view>
							<image :src="`/static/icon_${item.goods.rate>0?'rise':'fall'}.png`" mode="aspectFit" :style="$util.calcImageSize(12)" style="padding-right: 10px;"></image>
					</view>

					<view style="" :style="{color:$util.THEME.TEXT}">
						{{item.goods.name}}
					</view>
					<view style="" :style="$util.calcStyleRiseFall(item.goods.rate>0)">
						{{$util.formatNumber(item.goods.current_price)}}
					</view>
					<view style="" :style="$util.calcStyleRiseFall(item.goods.rate>0)">
						{{item.goods.rate>0?'+':''}}{{item.goods.rate}}%
					</view>
				</view>
			</block>
		</view>

		<view style="padding:4px 10px;display: flex;flex-wrap: nowrap;align-items: center;margin-left: 10px;">
			<image mode="aspectFit" src="/static/stock_all.png" :style="$util.calcImageSize(24)"></image>
			<view style="padding-left: 10px; font-size: 16px;" :style="{color:$util.THEME.PRIMARY}">{{ $lang.STOCK_BOOK}}</view>
		</view>

		<view class="common_block" style="margin: 10px;min-height: 69vh;">
			<view class="line"
				style="display: flex;align-items: center;padding:6px 10px;background-color: #01b4d5a3;border-top-left-radius: 10px;border-top-right-radius: 10px;"
				:style="{color:$util.THEME.LABEL}">
				<view style="flex:18%;">{{$lang.STOCK}}/{{$lang.CODE}}</view>
				<view style="flex:32%;"></view>
				<view style="flex:25%;text-align: right; padding-right: 16px;">{{$lang.RISE_FALL_AMOUNT}}</view>
				<view style="flex:15%;text-align: right; padding-right: 16px;">{{$lang.RISE_FALL_RATE}}</view>
				<view style="flex:5%;"></view>
			</view>
			<EmptyData v-if="list.length<=0"></EmptyData>
			<block v-for="(item,index) in list" :key="index">
				<view @click="productDetails(item.goods.code,item.id)" class="line"
					style="display: flex;align-items: center;margin:6px 10px;padding-bottom: 6px;">
					<view style="flex:15%;font-weight: 900;padding-right: 16px;"
						:style="$util.calcStyleRiseFall(item.goods.rate>0)">{{item.goods.code}}</view>
					<view style="flex:40%;" :style="{color:$util.THEME.TEXT}">
						{{item.goods.name}}
					</view>
					<view style="flex:25%;text-align: right; padding-right: 16px;"
						:style="$util.calcStyleRiseFall(item.goods.rate>0)">
						{{$util.formatNumber(item.goods.current_price)}}
					</view>
					<view style="flex:15%;text-align: right; padding-right: 16px;"
						:style="$util.calcStyleRiseFall(item.goods.rate>0)">
						{{item.goods.rate>0?'+':''}}{{item.goods.rate}}%
					</view>
					<view style="flex:5%;">
						<image mode="aspectFit" src="/static/star.png" :style="$util.calcImageSize(24)"
							@click.stop="handleClickDelProduct(item.goods.gid)"></image>
					</view>
				</view>
			</block>
		</view>
	</view>
</template>

<script>
	import Header from '@/components/Header.vue';
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		components: {
			Header,
			EmptyData,
		},
		data() {
			return {
				list: [],
				timer: null,
			}
		},
		onShow() {
			this.getList()
			this.startTimer()
		},
		onHide() {
			clearInterval(this.timer);
		},
		computed: {
			// 最高值的三条数据，块状显示
			best() {
				if (this.list) {
					return this.list.length <= 0 ? [] : this.list.length > 0 && this.list.length <= 3 ? this.list : this
						.list
						.sort((a, b) => b.goods.rate - a.goods.rate).slice(0, 3);
				}
			}
		},
		methods: {
			productDetails(code, id) {
				uni.navigateTo({
					url: `${this.$util.PAGE_URL.STOCK_OVERVIEW}?code=${code}&id=${id}`
				});
			},
			//定时器
			startTimer() {
				this.timer = setInterval(() => {
					this.getList();
				}, 5000);
			},

			async getList() {
				if (this.list.length <= 0) {
					uni.showLoading({
						title: this.$lang.LOADING,
					})
				}
				const result = await this.$http.get(this.$http.API_URL.COLLECT_LIST, {});
				uni.hideLoading();
				if (result.data.code == 0) {
					this.list = result.data.data.list;
				}
			},

			// 点击删除
			async handleClickDelProduct(gid) {
				const result = await this.$http.post(this.$http.API_URL.COLLECT_EDIT, {
					gid: gid,
				})
				if (result.data.code == 0) {
					uni.$u.toast(result.data.message);
					this.getList()
				} else {
					uni.$u.toast(result.data.message);
				}
			},
		},
	}
</script>