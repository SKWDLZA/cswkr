<!-- 新股申购 -->
<template>
	<view>
		<CustomHeader title="공모주신청" @action="handleBack()"></CustomHeader>
		<view style="display: flex;align-items: center;justify-content:space-around;" class="gap10 margin-right-20 margin-left-20">
			<view @click="handleChangeTab(0)" class="common_btn btn_primary flex-1" style="padding:2px 4px;">
				청약기록</view>
			<view @click="handleChangeTab(1)" class="common_btn btn_secondary flex-1" style="padding:2px 4px;">
				거래정보</view>
		</view>

		<view style="margin: 10px;background-color: #FFF;padding: 10px;min-height: 88vh;">
			<EmptyData v-if="list.length<=0"></EmptyData>
			<template v-if="current == 0">
				<block v-for="(item,index) in list" :key="index">
					<view style="border-bottom: 0.01rem solid #e0e0e0;margin-top: 10px;margin-bottom: 10px;" >
						<view style="align-items: center;justify-content: space-between;" class="flex">
							<view :style="{color:$util.THEME.TEXT}" style="font-size: 18px;">{{item.goods.name}}</view>
							<view @click="to_skip(item.id)" class="common_btn btn_primary"
								style="padding:2px 4px;width: 80px;margin-top: 0;">청약 신청</view>
						</view>
						<view style="display: flex;align-items: center;justify-content: space-between;">
							<view :style="{color:$util.THEME.TIP}">청약 가격</view>
							<view :style="{color:$util.THEME.PRIMARY}">{{$util.formatNumber(item.price)}}</view>
						</view>
						<view style="display: flex;align-items: center;justify-content: space-between;">
							<view :style="{color:$util.THEME.TIP}">수익률</view>
							<view :style="{color:$util.THEME.PRIMARY}">{{$util.formatNumber(item.shiying)}}</view>
						</view>
						<view style="display: flex;align-items: center;justify-content: space-between;">
							<view :style="{color:$util.THEME.TIP}">청약 날짜</view>
							<view :style="{color:$util.THEME.TIP}">{{item.shengou_date}}</view>
						</view>
					</view>
				</block>
			</template>

			<template v-else>
				<block v-for="(item,index) in list" :key="index">
					<view style="border-bottom: 2rpx solid #e0e0e0;padding-bottom:20rpx;">
						<view class="display approve">
							<view>
								<view class="corporation">{{item.goods.name}}</view>
								
							</view>
							<view class="subscription-times">구독 시간<text>{{item.shengou_date}}</text> </view>
						</view>

						<view class="display" style="margin-top: 10rpx;">
							<view class="display price">구독
								가격<text>{{$util.formatNumber(item.price)}}</text>
							</view>
							<view class="display price">
								주가수익비율<text>{{$util.formatNumber(item.shiying)}}</text>
							</view>
						</view>
						<view class="display price">
							순환<text>{{$util.formatNumber(item.fa_amount)}}</text>
						</view>
					</view>
				</block>
			</template>
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		components: {
			CustomHeader,
			EmptyData,
		},
		data() {
			return {
				current: 0,
				list: [],
			};
		},
		onLoad(item) {},
		onShow() {
			this.getList();
		},

		methods: {
			handleBack() {
				uni.navigateBack({
					delta: 1
				});
			},
			handleChangeTab(val) {
				if (val == 0) {
					this.applyPurchase();
				} else if (val == 1) {
					this.luckyNumber();
				}
			},
			to_skip(id) {
				uni.navigateTo({
					url: `/pages/index/components/newShares/nullElement/nullElement?id=${id}`
				});
				// console.log(gid, fa_price, '携带');
			},

			async getList() {
				uni.showLoading({
					title: this.$lang.LOADING,
				})
				const result = await this.$http.post(`api/goods-shengou/calendar`, {
					type: this.current + 1, // 传参 1或2
				})
				this.list = result.data.data;
				uni.hideLoading();
			},

			//구독기록 订阅记录
			applyPurchase() {
				uni.navigateTo({
					url: `/pages/trade/ipoLog`
				});
			},
			//우승기록 获胜记录
			luckyNumber() {
				uni.navigateTo({
					url: '/pages/index/components/newShares/luckyNumber/luckyNumber'
				});
			},
		}
	}
</script>