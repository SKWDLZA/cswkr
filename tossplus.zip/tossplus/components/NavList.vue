<!-- 用于纵向导航，如：个人中心 -->
<template>
	<view class="common_block" style="padding: 6px;margin-top:10px;padding-top:16px;">
		<view v-for="(item,index) in list" :key="index" class="line"
			style="display: flex;align-items: center;margin:20px;padding-bottom: 10px;"
			@click="actionEvent(item,index)">
			<view style="flex: 20%;">
				<image mode="aspectFit" :src="`/static/${item.icon}.png`" :style="$util.setImageSize(48)"></image>
			</view>
			<text style="flex: 70%;font-weight: 700;font-size: 15px;color: #333333;">{{item.name}}</text>
			<view style="flex: 6%;">
				<view class="arrow rotate_45" :style="$util.setImageSize(20)"></view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		name: "NavList",
		props: ['list'],
		data() {
			return {};
		},
		methods: {
			actionEvent(item, index) {
				if(item.mode =='sign_out'){
					this.handleSignOut();
					return false;
				}
				if (item.mode) {
					uni.navigateTo({
						url: item.url,
					})
				} else {
					this.$emit('action', item);
				}
			},
			// 登出
			handleSignOut() {
				this.$http.post(this.$http.API_URL.SIGN_OUT, );
				try {
					let version = uni.getStorageSync('version')
					uni.removeStorageSync('token');
					uni.setStorageSync('version', version)
				} catch (e) {
					// error
				}
				uni.$u.toast('로그아웃 완료');
				setTimeout(() => {
					uni.navigateTo({
						url: this.$util.PAGE_URL.ACCOUNT_SIGNIN
					});
					// 登录成功之后强制刷新页面
					this.$router.go(0)
				}, 500)
			}
		}
	}
</script>

<style>

</style>