<!-- 银转证  存款 -->
<template>
	<view >
		<view class="header_wrapper_10">
			<CustomHeader :title="$lang.DEPOSIT" @action="handleBack()"></CustomHeader>
		</view>
		<view style="display: flex;align-items: center;flex-direction: column;margin-top: 30px;padding: 10px;">
			<view style="padding:0 20px 10px 20px;" :style="{color:$util.THEME.TIP}">{{$lang.TIP_AMOUNT_AVAIL}}</view>
			<view style="font-size: 28px;font-weight: 900;" :style="{color:$util.THEME.PRIMARY}">
				{{$util.formatNumber(userInfo.money)}}
			</view>
			
		</view>
		
		<view  style="padding: 14px 20px;">
			<!-- 充值金额 -->
			<view style="display: flex;align-items: center;font-size:12px;color: #000;padding:10px;margin-top: 10px;">
				<text style="flex:20%;">충전금액</text>
				<text style="flex:60%;text-align: center;font-weight: 500;color:#ccc;">최소 충전금액은 <text
						style="color:#f85252;padding:0 10px;">1000000</text>원</text>
				<text style="flex:20%;text-align: right;"></text>
			</view>

			<view class="recharge">
				<view class="common_input_wrapper"
					style="background-color: rgba(198, 198, 198,0.2);border: 1px solid #C6C6C6;margin:10px;">
					<!-- <image mode="aspectFit" src='/static/money.png' :style="$util.calcImageSize(20)">
					</image> -->
					<input v-model="amount" placeholder="충전금액을 입력해주세요" type="number"
						style="flex: auto;margin-left: 20px;" placeholder-style="font-size:11px"> </input>
				</view>

				<view
					style="display: flex;flex-wrap: nowrap;align-items: center;justify-content: space-between;padding:10px;">
					<block v-for="(item,index) in [1000000,5000000,10000000,50000000]" :key="index">
						<view style="padding:6px;border-radius: 6px;" :style="{backgroundColor:curPos==index?'rgb(1 180 213 / 15%)':'#FFF',color:'#333' }" @click="handleSelectAmount(item,index)">
							{{item}}
						</view>
					</block>
				</view>

			</view>
		</view>
		<view style="padding: 20px;">
			<!-- 儲值 -->
			<view class="common_btn btn_primary" style="width: 90%;margin:auto;" @click="handleConfirm()">제출 신청
			</view>
			<!-- <view style="font-size: 14px;font-weight: 700;text-align: center;margin: 20px 10px;" :style="{color:$util.THEME.TITLE}">친절한 팁
			</view> -->
			<view style="padding-bottom:6px;color: #999;margin:10px 10px;">입금시간 : 평일 09:00~18:00, 공휴일 휴무.</view>
			<view style="color: #999;margin:6px 10px;">
				<view>우리를 선택해주셔서 감사합니다.</view>
				<view>원할한 자금충전을 위하여 충전계좌는 매번 충전송금하실때 고객센터에 연락하여  확인해 주시기 바랍니다.</view>
				<view>고객 센터에서 안내해주신 계좌가 아닌 다른 계좌로  송금되는 상황이 발생하면 책임은 본인한테 있습니다.</view>
			</view>
		</view>

	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components: {
			CustomHeader,
		},
		data() {
			return {
				userInfo: {},
				curPos:-1, // 当前选中预置金额
				amount:'',
			};
		},
		onLoad(option) {
			this.getInfo()
		},
		methods: {
			handleBack() {
				uni.navigateBack({
					delta: 1
				});
			},
			// 选中的预置金额
			handleSelectAmount(val,index){
				this.curPos = index;
				this.amount=val;
			},
			
			handleConfirm(){
				if(this.amount==''){
					uni.$u.toast('금액을 입력해주세요.');
					return false;
				}
				
				const _this = this;
				uni.showModal({
					title: '이 충전 채널에 대해서는 온라인 고객 서비스에 문의하세요.',
					cancelText: this.$lang.CANCEL,
					confirmText: this.$lang.SERVICE,
					success: function(res) {
						if (res.confirm) {
							_this.hanleLink();
							uni.hideLoading();
						} else if (res.cancel) {
							console.log('사용자가 취소를 클릭합니다.');
						}
					}
				})
			},			
			
			async hanleLink() {
				uni.navigateTo({
					url: this.$util.PAGE_URL.SERVICE
				});
			},
			async getInfo() {
				uni.showLoading({
					title: this.$lang.LOADING,
				})
				const result = await this.$http.get(this.$http.API_URL.USER_INFO, {})
				if (result.data.code == 0) {
					this.userInfo = result.data.data;
					uni.hideLoading()
				} else {
					uni.$u.toast(result.data.message);
					uni.hideLoading()
				}
			},
		},
	}
</script>