<template>
	<view class="page lg-bg">
		<view class="lg"><!---->
			<view class="flex flex-c">
				<view class="icon logo">
					<image src="/static/chuanggai/logo.png"></image>
				</view>
			</view>
		</view>
		<view class="form">
			<view class="item">
				<view class="ipt flex flex-b">
					<uni-input class="flex-1">
						<div class="uni-input-wrapper">
							<input  type="text" class="uni-input-input" placeholder="Enter your email" v-model="value1">
						</div>
					</uni-input>

				</view>
			</view>
			<view class="item">
				<view class="ipt flex flex-b">
					<u-input placeholder="Email verification code" border="none" v-model="email_code" placeholderStyle="margin-left:20px;">
						<template slot="suffix">
							<u-code ref="uCode" @change="codeChange" seconds="20" :changeText="$t('index.60mhcxhq')"></u-code>
							<u-button @tap="getCode" :text="tips" type="success" size="mini">Get code</u-button>
						</template>
					</u-input>
				</view>
			</view>
			<view class="item">
				<view class="ipt flex flex-b"><uni-input class="flex-1">
						<div class="uni-input-wrapper">
							<input maxlength="12" step="" enterkeyhint="done" autocomplete="off" placeholder="Please enter your passwords" type="password" class="uni-input-input" v-if="showPassword" v-model="value2">
							
							<input maxlength="12" step="" enterkeyhint="done" autocomplete="off" placeholder="Please enter a password" type="text" class="uni-input-input" v-if="!showPassword" v-model="value2">
						</div>
					</uni-input>
					<view class="icon" :class="showPassword?'e':'e1'" @click="showPassWord"></view>
				</view>
			</view>
			<view class="item">
				<view class="ipt flex flex-b"><uni-input class="flex-1">
						<div class="uni-input-wrapper">
							<input maxlength="12" step="" enterkeyhint="done" autocomplete="off" placeholder="Verify password" type="password" class="uni-input-input" v-if="showPassword" v-model="value3">
							
							<input maxlength="12" step="" enterkeyhint="done" autocomplete="off" placeholder="Verify password" type="text" class="uni-input-input" v-if="!showPassword" v-model="value3">

						</div>
					</uni-input>
					<view class="icon" :class="showPassword?'e':'e1'" @click="showPassWord"></view>
				</view>
			</view>
			<view class="item">
				<view class="ipt flex flex-b"><uni-input class="flex-1">
						<div class="uni-input-wrapper">
							<input maxlength="140" step="" enterkeyhint="done" autocomplete="off" placeholder="Enter invitation code" type="password" class="uni-input-input" v-model="code">
							
						</div>
					</uni-input><!----></view>
			</view>
			<view class="btns flex flex-b">
				<view class="login-btn flex-1 flex flex-c" @click="gain_register">Registration</view>
			</view>
		</view>
		<view>
			<view class="flex flex-c lg-btn" @tap="signIn()">
				<view>Log in now</view>
				<view class="icon jt"></view>
			</view>
			<view class="kefu flex flex-c" @tap="kefu()">
				<view class="img flex flex-c">
					<image src="/static/kefu.png" style="width: 24px;height: 24px;"></image>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				nick_name: '',
				value1: '',
				value2: '',
				value3: '',
				code: '',
				email_code:'',
				checkboxValue1: [],
				showPassword: true,
				smscode:""
			};
		},
		methods: {
			async getCode() {
				const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
				let invalidEmail = !emailPattern.test(this.value1);
				if(invalidEmail){
					return uni.$u.toast('Please enter your vaild email');
				}
				if (!this.value1) {
					uni.$u.toast('Please enter your vaild email');
					return
				}
				if (this.$refs.uCode.canGetCode) {
					// 模拟向后端请求验证码
					uni.showLoading({
						title: "Getting"
					})
					let list = await this.$http.post('api/app/sendSmsCode', {
						mobile: this.value1,
			
					})
					uni.hideLoading();
					// 这里此提示会被this.start()方法中的提示覆盖
					uni.$u.toast("Verification code sent");
					// 通知验证码组件内部开始倒计时
					this.$refs.uCode.start();
			
				} else {
					// uni.$u.toast('倒计时结束后再发送');
				}
			},
			showPassWord() {
				this.showPassword = !this.showPassword
			},
			//协议
			agree() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/my/components/other/userAgreement'
				});
			},
			// 跳转到登录
			signIn() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/logon/logon/logon'
				});
			},
			kefu() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/index/components/customer/customerzd'
				});
			},
			home() {
				uni.navigateBack({
					delta: 1, //返回层数，2则上上页
				});
			},
			//注册
			async gain_register() {
				const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
				let invalidEmail = !emailPattern.test(this.value1);
				if(invalidEmail){
					return uni.$u.toast('Please enter your vaild email');
				}
				console.log(invalidEmail);
				
				if (this.value1 == '') {
					return uni.$u.toast('Please enter your email');
				} else if (this.value2 == '') {
					return uni.$u.toast('Please enter a password');
				} else if (this.value3 == '') {
					return uni.$u.toast('Please enter a password');
				} else if (this.value3 != this.value2) {
					return uni.$u.toast('Two passwords do not match');
				} else if (!this.code) {
					return uni.$u.toast('Please enter your authentication number');
				}
				

				// else if (this.checkboxValue1.length == 0) {
				// 	uni.$u.toast('請閱讀協議後,在勾選');
				// } 
				else {
					let list = await this.$http.post('api/app/register', {
						mobile: this.value1,
						password: this.value2,
						confirmpass: this.value3,
						invite: this.code,
						code: this.email_code,
					})
					// console.log(list.data.code);
					if (list.data.code == 0) {
						uni.$u.toast('Registration has been completed. Please log in.');
						setTimeout(() => {
							uni.navigateTo({
								url: '/pages/logon/logon/logon'
							});
						}, 1000)
					} else {
						uni.$u.toast(list.data.message);
					}
				}
			},
			//数据请求
			async login_liufu() {
				try {
					uni.removeStorageSync('url');
				} catch (e) {}
				let list = await this.$http.get(
					'https://sm8-x8ax6-b574-u99hy-w4uv-dgm4-s-p-c.oss-cn-hongkong.aliyuncs.com/sotck-S1GT9GYprH0PVgMLwapC0nYzLAoDa0bd.txt', {
						// language: this.$i18n.locale
					})
				// 接口域名
				// console.log(list.data, '接口位置')
				uni.setStorageSync('url', list.data);
			},

		},
		async mounted() {
			await this.login_liufu()
		}
	}
</script>

<style lang="scss">
	.page {
		min-height: 100vh;
	}

	.lg-bg {
		width: 100%;
		height: 100%;
		background: url(/static/lg-bg.png) no-repeat top/100%;
	}

	.lg {
		padding: 55px 0;
		text-align: center;
	}

	.icon.logo {
		width: 99px;
		height: 99px;
		border-radius: 50%;
		overflow: hidden;

		uni-image {
			width: 100%;
			height: 100%;
		}
	}

	.form {
		background: #fff;
		padding: 0 16px;
		font-size: 14px;

		.item .ipt {
			height: 48px;
			background: #f6f6f6;
			border-radius: 24px;
			padding: 0 11px;
			margin-bottom: 16px;

			uni-input {
				background: transparent;
				padding-left: 11px;
			}
		}

		.btns {
			padding-top: 11px;
			padding-bottom: 11px;

			.login-btn {
				height: 48px;
				background: #eb333b;
				border-radius: 24px;
				font-size: 17px;
				font-weight: 700;
				color: #fff;
			}
		}
	}

	.lg-btn {
		width: 50%;
		height: 44px;
		line-height: 44px;
		background: #fff;
		border-radius: 11px;
		margin: 11px auto;

		uni-view {
			font-size: 17px;
			font-weight: 700;
			color: #eb333b;
		}

		.icon {
			margin-left: 5px;
		}
	}

	.kefu {
		border-top: 1px solid #dedede;
		width: 50%;
		margin: 11px auto;
		padding-top: 22px;

		.img {
			width: 49px;
			height: 49px;
			background: #f6f6f6;
			border-radius: 50%;
		}
	}
</style>