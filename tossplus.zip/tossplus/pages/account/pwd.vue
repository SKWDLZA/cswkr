<template>
	<view :style="$util.setPageBG('bg_common')">
		<CustomHeader title="로그인 비밀번호 변경" @action="handleBack()"></CustomHeader>

		<view style="padding:4px 10px;display: flex;flex-wrap: nowrap;align-items: center;margin-left: 10px;">
			<image mode="aspectFit" src="/static/stock_all.png" :style="$util.setImageSize(6,36)"></image>
			<view style="padding-left: 10px; font-size:36rpx;" :style="{color:$util.THEME.TITLE}">
				로그인 비밀번호 변경
			</view>
		</view>

		<view style="display: flex;flex-direction: column;justify-content: center;align-items: center;">
			<view class="common_block" style="width: 80%;padding:20px;">
				<view class="common_input_wrapper" style="background-color: rgba(198, 198, 198,0.2);border: 1px solid #C6C6C6;">
					<image mode="aspectFit" src="/static/password.png" :style="$util.setImageSize(28)">
					</image>
					<input v-model="value" type="password" :placeholder="$lang.OLD_PWD"
						:placeholder-style="$util.setPlaceholder()"></input>
				</view>

				<view class="common_input_wrapper" style="background-color: rgba(198, 198, 198,0.2);border: 1px solid #C6C6C6;">
					<image mode="aspectFit" src="/static/password.png" :style="$util.setImageSize(28)">
					</image>
					<input v-model="value2" type="password" :placeholder="$lang.NEW_PWD"
						:placeholder-style="$util.setPlaceholder()"></input>
				</view>

				<view class="common_input_wrapper" style="background-color: rgba(198, 198, 198,0.2);border: 1px solid #C6C6C6;">
					<image mode="aspectFit" src="/static/password.png" :style="$util.setImageSize(28)">
					</image>
					<input v-model="value3" type="password" :placeholder="$lang.NEW_PWD2"
						:placeholder-style="$util.setPlaceholder()"></input>
				</view>
			</view>
			<view class="common_btn btn_primary" style="width:80%;margin-top: 20px;" @click="changePassword">{{$lang.CONFIRM}}</view>
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components: {
			CustomHeader,
		},
		data() {
			return {
				value: "",
				value2: "",
				value3: "",
			};
		},
		methods: {
			handleBack() {
				uni.switchTab({
					url: this.$util.PAGE_URL.ACCOUNT_CENTER
				});
			},
			//修改登录密码
			async changePassword() {
				const result = await this.$http.post(this.$http.API_URL.SIGNIN_PASSWORD, {
					oldpass: this.value,
					newpass: this.value2,
					confirmpass: this.value3,
				})
				if (result.data.code == 0) {
					uni.$u.toast('프로필 변경완료');
					setTimeout(() => {
						uni.switchTab({
							url: this.$util.PAGE_URL.ACCOUNT_CENTER
						});
					}, 1000)
				} else {
					uni.$u.toast(result.data.message);
				}
			},
		},
	}
</script>