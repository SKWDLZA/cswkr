<!-- 下单 -->
<template>
	<view :style="$util.setPageBG('bg_common')">
		<CustomHeader :title="detailedData.name" @action="handleBack()"></CustomHeader>

		<view class="withdraw_info"
			style="display: flex;flex-direction: column; align-items: center;justify-content: space-around;">
			<view style="color:#f5f5f5">현재 잔액</view>
			<view style="font-size: 64rpx;font-weight: 700;color:#FFFFFF;">
				{{$util.formatNumber(userInfo.money)}}<text style="padding:0 4px">원</text>
			</view>
		</view>

		<view class="common_block" style=";margin-top: 20px;padding:20px 10px;" v-if="detailedData">
			<view class="flex padding-bottom-10">
				<view style="margin-left: 10px;" :style="{color:$util.THEME.TEXT}">{{detailedData.name}}</view>
				<view class="text-right flex-1 bold margin-right-20">
					<view :style="{color:$util.THEME.TEXT}">
						{{$util.formatNumber(detailedData.current_price)}}<text style="padding:0 4px">원</text>
					</view>
					<view :style="$util.calcStyleRiseFall(detailedData.rate>0)">{{detailedData.rate}}%</view>
				</view>
			</view>

			<view class="margin-top-20 bold" :style="{color:$util.THEME.TEXT}">
				수량
			</view>

			<view class="btns">
				<block v-for="(item,index) in quantityList" :key="index">
					<view class="item" style="flex:30%;margin:4px;" :class="curQuantity==item?'actity':'noactity'"
						@click="handleSelected(item)">{{item}}</view>
				</block>
			</view>

			<view class="common_input_wrapper"
				style="background-color: rgba(198, 198, 198,0.2);border: 1px solid #C6C6C6;">
				<view style="width: 20px;"></view>
				<input v-model="quantity" type="number" placeholder="수량을 입력해주세요" @input="handleInput"
					:placeholder-style="$util.setPlaceholder()"></input>
			</view>

			<view class="flex" style="font-size: 28rpx;" :style="{color:$util.THEME.TEXT}">
				<view class="flex-1">결제 금액</view>
				<view class="flex-2 text-right">
					<!-- <text v-if="detailedData.project_type_id==2">$</text> -->						
						{{detailedData.current_price*curQuantity/ganggan|addZero}}<text style="padding:0 4px">원</text>
				</view>
			</view>
			<view class="flex" style="font-size: 28rpx;" :style="{color:$util.THEME.TEXT}">
				<view class="flex-1">수수료</view>
				<view class="flex-2 text-right">
					<!-- <text v-if="detailedData.project_type_id==2">$</text> -->						
						{{detailedData.current_price*curQuantity/ganggan*fee|addZero}}<text style="padding:0 4px">원</text>
				</view>
			</view>
		</view>

		<view class="common_btn btn_primary" style="margin: 20px;" @click="placeOrder()">
			주문
		</view>

	</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components: {
			CustomHeader,
		},
		data() {
			return {
				quantityList: [50, 100, 150, 200, 250, 300], // 预置数量
				curQuantity: 50, // 当前选中预置数量
				show: false,
				detailedData: {},
				quantity: 50,
				ganggan: 1,
				userInfo: {},
				fee: 1, // 手续费
			};
		},
		mounted() {
			this.getUserInfo()
		},
		onLoad(option) {
			this.product(option.code)
			this.getconfig()
		},
		methods: {
			handleBack() {
				uni.navigateBack({
					delta: 1
				});
			},
			handleSelected(val) {
				this.curQuantity = val;
				this.quantity = this.curQuantity;
			},

			// 获取配置
			async getconfig() {
				const result = await this.$http.get(this.$http.API_URL.APP_CONFIG, {})
				if (result.data.code == 0) {
					const temp = result.data.data.reduce((map, item) => {
						map.set(item.key, item.value);
						return map;
					}, new Map());
					this.fee = temp.get('TransRate') || this.fee;
				}
			},

			// 输入值
			handleInput(e){
				this.curQuantity = Number(e.detail.value)
			},

			// 产品详情
			async product(code) {
				const result = await this.$http.get(this.$http.API_URL.PRODUCT_INFO, {
					code: code,
				})
				this.detailedData = result.data.data[0]

			},
			//购买
			placeOrder() {
				const _this = this;
				let money = this.$util.formatNumber(this.detailedData.current_price * this.curQuantity * 1)
				uni.showModal({
					title: "매수주문 확인",
					content: `${this.detailedData.name} ${this.$util.formatNumber(this.curQuantity)} 주 매수금액 ${money} 원`,
					cancelText: this.$lang.CANCEL,
					confirmText: this.$lang.CONFIRM,
					showCancel: true, // 是否显示取消按钮，默认为 true
					confirmColor: '#f55850',
					cancelColor: '#39B54A',
					success: (res) => {
						if (res.confirm) {
							_this.buy()
						} else {}
					}
				})
			},
			async buy() {
				uni.showLoading({
					mask: true, // 显示透明蒙层，防止触摸穿透
				});

				const result = await this.$http.post(this.$http.API_URL.PRODUCT_PURCHASE, {
					num: this.quantity || 0,
					gid: this.detailedData.gid,
					price: this.detailedData.current_price,
					ganggan: this.ganggan,
				});
				uni.hideLoading();
				if (result.data.code == 0) {
					uni.$u.toast(result.data.data.message);
					setTimeout(() => {
						uni.switchTab({
							url: this.$util.PAGE_URL.ACCOUNT_TRADE,
						});
					}, 1000)
				} else {
					uni.$u.toast(result.data.message);
				}
			},
			//实名认证
			async getUserInfo() {
				const result = await this.$http.get(this.$http.API_URL.USER_INFO, {})
				this.userInfo = result.data.data
			},
		},
		filters: {
			addZero: function(data) {
				return data.toFixed(0).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")
			}
		},
	}
</script>

<style lang="scss">
	.gp_type {
		position: fixed;
		top: 220rpx;
		background-color: #ed4344;
		color: #fff;
		width: 80rpx;
		padding: 14rpx;
		right: 40rpx;
		text-align: center;
	}

	.purchase {
		width: 90%;
		height: 80rpx;
		// background: url(../../static/anniu.png);
		background-size: 100% 100%;
		border-radius: 20rpx;
		font-weight: 700;
		color: #fff;
		font-size: 40rpx;
		display: -webkit-box;
		display: -ms-flexbox;
		display: flex;
		-webkit-box-align: center;
		-ms-flex-align: center;
		align-items: center;
		-webkit-box-pack: center;
		-ms-flex-pack: center;
		justify-content: center;
		margin: 40rpx 5%;
	}

	.actity {
		background-color: rgba(48, 131, 248, 0.35);
		color: #3c1f20;
		font-weight: 700;
		height: 80rpx;
		line-height: 80rpx;
		text-align: center;
		margin-bottom: 20rpx;
	}

	.noactity {
		background-color: #fff;
		color: #979898;
		border: 1px solid #f1f5f9;
		height: 80rpx;
		line-height: 80rpx;
		text-align: center;
		margin-bottom: 20rpx;
	}

	.f-dis-input {
		padding: 26rpx 24rpx;
		background: #f6f6f6;
		border-radius: 10rpx;
		color: #262626;
		font-size: 32rpx;
	}

	.yue {
		margin: 10px 20px;
		color: #fff;
		font-size: 56rpx;
		font-weight: 700;
	}
</style>