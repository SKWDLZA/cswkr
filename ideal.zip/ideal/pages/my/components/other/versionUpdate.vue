<!-- 版本更新 -->
<template>
	<view>
		<view class="college-bg">
			<view class="college-text">{{agreement.title}}</view>
			<view class=""></view>
		</view>

		<view class="">
			<view class="" v-html="agreement.content"></view>

		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				agreement: ''
			};
		},
		methods: {
			home() {
				uni.switchTab({
					url: this.$util.PAGE_URL.ACCOUNT_CENTER
				});
			},
			async edition() {
				let list = await this.$http.get('api/version/detail', {
					// language: this.$i18n.locale
				})
				this.agreement = list.data.data
			},
		},
		mounted() {
			this.edition()
		},
	}
</script>

<style lang="scss">
	.college-bg {
		padding: 20rpx;
		height: 80rpx;
		background-color: #014b8d;
		display: flex;
		justify-content: space-between;
		align-items: center;
		text-align: center;

		image {
			width: 20rpx;
			height: 40rpx;
		}

		.college-text {

			color: #fff;
			font-weight: 800;
			font-size: 36rpx;
		}

	}

	.college-content {
		padding: 40rpx;
		font-size: 28rpx;

		.about {
			display: flex;
			flex-direction: column;
			justify-content: center;
			align-items: center;
			margin: 30rpx 0;

			image {
				width: 200rpx;
				height: 200rpx;
			}

			.ouyi-name {
				font-size: 46rpx;
				font-weight: 900;
				margin: 20rpx 0;
			}

			.edition {
				font-size: 25rpx;
				color: #929292;
			}
		}

	}
</style>
