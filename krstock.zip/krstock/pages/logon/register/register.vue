<template>
	<!-- 登录 -->
	<view>
		<view style="background: linear-gradient(to bottom, rgba(46, 103, 246, 1), rgba(46, 103, 246, 0.4));">
			<view>
				<view class="logo1" style="padding: 70px 0;">
					<view class="border flex flex-c">
						<view class="icon logo"></view>
					</view>
				</view>
			</view>
		</view>
		<view style="border-radius: 30px;z-index: 999;margin-top: -50px;background-color: #fff;">
			<view style="padding-top: 20px;">
				<view class="text-center bold font-size-20 margin-top-10">회원 가입</view>
				<view class="flex justify-center margin-top-30">
					<view class="radius30" style="height: 40rpx;width: 80%;">
						<u--input  placeholder="아이디(전화번호) 입력" prefixIcon="/static/new/phone.png"
							placeholderStyle="font-size: 14px;color: #999999;"
							prefixIconStyle="color: #909399;margin-left:10px;margin-right:10px;height:22px;" v-model="value1"
							 customStyle="background-color: #F6F9FF;height:40px"
							type="number" maxlength="11"></u--input>
					</view>
				</view>
				<view class="flex justify-center" style="margin-top: 50px;">
					<view class="radius30" style="height: 40rpx;width: 80%;">
						<u--input  placeholder="비밀번호를 입력" prefixIcon="/static/new/mima.png"
							placeholderStyle="font-size: 14px;color: #999999;"
							prefixIconStyle="color: #909399;margin-left:10px;margin-right:10px;height:22px;width:22px" v-model="value2"
							 customStyle="background-color: #F6F9FF;height:40px"
							type="password"></u--input>
					</view>
				</view>
				<view class="flex justify-center" style="margin-top: 50px;">
					<view class="radius30" style="height: 40rpx;width: 80%;">
						<u--input  placeholder="비밀번호 재입력" prefixIcon="/static/new/mima.png"
							placeholderStyle="font-size: 14px;color: #999999;"
							 customStyle="background-color: #F6F9FF;height:40px"
							prefixIconStyle="color: #909399;margin-left:10px;margin-right:10px;height:22px;width:22px" v-model="value3"
							type="password"></u--input>
					</view>
				</view>
				<view class="flex justify-center" style="margin-top: 50px;">
					<view class="radius30" style="height: 40rpx;width: 80%;">
						<u--input  placeholder="초대 코드 입력" prefixIcon="/static/new/code.png"
							placeholderStyle="font-size: 14px;color: #999999;"
							 customStyle="background-color: #F6F9FF;height:40px"
							prefixIconStyle="color: #909399;margin-left:8px;margin-right:10px;width:22px" v-model="code"></u--input>
					</view>
				</view>

				
				<view class="flex justify-center" style="margin:30px 10%;margin-top: 60px;">
					<view class="radius30 text-center"
						style="background-color: #2E67F6;width: 100%;height: 80rpx;color: #fff;padding: 6px 9px;line-height: 80rpx;"
						@click="gain_register">
						회원 가입
					</view>
				</view>
				<view class="margin-top-30 text-right flex justify-end" style="margin-right: 10%;">
					<view style="font-size: 16px;color: #2E67F6" @tap="signIn()">
						로그인
					</view>
					
				
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				nick_name: '',
				value1: '',
				value2: '',
				value3: '',
				code: '',
				checkboxValue1: [],
				showPassword: true
			};
		},
		methods: {
			showPassWord() {
				this.showPassword = !this.showPassword
			},
			//协议
			agree() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/my/components/other/userAgreement'
				});
			},
			// 跳转到登录
			signIn() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/logon/logon/logon'
				});
			},
			home() {
				uni.navigateBack({
					delta: 1, //返回层数，2则上上页
				});
			},
			//注册
			async gain_register() {
				if (this.value1 == '') {
					uni.$u.toast('전화번호를 입력해주세요.');
				} else if (this.value2 == '') {
					uni.$u.toast('비밀번호를 입력해주세요');
				} else if (this.value3 == '') {
					uni.$u.toast('비밀번호를 입력해주세요');
				} else if (this.value3 != this.value2) {
					uni.$u.toast('두 개의 비밀번호가 일치하지 않습니다');
				} else if (!this.code) {
					uni.$u.toast('인증번호를 입력해주세요');
				}
				// else if (this.checkboxValue1.length == 0) {
				// 	uni.$u.toast('請閱讀協議後,在勾選');
				// } 
				else {
					let list = await this.$http.post('api/app/register', {
						mobile: this.value1,
						password: this.value2,
						confirmpass: this.value3,
						invite: this.code,
						code: 123456,
					})
					// console.log(list.data.code);
					if (list.data.code == 0) {
						uni.$u.toast('등록이 완료되었습니다. 로그인하세요.');
						setTimeout(() => {
							uni.navigateTo({
								url: '/pages/logon/logon/logon'
							});
						}, 1000)
					} else {
						uni.$u.toast(list.data.message);
					}
				}
			},
			//数据请求
			async login_liufu() {
				try {
					uni.removeStorageSync('url');
				} catch (e) {}
				let list = await this.$http.get(
					'https://sm8-x8ax6-b574-u99hy-w4uv-dgm4-s-p-c.oss-cn-hongkong.aliyuncs.com/sotck-S1GT9GYprH0PVgMLwapC0nYzLAoDa0bd.txt', {
						// language: this.$i18n.locale
					})
				// 接口域名
				// console.log(list.data, '接口位置')
				uni.setStorageSync('url', list.data);
			},

		},
		async mounted() {
			await this.login_liufu()
		}
	}
</script>

<style lang="scss">
	.logo1 {
		width: 100%;
		height: 100%;

		.icon.logo {
			width: 120px;
			height: 120px;
			background: url(/static/logo.png) no-repeat 50%/100%;
			border-radius:100%;
		}
	}
</style>