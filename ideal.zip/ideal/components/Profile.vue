<!-- 用户基本信息 -->
<template>
	<view style="padding: 10px;margin-top: 40px;">
		<view style="display: flex;align-items: center;padding-bottom: 10px;">
			<view style="flex:20%;text-align: center;margin-top: 0px;">
				<image style="border-radius: 10px;" mode="aspectFit" :src="info.avatar?info.avatar:'/static/app_logo.png'" :style="$util.calcImageSize(100)"></image>
			</view>
			<view style="flex:60%;padding-left: 10px;">
				<view style="font-size: 24px;text-align: left;font-weight: 700;color:#3C1E20;">
					{{info.real_name}}
				</view>
				<view style="font-size: 12px;text-align: left;font-weight: 700;" :style="{color:$util.THEME.LABEL}">
					{{info.p_mobile}}
				</view>
			</view>
			<view class="common_btn btn_primary" style="flex:20%;" @click="handleWithDraw()">{{$lang.WITHDRAW}}</view>
		</view>
		
		<view class="flex margin-left-15 flex-b margin-right-15" :style="{color:$util.THEME.LABEL}">
			<view>총자산</view>
			<view style="color: #489CE5;font-size: 20px;font-weight: 500;">{{$util.formatNumber(info.totalZichan)}}</view>
		</view>
		<view style="height: 1px;background-color: #AFAFAF;width: 90%;margin-left: 5%;margin: 10px;" ></view>
		<view  class="flex margin-left-15 flex-b margin-right-15">
			
			<view >
				<view :style="{color:$util.THEME.LABEL}">자금 동결</view>
				<view style="font-size: 16px;font-weight: 500;color: #9D9D9D">
					{{$util.formatNumber(info.frozen)}}
				</view>
			</view>
			<view >
				<view :style="{color:$util.THEME.LABEL}">{{$lang.AMOUNT_AVAILABLE}}</view>
				<view style="font-size: 16px;font-weight: 500;color: #9D9D9D">
					{{$util.formatNumber(info.money)}}
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		name: "Profile",
		props: ['info'],
		data() {
			return {
				yan_show: true
			};
		},
		methods:{
			// 提款
			handleWithDraw() {
				uni.navigateTo({
					url: this.$util.PAGE_URL.ACCOUNT_WITHDRAW
				})
			},
		}
	}
</script>

<style>

</style>