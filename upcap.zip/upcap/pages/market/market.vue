<!-- 行情 -->
<template>
	<view >
		<view class="bg_market">
			<Header :title="$lang.MARKET_QUOTATION"></Header>
		</view>
		<ButtonGroup :btns="$util.mqBtnsConfig()" @action="handleBtnClick" col="33.33"></ButtonGroup>

		<view >
			<TabOne v-if="current==0"></TabOne>
			<TabTwo v-if="current==1"></TabTwo>
			<TabThree v-if="current==2"></TabThree>
		</view>
	</view>
</template>

<script>
	import Header from '@/components/Header.vue';
	import ButtonGroup from '@/components/ButtonGroup.vue';
	import TabOne from '@/components/market/TabOne.vue'
	import TabTwo from '@/components/market/TabTwo.vue'
	import TabThree from '@/components/market/TabThree.vue'
	export default {
		components: {
			Header,
			ButtonGroup,
			TabOne,
			TabTwo,
			TabThree,
		},
		data() {
			return {
				current: 0
			}
		},
		onShow() {},


		methods: {
			handleBtnClick(index) {
				this.current = index;
			},
		},

		mounted() {},

		onLoad(op) {
			if (op.type) {
				this.current = op.type
			}
		},
		onUnload() {
			clearInterval(this.timerId);
		},
		onHide() {
			clearInterval(this.timerId);
		},
	}
</script>

<style lang="scss">

</style>