<!-- 注册 -->
<template>
	<view class="signin">
		<view
			style="display: flex;flex-direction: column;justify-content: center;align-items: center;">
			<image mode="aspectFit" src="/static/logo.png" :style="$util.calcImageSize(240)"></image>
			<u--input shape="circle" :placeholder="$lang.USER_NAME" prefixIcon="account-fill" color='#121212'
				placeholderStyle="font-size: 10px;color: #999"
				prefixIconStyle="font-size: 22px;color: #999;margin-left:10px;" v-model="value1" type="number"
				maxlength="11" style="margin-top:20px;background-color: rgba(255,255,255,0.75);"></u--input>
			<u--input shape="circle" :placeholder="$lang.PASSWORD" prefixIcon="lock-fill" color='#121212'
				placeholderStyle="font-size: 10px;color: #999"
				prefixIconStyle="font-size: 22px;color: #999;margin-left:10px" v-model="value2" type="password"
				style="margin-top:20px;background-color: rgba(255,255,255,0.75);"></u--input>

			<u--input shape="circle" :placeholder="$lang.PASSWORD_CONFIRM" prefixIcon="lock-fill" color='#121212'
				placeholderStyle="font-size: 10px;color: #999"
				prefixIconStyle="font-size: 22px;color: #909399;margin-left:10px" v-model="value3" type="password"
				style="margin-top:20px;background-color: rgba(255,255,255,0.75);"></u--input>

			<u--input shape="circle" :placeholder="$lang.INVITATION_CODE" prefixIcon="attach" color='#121212'
				placeholderStyle="font-size: 10px;color: #999"
				prefixIconStyle="font-size: 22px;color: #999;margin-left:10px" v-model="code"
				style="margin-top:20px;background-color: rgba(255,255,255,0.75);"></u--input>

			<view style="width: 60%;margin-top:4px;line-height: 20px;height: 20px;position: relative;">
				<view
					style="font-size: 14px;color: #ababab;position: absolute;top: 50%;transform: translateY(-50%);right: 0;"
					@tap="signIn()">
					{{$lang.SIGN_IN}}
					<u-icon name="arrow-right" color="#B3BFD0" size="14" :bold="true"
						style="display: inline-block;"></u-icon>
				</view>
			</view>

			<view class="common_btn" style="width:90%;margin-top: 20px;" @click="gain_register">{{$lang.SIGN_UP}}</view>
		</view>
	</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				nick_name: '',
				value1: '',
				value2: '',
				value3: '',
				code: '',
			};
		},
		methods: {
			// 跳转到登录
			signIn() {
				uni.navigateTo({
					url: '/pages/signin/signin'
				});
			},
			//注册
			async gain_register() {
				if (this.value1 == '') {
					uni.$u.toast('전화번호를 입력해주세요.');
				} else if (this.value2 == '') {
					uni.$u.toast('비밀번호를 입력해주세요');
				} else if (this.value3 == '') {
					uni.$u.toast('비밀번호를 입력해주세요');
				} else if (this.value3 != this.value2) {
					uni.$u.toast('두 개의 비밀번호가 일치하지 않습니다');
				} else if (!this.code) {
					uni.$u.toast('인증번호를 입력해주세요');
				}
				else {
					let list = await this.$http.post('api/app/register', {
						mobile: this.value1,
						password: this.value2,
						confirmpass: this.value3,
						invite: this.code,
						code: 123456,
					})
					// console.log(list.data.code);
					if (list.data.code == 0) {
						uni.$u.toast('등록이 완료되었습니다. 로그인하세요.');
						setTimeout(() => {
							uni.navigateTo({
								url: '/pages/signin/signin'
							});
						}, 1000)
					} else {
						uni.$u.toast(list.data.message);
					}
				}
			},
			
		},
		
	}
</script>

<style lang="scss">

</style>