<!-- 실시간 이체 -->
<template>
	<view>
		<view style="background: linear-gradient(to right, #2E67F6, #6492FF);" class="padding-20">

			<view class="flex">
				<u-icon name="arrow-left" color="#fff" size="22" @tap="home()" class="icon"></u-icon>
				<view class="text-center width100 color-white"
					style="height: 30px;line-height: 30px;font-size: 18px;margin-left: -20px;">출금</view>
			</view>
			<view class="margin-top-30 color-white">
				<view class="text-center font-size-14">
					출금신청
				</view>
				<view class="text-center bold margin-top-10 font-size-28">{{$util.formatNumber(userInformation.money)}}
				</view>
			</view>

			
		</view>
		<template v-if="userInformation.bank_card_info && userInformation.bank_card_info.card_sn">
			<view style="border-radius: 0 0 20px 20px;background-color: #dde4fe;padding: 20px 30px;color: #2E67F6;"
				class="flex flex-b">
				<view class="font-size-16">
					계정
				</view>
				<view class="font-size-18 bold">
					{{userInformation.bank_card_info.card_sn}}
				</view>
			</view>
		</template>

		<view class="home" style="padding: 10px 20px;">
			<view style="margin-right: -10px;padding: 30px 20px 100px 20px;">
				<view>
					<view>출금금액</view>
					<view class="margin-top-10">
						<u--input placeholder="출금 금액 입력" border="surround" v-model="value1"
							customStyle="background-color:#fff" style="height: 35px;">
							<template slot="suffix">

								<view @click="whole(userInformation.money)">전액</view>

							</template>
						</u--input>
					</view>
				</view>

				<view class="margin-top-20">
					<view>비밀번호</view>
					<view class="margin-top-10">
						<u--input placeholder="비밀번호 6자리 입력" border="surround" v-model="value2"
							customStyle="background-color:#fff" style="height: 35px;"></u--input>
					</view>
				</view>
				<view class="margin-top-30 text-center radius30 padding-10 color-white"
					style="background-color: #4f61f5;height: 30px;line-height: 30px;" @click="to_withdraw()">
					출금신청
				</view>

				<view class="guize">
					<view>1. 현재 보유주식 매도전에는 출금이 불가능합니다.</view>
					<view>2. 출금을 위해서는 실명인증 및 본인 계좌 확인 후 출금 진행이 됩니다.</view>
					<view>3. 출금 거래 가능 시간 : 평일 오전 09시 ~ 오후 18시 (*주말, 대체공휴일 출금 불가)</view>
					<view>4. 각 현금 인출의 최소 금액은 10,000단위 입니다.</view>
					<view>
						5. <text>출금 신청 후 영업일 기준 2일 이내 입금됩니다.</text>
					</view>
				</view>
			</view>

		</view>

	</view>
</template>

<script>
	export default {
		data() {
			return {
				value1: '',
				value2: '',
				value3: "",
				userInformation: ''
			};
		},
		onShow() {
			this.gaint_info()
		},
		onLoad(option) {

		},
		methods: {
			async to_withdraw() {
				uni.showLoading({
					title: "출금중이니 기다려주세요....",
					mask: true, // 显示透明蒙层，防止触摸穿透
				});
				let list = await this.$http.post('api/app/withdraw', {
					type: 1,
					total: this.value1,
					pay_pass: this.value2,
					remakes: this.value3,
				})
				// console.log(list.data.code, 'code');
				if (list.data.code == 0) {

					uni.$u.toast(list.data.message);
					setTimeout(() => {
						uni.switchTab({
							url: '/pages/my/my'
						});
						uni.hideLoading();
					}, 500)
				} else {
					uni.$u.toast(list.data.message);
				}
			},
			home() {
				uni.switchTab({
					url: '/pages/my/my'
				});
			},
			whole(money) {
				this.value1 = money
				// console.log(this.value1, '123');
			},
			//用户信息
			async gaint_info() {
				let list = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				})
				this.userInformation = list.data.data
			},


		},

	}
</script>

<style lang="scss">
	page {
		background-color: #fff;
	}

	.home {
		background-image: url(/static/chuanggai/home-top.png);
		/* 背景图片覆盖整个容器，可能会裁剪 */
		background-size: cover;
		/* 让背景图片始终位于容器的中心 */
		background-position: center;
		/* 不重复背景图片 */
		background-repeat: no-repeat;
		height: 600rpx;
		margin-left: -10px;

	}

	.guize {
		margin-top: 10px;

		view {
			padding-top: 2px;
			font-size: 12px;

			text {
				color: #ff3636;
			}
		}
	}
</style>