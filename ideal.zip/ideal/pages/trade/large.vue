<!-- 大宗交易 -->
<template>
	<view >
		<CustomHeader :title="$lang.TRADE_LARGE" @action="handleBack()"></CustomHeader>
		
		<view style="display: flex;align-items: center;justify-content:space-around;margin-bottom: 10px;">
			<view @click="handleChangeTab(0)" class="common_btn btn_primary" style="padding:2px 4px;">{{$util.BTNS_IPO[1]}}</view>
<!-- 			<view @click="handleChangeTab(1)" class="common_btn btn_secondary" style="padding:2px 4px;">{{$util.BTNS_IPO[2]}}</view> -->
		</view>
		
		<view class="common_block" style="min-height: 89vh;">
			<EmptyData v-if="list.length<=0"></EmptyData>
			<block v-for="(item,index) in list" :key="index">
				<view class="info-roe" style="margin:10px;padding-bottom: 10px;display: flex;align-items: center;">
					<view :style="{color:$util.THEME.TEXT}" style="flex:50%;">{{item.goods.name}}</view>
					<view :style="{color:$util.THEME.PRIMARY}" style="flex:30%;">
						{{$util.formatNumber(item.price)}}
					</view>
					<view class="common_btn btn_primary" style="flex:20%;transform: scale(0.75);"
						@click="handleDetail(item.id)">
						{{$lang.STOCK_DETAIL}}
					</view>
				<!-- 	<view style="display: flex; flex-direction: column; align-items: flex-start; margin-top: 10px;">
						<view >예상 수익률:{{item.expected_syl}}</view>
						<view >최소 매수금액:{{item.min_buy}}</view>
					</view> -->
				</view>
				
			<view class="info-row " style="margin-top: 10px;">
				<view >예상 수익률:{{item.expected_syl}}%</view>
				<view >최소 매수금액:{{item.min_buy}}</view>
			</view>	
			</block>
			
		</view>

		<template v-if="isShow">
			<view class="common_mask">
				<view class="common_block common_popup" style="min-height:35vh;margin:auto">
					<view class="popup_header">청약 신청 내역</view>

					<view style="display: flex;flex-wrap: nowrap;align-items: center;justify-content: space-around;">
						<text :style="{color:$util.THEME.LABEL}">{{$lang.BUY_AMOUNT}}</text>
						<text :style="{color:$util.THEME.PRIMARY}">{{$util.formatNumber(detail.price)}}</text>
					</view>
					<view class="common_input_wrapper">
						<image mode="aspectFit" src='/static/amount.png' :style="$util.calcImageSize(20)"> </image>
						<input v-model="amount" :placeholder="$lang.TIP_BUY_COUNT" type="number"></input>
					</view>

					<!-- <view class="common_input_wrapper">
						<image mode="aspectFit" src='/static/leverage.png' :style="$util.calcImageSize(20)"> </image>
						<block v-for="(item,index) in leverList" :key="index">
							<text @click="handleChgangeLever(index)" style="display: inline-block;padding:0 16px;"
								:style="{borderBottom:`2px solid ${index==current? $util.THEME.PRIMARY:'transparent'}`,color:index==current?$util.THEME.PRIMARY:$util.THEME.TEXT}">{{item.name}}</text>
						</block>
					</view> -->

					<view style="display: flex;flex-wrap: nowrap;align-items: center;justify-content: space-around;">
						<view :style="{color:$util.THEME.LABEL}">{{$lang.BUY_AMOUNT}}</view>
						<view :style="{color:$util.THEME.PRIMARY}">{{$util.formatNumber(buyAmount)}}</view>
					</view>

					<view class="common_input_wrapper">
						<image mode="aspectFit" src='/static/password.png' :style="$util.calcImageSize(20)">
						</image>
						<input v-model="password" :placeholder="$lang.TIP_BUY_PWD" type="password"></input>
					</view>

					<view style="display: flex;flex-wrap: nowrap;align-items: center;justify-content: space-around;">
						<text :style="{color:$util.THEME.LABEL}">사용 가능 잔액 </text>
						<text :style="{color:$util.THEME.PRIMARY}">{{availBal}}</text>
					</view>


					<view style="display: flex;justify-content: space-evenly;margin:20px 0;">
						<view class="common_btn btn_primary" style="width: 30%;" @click="handleConfirm"> {{$lang.BUY}} </view>
						<view class="common_btn btn_secondary" style="width: 30%;" @click="handleCancel">
							{{$lang.CANCEL}}
						</view>
					</view>
				</view>
			</view>
		</template>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		components: {
			CustomHeader,
			EmptyData,
		},
		data() {
			return {
				list: [],
				detail: {},
				isShow: false, // 显示弹层
				amount: "", // 金额
				password: '',
				leverList: [], // 杠杆值数组
				current: 0,
				availBal: 0,
			}
		},
		onShow() {
			this.getList()
			this.available()
		},
		computed: {
			curLever() {
				return this.leverList[this.current];
			},
			buyAmount() {
				return !this.curLever ? 0 : this.detail.price * this.amount / Number(this.curLever.index);
			}
		},

		methods: {
			handleBack() {
				uni.navigateBack({
					delta: 1
				});
			},
			handleChangeTab(val) {
				if (val== 0) {
					uni.navigateTo({
						url:this.$util.PAGE_URL.TRADE_LARGE_LOG
					})
				} 
			},
			handleChgangeLever(val) {
				this.current = val;
			},

			async handleDetail(id) {
				uni.showLoading({
					title: this.$lang.LOADING,
				})
				this.isShow = true;
				const result = await this.$http.get(this.$http.API_URL.TRADE_LARGE_DETAIL, {
					id
				});
				console.log('result:', result);
				this.detail = result.data.data;
				uni.hideLoading();			
			},
			handleCancel() {
				this.isShow = false;
				this.amount = "";
				this.password = "";
				this.current = 0;
			},
			handleConfirm() {
				if (this.checkForm()) {
					this.buy();
				}
			},
			checkForm() {
				if (this.amount == '') {
					uni.$u.toast(this.$lang.TIP_BUY_COUNT);
					return false;
				}
				if (this.password == '') {
					uni.$u.toast(this.$lang.TIP_BUY_PWD);
					return false;
				}
				return true;
			},
			async buy() {
				const result = await this.$http.post(this.$http.API_URL.TRADE_LARGE_ORDER, {
					id: this.detail.id,
					num: this.amount,
					pay_pass: this.password,
					ganggan: this.curLever.index,
				})
				if (result.data.code == 0) {
					uni.$u.toast(result.data.message);
					uni.navigateTo({
						url: this.$util.PAGE_URL.TRADE_LARGE_LOG
					});
				} else {
					uni.$u.toast(result.data.message);
				}
			},
			async getList() {
				uni.showLoading({
					title: this.$lang.LOADING,
				})
				const result = await this.$http.get(this.$http.API_URL.TRADE_LARGE_LIST, {})
				this.list = result.data.data
				uni.hideLoading();
			},
			async available() {
				const result = await this.$http.get(this.$http.API_URL.USER_FASTINFO, {})
				this.availBal = this.$util.formatNumber(result.data.data.money);
				this.leverList = [{
					name: 1,
					index: 1
				}, ...result.data.data.ganggan];
			},
		},
	}
</script>
<style scoped>  
.info-row {  
  display: flex;  
  flex-direction: column; /* 子元素垂直堆叠 */  
  align-items: center; /* 子元素垂直居中 */  
  justify-content: center; /* 子元素水平居中（如果需要的话） */  
  border: 1px solid #ccc; /* 添加边框 */  
  padding: 10px; /* 添加内边距，使内容不会紧贴边框 */  
}  
.info-roe {  
  /* display: flex;  */
 /* flex-direction: column; /* 子元素垂直堆叠 */  
 /* align-items: center; /* 子元素垂直居中 */  
  /*justify-content: center; /* 子元素水平居中（如果需要的话） */  
 /* border: 1px solid #ccc; /* 添加边框 */  
  padding: 10px; /* 添加内边距，使内容不会紧贴边框 */  
}  
  
.info-row > view {  
  /* 如果需要，可以为内部的view添加额外的样式 */  
  margin-bottom: 5px; /* 例如，添加一些底部间距 */  
}  
</style>