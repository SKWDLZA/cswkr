<!-- 主页 -->
<template>
	<view>
		<view class="bg_home_header">
			<Header></Header>
		</view>
		<view
			style="position: fixed;bottom: 30%;right: 5%;background-color: #4bbfe5;border-radius: 50%;width: 60px;height: 60px;align-items: center;"
			class="flex justify-center" @click="$u.route({url:$util.PAGE_URL.SERVICE});">
			<!-- <u-image></u-image> -->
			<u--image src="/static/kefu.png" shape="circle" width="50px" height="50px"></u--image>
		</view>
		<view style="margin-top: -13vh;">
			<ButtonGroup :btns="$util.BTNS_CONFIG_HOME"></ButtonGroup>

			<view class="bg_home_bnner"></view>
			<view style="padding:4px 10px;display: flex;flex-wrap: nowrap;align-items: center;margin-left: 10px;">
				<image mode="aspectFit" src="/static/stock_all.png" :style="$util.calcImageSize(24)"></image>
				<view style="padding-left: 10px; font-size: 16px;" :style="{color:$util.THEME.PRIMARY}">
					{{ $lang.STOCK_HOT}}
				</view>
				<!-- <view style="font-size: 14px;" @click="handleAllList()" :style="{color:$util.THEME.TIP}">
					{{$lang.MORE}}
					<view class="arrow rotate_45" :style="$util.calcImageSize(10)"></view>
				</view> -->
			</view>
			<GoodsList ref="goods"></GoodsList>
		</view>
	</view>
</template>

<script>
	import Header from '@/components/Header.vue';
	import ButtonGroup from '@/components/ButtonGroup.vue';
	import EmptyData from '@/components/EmptyData.vue';
	import GoodsList from '@/components/GoodsList.vue';
	export default {
		components: {
			Header,
			ButtonGroup,
			EmptyData,
			GoodsList,
		},
		data() {
			return {
				timer: null,
				page: 1,
				gp_index: 0,

			}
		},
		onShow() {
			this.startTimer();
			if (this.$refs.goods) {
				this.$refs.goods.getList();
			}
		},
		onHide() {
			clearInterval(this.timer);
		},

		// onReachBottom() {
		// 	this.page = this.page + 1;
		// 	this.$refs.goods.getList(this.page);
		// },
		onUnload() {
			uni.$off('onSuccess');
		},
		methods: {
			handleIPO() {
				uni.navigateTo({
					url: this.$util.PAGE_URL.TRADE_IPO
				});
			},
			startTimer() {
				this.timer = setInterval(() => {
					// this.$refs.free.getList();
					this.$refs.goods.getList();
				}, 3000);
			},

			// 银转证
			async silver() {
				uni.navigateTo({
					url: this.$util.PAGE_URL.SERVICE
				});
			},
		},
	}
</script>