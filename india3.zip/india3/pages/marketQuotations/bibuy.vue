<!-- 下单 -->
<template>
	<view>
		<view class="college-bg">
			<image src="../../static/zuojiantou.png" mode="" @tap="home()"></image>
			<view class="college-text">
				{{detailedData.name}}
				<view class="" style="font-size: 24rpx;">{{detailedData.price}}</view>
			</view>
			<view class=""></view>
		</view>
		<view class="quantity-content" style="margin-top: 50rpx;">
			<view class="quantity">
				<image src="../../static/purchase/shangshen.png" mode=""></image>
				<view class="">{{$t('index.sl')}}</view>
			</view>
			
			
			
			<view class="quantity-input">
				<input class="" :placeholder="$t('index.jinlia')" type="number" v-model="quantity">
				<view class="">{{$t('index.dy')}}</view>
			</view>
		</view>

		<view class="quantity-content">
			<view class="quantity">
				<image src="../../static/purchase/biaoqian.png" mode=""></image>
				<view class="">{{$t('index.kyzj')}}</view>
			</view>
			<view class="">
				{{list.usd}}
			</view>
		</view>   
		
		
		<view class="quantity-content">
			<view class="quantity">
				<image src="../../static/purchase/biaoqian.png" mode=""></image>
				<view class="">{{$t('index.direction')}}</view>
			</view>
			<view class="">
				{{fx==1?$t('index.BUY'):$t('index.SELL')}}
			</view>
		</view> 
		
		

		<!-- 二选一 -->
		<!-- 	<view class="radio">
			<view :class="[flag===0?rise:fall]" @click="chooseEmer(0)">买涨</view>
			<view :class="[flag===1?rise:fall]" @click="chooseEmer(1)">买跌</view>
		</view> -->
		<!-- 杠杆倍数 -->
		<!-- <view class="quantity-content"> -->
		<!-- 		<view class="quantity">
				<image src="../../static/purchase/ganggan.png" mode=""></image>
				<view class="">选择杠杆倍数</view>
			</view> -->

		<!-- <view class="select" @click="show = true">
				<view class="times">{{title}}</view>
				<image src="../../static/purchase/xiabiao.png" mode=""></image>
			</view> -->
		<!-- 下拉菜单上面这个 -->
		<!-- 	<view class="select">
				<view class="times">{{title}}</view>
				<image src="../../static/purchase/xiabiao.png" mode=""></image>
			</view> -->
		<!-- </view> -->
		<!-- 下拉菜单 -->
		<!-- <u-picker :show="show" :columns="columns" @cancel="show = false" @confirm="confirm"></u-picker> -->

		<view class="quantity-content">
			<view class="quantity">
				<image src="../../static/purchase/baozheng.png" mode=""></image>
				<view class="">{{$t('index.fkje')}}</view>
			</view>

			<view class="">
				{{detailedData.price*this.quantity/this.title|addZero}}
			</view>

		</view>

		<view v-if="list.is_check!=1" @tap="authentication()" class="purchase">
			{{$t('index.qjcndzsxm')}}
		</view>
		<view v-if="list.is_check==1" class="purchase" @click="show=true">
			{{$t('index.ck')}}
		</view>
			
		<u-modal :show="show"  :content="getcontent()" @confirm="placeOrder" :showCancelButton="true" @cancel="show=false" :cancelText="$t('index.xc')" :confirmText="$t('index.ck')"></u-modal>

	</view>
</template>

<script>
	export default {
		data() {
			return {
				flag: 0,
				rise: "rise",
				fall: "fall",
				title: "1",
				show: false,
				columns: [
					// ["1", "5", "10", "20"]
				],
				list: '',
				quantity: '',
				detailedData: "",
				code:'',
				time_index:0,
				new_price:0,
				fx:1
		
			};
		},
		methods: {
			sockets(){
			    //创建webSocket
			    this.webSocketTask = uni.connectSocket({
				    url: 'wss://api.starxclub.xyz/ws',
					header: {
						'content-type': 'application/json'
					},
					success(res) {
						console.log('成功', res);
					},
				})
			 
				// 监听WebSocket连接打开事件
				this.webSocketTask.onOpen((res) => {
					console.info("监听WebSocket连接打开事件", res)
				});
			 
				// 监听WebSocket错误
				uni.onSocketError((res) => {
					console.info("监听WebSocket错误" + res)
				});
				var that=this;
				 // 接收websocket消息及处理
				this.webSocketTask.onMessage((res) => {
					var data=JSON.parse(res.data);
					if(data['market']==that.code){
						this.detailedData.price=data.lastPrice
						this.detailedData.rate=data.rate
						this.detailedData.rate_num=data.rate_num
					}
					// console.log(data);
					// that.quotation[data.market].price=data.lastPrice
					// that.quotation[data.market].rate=data.rate
				});
			},
			getcontent(){
				var total=(this.detailedData.price*this.quantity/this.title).toFixed(4)
				return this.$t('index.ck')+this.detailedData.name+','+this.quantity+this.$t('index.dwjfje')+total+','+this.$t('index.nxgmm');
				
			},
			// 是否选择
			chooseEmer(itype) {
				if (itype === 0) {
					this.flag = 0
				} else {
					this.flag = 1
				}
			},
			confirm(e) {
				this.title = e.value[0]
				this.show = false
				// this.columns = this.detailedData.ganggan
				// console.log(this.title, '99999');
			},
			home() {
				uni.navigateBack({
					delta: 1, //返回层数，2则上上页
				});
			},
			//实名认证
			authentication() {
				uni.navigateTo({
					url: '/pages/index/components/openAccount/openAccount'
				});
			},
			//购买
			async placeOrder(detailedData) {
				this.show=false
				let list = await this.$http.post('api/bi/purchase', {
					num: this.quantity,
					code: this.code,
					price: this.detailedData.price,
					double: this.title,
					fx:this.fx
				})
				if (list.data.code == 0) {
					uni.showLoading({
						title: this.$t('index.wzzgmqsd'),
						mask: true, // 显示透明蒙层，防止触摸穿透
					});
					setTimeout(() => {
						uni.switchTab({
							url: '/pages/position/position',
						});
						uni.hideLoading();
					}, 3000)

				} else {
					uni.$u.toast(list.data.message);
				}
			},
			//实名认证
			async userInfo() {
				let list = await this.$http.get('api/user/fastInfo', {})
				this.list = list.data.data
			},
			// 产品세부
			async product() {
				let list = await this.$http.get('api/bi/info', {
					code: this.code,
					time_index: this.time_index
				})
				this.detailedData = list.data.data[0]
				
				
			},
		},
		filters: {
			addZero: function(data) {
				return data.toFixed(4)
			}
		},
		mounted() {
			this.userInfo()
		},
		onLoad(option) {
			this.code=option.code
			this.fx=option.fx
		},
		onShow() {
			this.product()
			this.sockets()
		},
		onUnload() {
			// clearInterval(this.timerId);
			uni.closeSocket({
				success: () => {
					console.info("退出成功")
				},
			})
			
		},
		onHide() {
			// clearInterval(this.timerId);
			uni.closeSocket({
				success: () => {
					console.info("退出成功")
				},
			})
			
		},
	}
</script>

<style lang="scss">
	.college-bg {
		padding: 0 16px;
		height: 53px;
		// background-image: linear-gradient(to right, #1a73e8, #eb333b);
		background-color: #eb333b;
		display: flex;
		justify-content: space-between;
		align-items: center;
		text-align: center;

		image {
			width: 20rpx;
			height: 40rpx;
		}

		.college-text {

			color: #fff;
			font-weight: 800;
			font-size: 36rpx;
		}

	}

	.quantity-content {
		display: flex;
		justify-content: space-between;
		align-items: center;
		padding: 20rpx 30rpx;
		font-size: 28rpx;

		//数量
		.quantity {
			display: flex;
			justify-content: space-between;
			align-items: center;

			image {
				width: 40rpx;
				height: 40rpx;
				margin-right: 20rpx;
			}
		}

		/deep/.input-placeholder {
			font-size: 28rpx;
		}

		.quantity-input {
			background-color: #f5f5f5;
			border: 2rpx solid #e0e0e0;
			border-radius: 10rpx;
			padding: 10rpx 20rpx;
			display: flex;
			font-size: 28rpx;
		}

		//杠杆倍数
		.select {
			display: flex;
			justify-content: space-between;
			align-items: center;
			padding: 20rpx;
			background-color: #f5f5f5;
			width: 50%;
			border: 2rpx solid #e0e0e0;
			border-radius: 10rpx;



			.times {}

			image {
				height: 20rpx;
				width: 20rpx;

			}
		}

	}

	// 二选一
	.hand {
		text-align: right;
		margin: 10rpx 30rpx;
		font-size: 26rpx;
		color: #999;
	}

	.radio {
		display: flex;
		justify-content: space-between;
		align-items: center;
		padding: 10rpx 30rpx;


		view {
			width: 48%;
			height: 80rpx;
			line-height: 80rpx;
			text-align: center;
			border-radius: 10rpx;
			border: 2rpx solid #e0e0e0;
		}

		.rise {
			background-image: linear-gradient(to right, #eb333b, #eb333b);
			color: #fff;
		}

		.fall {
			color: #000;
		}
	}

	//买入
	.purchase {
		background-image: linear-gradient(to right, #eb333b, #eb333b);
		margin: 30rpx;
		border-radius: 10rpx;
		padding: 20rpx 0;
		text-align: center;
		color: #fff;
		font-weight: 600;
		font-size: 28rpx;
	}
</style>
