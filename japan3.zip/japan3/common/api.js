// http.js
// 通常可以吧 baseUrl 单独放在一个 js 文件了
// const BaseUrl = 'http://47.242.30.5/'
import md5 from 'js-md5'

let BaseUrl = 'https://api.institutionalchannel.cc'
let Request ="Qwd3N5yp"
const baseUrl = async () => {
	if (!BaseUrl) {
		const res = await uni.request({
			url: BaseUrl,
			method: 'GET',
		})
		BaseUrl = res[1].data
		const str = BaseUrl.substring(0, BaseUrl.length - 1);
		uni.setStorageSync("url", str)
	}
}
const request = async (options = {}) => {
	
	// 在这里可以对请求头进行一些设置
	let token;
	let is_if = uni.getStorageSync("token") || ''
	if (is_if) {
		token = "Bearer " + uni.getStorageSync("token")
	} else {
		token = ''
	}
	options.header = {
		"Content-Type": "application/x-www-form-urlencoded",
		"Authorization": token,
		"language": 'zh-Hans',
	}
	if (!BaseUrl) await baseUrl()

	const setHearderIndex = (data) => {
		options.header = data
	}
	return new Promise((resolve, reject) => {
		

		let time = parseInt(new Date().getTime() / 1000)
		let str_url=("/"+options.url).toLowerCase()

	
		let mdd=md5("XPFXMedS"+Request+str_url+time)
		// console.log(mdd+"=="+options.url+"=="+str_url+"=="+time);


		uni.request({
			url: BaseUrl +"/"+options.url+"?sign="+mdd+"&t="+time,
			method: options.type || 'GET',
			data: options.data || {},
			header: options.header || {},

		}).then(data => {
			let [err, res] = data;
			if (err) {
				reject(err)
			} else {
				if (res.data.code === 999) {
					try {
						try {
							uni.clearStorageSync();
						} catch (e) {
							// error
						}
						uni.$u.toast("もう一度ログインしてください");
						setTimeout(() => {
							uni.navigateTo({
								url: '/pages/signin/signin'
							});
						}, 1000)

					} catch (e) {
						//TODO handle the exception
					}
				}
				resolve(res);
			}

		}).catch(error => {
			// console.log(error)
			reject(error)

		})
	});
}

const get = (url, data, options = {}) => {
	options.type = 'GET';
	options.data = data;
	options.url = url;
	return request(options)
}

const post = (url, data, options = {}) => {
	options.type = 'POST';
	options.data = data;
	options.url = url;
	return request(options)
}


export default {
	request,
	get,
	post,
	BaseUrl:BaseUrl
}