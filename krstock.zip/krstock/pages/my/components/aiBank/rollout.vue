<template>
	<view>
		<view class="college-bg">
			<image src="@/static/zuojiantou.png" mode="" @tap="home()"></image>
			<view class="college-text">잔액 전환</view>
		</view>
		<view class="flex"
			style="height: 200rpx; width: 88%;margin: 5%;padding: 1%; background-color: #f7f7f7;border-radius: 10px">
			<view class="icon">
				<image src="@/static/icon/bank.png" mode="" style="height: 60px;width: 60px;"></image>
			</view>
			<view class="title" style="font-size: 16px;">
				<span>잔액</span>
			</view>
			<view class="money" style="margin-left: 10%;">
				<span style="font-size: 12px; color: #999;">이체가능금액</span>
				<view>
					<span>{{userInformation.aiMoney}}</span>
				</view>
			</view>

		</view>
		<view class="flex"
			style="height: 200rpx; width: 88%;margin: 5%;padding: 1%; background-color: #f9fafe;border-radius: 10px;border: 1px solid #84b8fe;">
			<view class="icon">
				<image src="@/static/icon/balance.png" mode="" style="height: 60px;width: 60px;"></image>
			</view>
			<view class="title" style="font-size: 16px;">
				<span>잔액</span>
			</view>
			<view class="money" style="margin-left: 10%;">
				<span style="font-size: 12px; color: #999;">이체금액</span>
				<view>
					<input placeholder="출금액을 입력해주세요" placeholder-style="font-size:20px;color:#999;" v-model="money"
						type="number" />
				</view>
			</view>

		</view>
		<veiw class="flex flex-wrap text-center gap10" style="margin: 20px;color: #625af4;">
			<view class="flex-1 padding-20" style="background-color: #f9fafe;" @click="xx(10)">
				10%
			</view>
			<view class="flex-1 padding-20" style="background-color: #f9fafe;" @click="xx(20)">
				20%
			</view>
			<view class="flex-1 padding-20" style="background-color: #f9fafe;" @click="xx(30)">
				30%
			</view>
			<view class="flex-1 padding-20" style="background-color: #f9fafe;" @click="xx(40)">
				40%
			</view>
		</veiw>
		<veiw class="flex flex-wrap text-center gap10" style="margin: 20px;color: #625af4;">
			<view class="flex-1 padding-20" style="background-color: #f9fafe;" @click="xx(50)">
				50%
			</view>
			<view class="flex-1 padding-20" style="background-color: #f9fafe;" @click="xx(60)">
				60%
			</view>
			<view class="flex-1 padding-20" style="background-color: #f9fafe;" @click="xx(70)">
				70%
			</view>
			<view class="flex-1 padding-20" style="background-color: #f9fafe;" @click="xx(80)">
				80%
			</view>
		</veiw>
		<view class="purchase" @click="transfer">
			출금
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				money: '',
				userInformation: {},
				balance1:""
			}
		},
		onShow() {
			this.gaint_info()
		},
		methods: {
			xx(number){
				this.money=parseInt(this.balance1*number*0.01)
			},
			home() {
				uni.navigateBack()
			}, //用户信息
			async gaint_info() {
				let list = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				})
				this.balance = list.data.data.money;
				this.balance1 = list.data.data.aiMoney;
				const _fmtTotal = list.data.data.totalZichan.toString().length < 3 ? list.data.data.totalZichan : list
					.data.data.totalZichan.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
				const _fmtMoney = list.data.data.money.toString().length < 3 ? list.data.data.money : list.data.data
					.money.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
				const _fmtAiMoney = list.data.data.aiMoney.toString().length < 3 ? list.data.data.aiMoney : list.data
					.data
					.aiMoney.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
				this.userInformation = {
					...list.data.data,
					totalZichan: _fmtTotal,
					money: _fmtMoney
				}
				this.cardManagement = list.data.data.bank_card_info
			},
			async transfer() {
				if (this.money > 0) {
					let list = await this.$http.post('api/user/transfer', {
						'money': this.money,
						'type': 2
					});
					uni.showToast({
						title: list.data.message,
						icon: 'none'
					})
					let _this = this;
					setTimeout(function() {
						_this.gaint_info();
						_this.money = '';
					}, 1000)

				}

			}
		}
	}
</script>

<style lang="scss">
	.college-bg {
		padding: 60rpx 30rpx 0;
		height: 100rpx;
		// background-image: url("../../../../static/my/zijimima.png");
		background-color: #4f61f5;
		background-repeat: no-repeat;
		background-size: 100% 100%;
		display: flex;
		justify-content: space-between;
		// align-items: center;
		text-align: center;

		image {
			width: 20rpx;
			height: 40rpx;
		}

		.college-text {
			text-align: center;
			color: #fff;
			font-weight: 800;
			font-size: 36rpx;
		}

	}

	.college-content {
		border-radius: 30rpx 30rpx 0 0;
		background: #fff;
		padding: 20rpx;

		.cipher {
			padding: 20rpx;
			margin: 30rpx 0;
			background: #f5f5f5;
			border-radius: 10rpx;

		}

	}

	/deep/.uni-input-placeholder {
		color: #C0C4CC;
		font-size: 28rpx;
	}

	.purchase {
		background-color: #4f61f5;
		margin: 60rpx 30rpx;
		border-radius: 10rpx;
		padding: 20rpx 0;
		text-align: center;
		color: #fff;
		font-weight: 600;
	}

	.with-bottom-line {
		color: #1d7ed2;
	}

	.with-bottom-line::after {
		content: "";
		/* 必须设置，表示插入的内容为空 */
		display: block;
		/* 使得::after生成的元素成为块级元素 */
		border-bottom: 2px solid #1d7ed2;
		/* 添加底部横线 */
		width: 60%;
		/* 使横线宽度与父元素相同 */
		margin-top: 10px;
		/* 可选：添加一些顶部外边距 */
		text-align: center;
		margin-left: 20%;
	}
</style>