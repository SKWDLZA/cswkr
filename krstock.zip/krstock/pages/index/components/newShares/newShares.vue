<template>
	<view class="page">
		<view>
			<view class="header flex flex-b" style="background-color: #FFFFFF;box-shadow: none;" @click="home()">
				<image src="/static/zuojiantou.png" mode="aspectFit" style="width: 40rpx;height: 40rpx;"></image>
				<view class="header-center flex-1" style="color:#121212;">스마트 주문</view>
			</view>
		</view>

		<view style="display: flex;align-items: center;margin:20px;">
			<view @tap="blockReviewLog()"
				style="flex:48%;margin:10px;padding:20px;border-radius: 10px; background-image: linear-gradient(to bottom, rgba(35,65,215,0.3), rgba(35,65,215,0));text-align: center;">
				<image src="/static/ipo_left.png" mode="aspectFit" style="width: 80rpx;height: 80rpx;"></image>
				<view class="margin-top-10">구매 내역</view>
			</view>
			<view @tap="blockTransaction()"
				style="flex:48%;margin:10px;padding:20px;border-radius: 10px; background-image: linear-gradient(to bottom, rgba(0,207,125,0.3), rgba(0,207,125,0));text-align: center;">
				<image src="/static/ipo_right.png" mode="aspectFit" style="width: 80rpx;height: 80rpx;"></image>
				<view class="margin-top-10">배정 수량</view>
			</view>

		</view>

		<view v-if="current==0">
			<applyPurchase></applyPurchase>
		</view>
		<view v-if="current==1">
			<newShareRaising></newShareRaising>
		</view>
		<view v-if="current==3">
			<blockTrade></blockTrade>
		</view>
		<view v-if="current==4">
			<shortTrade></shortTrade>
		</view>
	</view>
</template>

<script>
	import applyPurchase from "../../../../components/new-shares/applyPurchase.vue";
	import newShareRaising from "../../../../components/new-shares/newShareRaising.vue";
	import shortTrade from "../../../../components/new-shares/shortTrade.vue";
	// import newBondPlacement from "../../../../components/new-shares/newBondPlacement.vue";
	import blockTrade from "../../../../components/new-shares/blockTrade.vue";
	import vipScramble from "../../../../components/new-shares/vipScramble.vue";
	export default {
		components: {
			applyPurchase,
			newShareRaising,
			// subscriptionBonds,
			// newBondPlacement,
			blockTrade,
			vipScramble,
			shortTrade,

		},
		data() {
			return {
				current: this.current,
				list: [{
						name: '청약 신청'
					}, {
						name: '청약 내역'
					},
					// {
					// 	name: '新债申购',
					// },
					// {
					// 	name: "新债配售",
					// },
					{
						name: '기관 거래 우선가',
					}, {
						name: 'VIP 우대'
					},
				],
				// newShares_list: "",
				// newShares_list2: "",

			};
		},
		onLoad(item) {
			console.log(item);
			this.current = item.index;
			// // this.newShares()
			// // this.newShares2()
			// if (item.index == 0) {
			// 	this.current = 0
			// 	// this.current = item.index;
			// }
			// if (item.index == 1) {
			// 	this.current = 1
			// 	// this.current = item.index;
			// }
			// if (item.index == 2) {
			// 	this.current = 2
			// 	// this.current = item.index;
			// }
			// // if (item.index == 3) {
			// // 	this.current = 3
			// // 	// this.current = item.index;
			// // }
			// if (item.index == 3) {
			// 	this.current = 3
			// }
			// if (item.index == 4) {
			// 	this.current = 4
			// }

		},
		methods: {
			//구독기록
			applyPurchase() {
				uni.navigateTo({
					url: '/pages/index/components/newShares/applyPurchase/applyPurchase'
				});
			},
			//우승기록
			luckyNumber() {
				uni.navigateTo({
					url: '/pages/index/components/newShares/luckyNumber/luckyNumber'
				});
			},
			blockTransaction() {
				uni.navigateTo({
					url: '/pages/index/components/newShares/blockTransactions/blockTransactions'
				});
			},
			blockReviewLog() {
				uni.navigateTo({
					url: '/pages/index/components/newShares/blockTransactions/ReviewLog'
				});
			},
			home() {
				uni.switchTab({
					url: '/pages/index/index'
				});
			},
			searchFor() {
				uni.navigateTo({
					url: '/pages/searchFor/searchFor'
				});
			},
			select(item) {
				this.current = item;
			},
			// //新股申购
			// async newShares() {
			// 	let list = await this.$http.post('api/goods-shengou/calendar', {
			// 		type: 1,
			// 	})
			// 	this.newShares_list = list.data.data
			// },
			// async newShares2() {
			// 	let list = await this.$http.post('api/goods-shengou/calendar', {
			// 		type: 2,
			// 	})
			// 	this.newShares_list2 = list.data.data
			// 	// console.log(list.data.data, '구독 예정');
			// },
		},

	}
</script>

<style lang="scss">
	uni-view,
	uni-text {
		box-sizing: border-box;
	}

	page {
		background-color: #F3F4F8;
	}

	.page {
		padding: 50px 0 0;
	}

	.header {
		height: 60px;
		background: #4f61f5;
		box-shadow: 0px 1px 4px 0px rgba(0, 0, 0, .1);
		padding: 20px 16px;
		width: 100vw;
		position: fixed;
		top: 0;
		left: 0;
		z-index: 999;

		.header-left {
			position: absolute;
			top: 18px;
			left: 16px;
			width: 10px;
			height: 18px;
		}

		.header-center {
			font-size: 16px;
			font-weight: 700;
			color: #fff;
			text-align: center;
		}
	}

	.top-a {
		background-image: url(/static/market/top1.png);
		background-repeat: no-repeat;
		background-position: center;
		background-size: 100px 33px;
		/* 不重复背景图片 */
		height: 33px;
		line-height: 28px;
		text-align: center;
		color: #fff;
		margin: 5px;
	}

	.top {
		background-color: #fff;
		color: #000;
		height: 28px;
		line-height: 28px;
		width: 70px;
		text-align: center;
		border: 1px #b6b6b6 solid;
		margin: 5px;
	}

	/* 遮罩层 */
	.overlay {

		position: fixed;
		/* Stay in place */
		top: 0;
		left: 0;
		width: 100%;
		/* Full width */
		height: 100%;
		/* Full height */
		z-index: 999;
		/* Sit on top */
		background-color: rgba(0, 0, 0, 0.5);
		/* Black background with opacity */
		cursor: pointer;
		/* Add a pointer on hover */
	}
</style>