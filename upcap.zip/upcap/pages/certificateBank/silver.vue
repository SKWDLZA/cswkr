<!-- 银转证 -->
<template>
	<view>
		<CustomHeader title="입금 정보" @action="handleBack()"></CustomHeader>
		<view
			style="padding: 10px;margin:20px 10px;background-color: #fff;border-radius: 10px;box-shadow: rgba(0, 0, 0, 0.15) 1.95px 1.95px 2.6px;">
		<view style="text-align: center; font-size: 52rpx;
		color: #4b5fcc;
		margin: 5px 0;"> {{userInformation.money}}</view>
			<view style="text-align: center;
		color: #f47b78;
		font-size: 26rpx;margin: 5px 0;">현재 사용 가능한 잔액</view>

			<view style="display: flex;justify-content:center;align-items: center;">
				<view v-for="(item,index) in items" :key="index"
					style="border-radius: 100px;height: 24px;text-align: center;line-height: 24px;width: 100px;"
					:style="{color:Inv==index?'#FFF':'#666',backgroundColor:Inv==index?'#f85252':''}"
					@click="Inv=index">{{item}} </view>
			</view>

			<view v-show="Inv == 0">
				<view
					style="display: flex;align-items: center;font-size:14px;color: #000;font-weight: 700;padding:10px;border-bottom:1px solid #ccc;margin-top: 10px;">
					<text style="flex:20%;">수취인 이름</text>
					<text style="flex:60%;text-align: center;font-weight: 500;">{{BankUser}}</text>
					<text style="flex:20%;text-align: right;" @click="copy(BankUser)">복사</text>
					<!-- <view class="duplicate" @tap="service()">客服</view> -->
				</view>
				<view
					style="display: flex;align-items: center;font-size:14px;color: #000;font-weight: 700;padding:10px;border-bottom:1px solid #ccc;margin-top: 10px;">
					<text style="flex:20%;">수취은행</text>
					<text style="flex:60%;text-align: center;font-weight: 500;" @click="service()">고객센터로 연락주세요</text>
					<text style="flex:20%;text-align: right;" @click="copy(BankName)">복사</text>
				</view>
				<view
					style="display: flex;align-items: center;font-size:14px;color: #000;font-weight: 700;padding:10px;border-bottom:1px solid #ccc;margin-top: 10px;">
					<text style="flex:20%;">미수금</text>
					<text style="flex:60%;text-align: center;font-weight: 500;">{{BankNo}}</text>
					<text style="flex:20%;text-align: right;" @click="copy(BankNo)">복사</text>
				</view>
			</view>

			<view v-show="Inv == 1">
				<view
					style="display: flex;align-items: center;font-size:14px;color: #000;font-weight: 700;padding:10px;border-bottom:1px solid #ccc;margin-top: 10px;">
					<text style="flex:20%;">수취인 이름</text>
					<text style="flex:60%;text-align: center;font-weight: 500;">{{BankUser_2}}</text>
					<text style="flex:20%;text-align: right;" @click="copy(BankUser_2)">복사</text>
				</view>
				<view
					style="display: flex;align-items: center;font-size:14px;color: #000;font-weight: 700;padding:10px;border-bottom:1px solid #ccc;margin-top: 10px;">
					<text style="flex:20%;">수취은행</text>
					<text style="flex:60%;text-align: center;font-weight: 500;" @click="service()">고객센터로 연락주세요</text>
					<text style="flex:20%;text-align: right;" @click="copy(BankName_2)">복사</text>
				</view>
				<view
					style="display: flex;align-items: center;font-size:14px;color: #000;font-weight: 700;padding:10px;border-bottom:1px solid #ccc;margin-top: 10px;">
					<text style="flex:20%;">미수금</text>
					<text style="flex:60%;text-align: center;font-weight: 500;">{{BankNO_2}}</text>
					<text style="flex:20%;text-align: right;" @click="copy(BankNO_2)">복사</text>
				</view>
			</view>
			<!-- 查看 -->
			<view
				style="display: flex;align-items: center;font-size:14px;color: #000;font-weight: 700;padding:10px;border-bottom:1px solid #ccc;margin-top: 10px;">
				<text style="flex:20%;">충전기록</text>
				<text style="flex:60%;text-align: center;font-weight: 500;"> </text>
				<text style="flex:20%;text-align: right;" @tap="capitalDetails()">내역확인</text>
			</view>

			<!-- 充值金额 -->
			<view style="display: flex;align-items: center;font-size:12px;color: #000;padding:10px;margin-top: 10px;">
				<text style="flex:20%;">충전금액</text>
				<text style="flex:60%;text-align: center;font-weight: 500;color:#ccc;">최소 충전금액은 <text
						style="color:#f85252">1000000</text>원</text>
				<text style="flex:20%;text-align: right;"></text>
			</view>

			<view class="recharge">
				<input placeholder="충전금액을 입력해주세요" type="number" v-model="value1"></input>
				<view class="select">
					<view :style="{ 'background':shadow,'color':character}" @click="quantity('1000000')">1000000
					</view>
					<view :style="{ 'background':shadow1, 'color':character1}" @click="quantity('5000000')">
						5000000
					</view>
					<view :style="{ 'background':shadow2, 'color':character2}" @click="quantity('10000000')">
						10000000
					</view>
					<view :style="{ 'background':shadow3, 'color':character3}" @click="quantity('50000000')">
						50000000
					</view>
				</view>
			</view>
<!-- 			<view style="display: flex;align-items: center;font-size:12px;color: #000;padding:10px;margin-top: 10px;">
				<text style="flex:30%;text-align: left;">인증서 업로드</text>
				<text style="flex:60%;text-align: center;font-weight: 500;color:#ccc;">인증서를 업로드하렴 클릭하세요.</text>
				<text style="flex:10%;text-align: right;"></text>
			</view> -->
			
<!-- 			<u-upload
				:fileList="fileList6"
				@afterRead="afterRead"
				@delete="deletePic"
				name="6"
				multiple
				:maxCount="1"
				width="250"
				height="150"
				style="margin:10vw;"
			>
				<image src="/static/positive.png" 
				mode="widthFix" style="width: 250px;height: 150px;"></image>
			</u-upload> -->
			
			<!-- 儲值 -->
			<view @click="to_recharge()" style="background-color:#4b5fcc;margin: 50rpx 30rpx;
					border-radius: 10rpx;
					padding: 20rpx 0;
					text-align: center;
					color: #fff;
					font-size: 28rpx;">
				재충전
			</view>
			<view style="font-size: 14px;font-weight: 700;text-align: center;">친절한 팁</view>
			<view style="padding-bottom:6px;">1.당일 거래된 자금은 2거래일 후에 인출할 수 있습니다.</view>
			<view style="padding-bottom:6px;">2.출금은 본인인증과 은행계좌 연동이 필요합니다.</view>
			<view style="padding-bottom:6px;">3.출금시간 : 거래일 9:00-15:30.</view>
			<view style="padding-bottom:6px;">4.매회 출금 금액은 10000원 이하일 수 없습니다.</view>
			<view style="padding-bottom:6px;">5.출금은 신청 후 2시간 이내에 입금됩니다.</view>
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	import {
		pathToBase64
	} from '@/common/js_sdk.js'
	export default {
		components: {
			CustomHeader
		},
		data() {
			return {
				serviceService: '보려면 고객 서비스에 문의하십시오.',
				value1: '',
				shadow: '',
				shadow1: '',
				shadow2: '',
				shadow3: '',
				character: '',
				character1: '',
				character2: '',
				character3: '',
				fileList6: [],
				userInformation: "",
				queryFunction: '',
				value3: '',
				value4: "",
				// lookOver: "",
				BankUser: '',
				BankName: '',
				BankNo: '',
				BankUser_2: '',
				BankName_2: '',
				BankNO_2: '',
				current: 0,
				list1: [{
						name: '채널 1'
					},
					{
						name: '채널 2'
					},
				],
				Inv: 0,
				items: ['채널 1', '채널 2']
			};
		},
		methods: {
			handleBack() {
				uni.switchTab({
					url: '/pages/user/user'
				});
			},
			//选项卡
			strike(item) {
				// console.log(item);
				this.current = item.index;
			},
			//选项卡
			changeTab(Inv) {
				that.navIdx = Inv;

			},
			//客服
			service() {
				uni.navigateTo({
					url: '/pages/service/service'
				});
			},
		
			//充值记录
			capitalDetails() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/my/capitalDetails?index=1'
				});
			},



			copy(value) {
				//提示模板
				if (value == '') {
					uni.$u.toast('먼저 비밀번호를 확인해 주세요');
				} else {
					uni.setClipboardData({
						data: value, //要被复制的内容
						success: () => { //复制成功的回调函数
							// console.log(value);
							uni.showToast({
								title: '성공적으로 복사되었습니다',
								duration: 2000,
								icon: 'success'
							})
						}
					});
				}

			},
			quantity(value1) {
				if (value1 == 50000) {
					this.value1 = 50000
					// this.shadow = "#ea4445";
					// this.character = "#fff";
				}
				// else if (value1 != 50000) {
				// 	this.shadow = "";
				// 	this.character = "";
				// }
				if (value1 == 100000) {
					this.value1 = 100000
					// this.shadow1 = "#ea4445";
					// this.character1 = "#fff";
				}
				// else if (value1 != 100000) {
				// 	this.shadow1 = "";
				// 	this.character1 = "";
				// }
				if (value1 == 300000) {
					this.value1 = 300000
					// this.shadow2 = "#ea4445";
					// this.character2 = "#fff";
				}
				// else if (value1 != 300000) {
				// 	this.shadow2 = "";
				// 	this.character2 = "";
				// }
				if (value1 == 500000) {
					this.value1 = 500000
					// this.shadow3 = "#ea4445";
					// this.character3 = "#fff";
				}
				// else if (value1 != 500000) {
				// 	this.shadow3 = "";
				// 	this.character3 = "";
				// }
				// if (value1 != 50000 || value1 != 100000 || value1 != 300000 || value1 != 500000) {
				// 	// this.shadow3 = "";
				// 	// this.character3 = "";
				// }
			},
			// 回调参数为包含columnIndex、value、values
			async to_recharge() {
				uni.showLoading({
					title: "충전 중입니다. 잠시 기다려 주세요....",
					mask: true, // 显示透明蒙层，防止触摸穿透
				});
				let list = await this.$http.post('api/app/recharge', {
					money: this.value1,
					type: 5,
					image: this.is_url,
					desc: this.value2,
				})

				if (list.data.code == 0) {
					uni.$u.toast(list.data.message);
					this.value2 = '';
					this.value1 = '';
					this.is_url = '';
					this.fileList6 = [];
					this.title = '은행 카드',
						setTimeout(() => {
							uni.switchTab({
								url: '/pages/user/user'
							});
							uni.hideLoading();
						}, 2000)
				} else {
					uni.$u.toast(list.data.message);
					uni.hideLoading();
					// if (list.data.message === '充值金额错误') {
					// 	uni.$u.toast('请填写充值金额金额');
					// } else if (list.data.message === '您还未实名') {
					// 	uni.$u.toast('请先实名认证');
					// 	setTimeout(() => {
					// 		uni.navigateTo({
					// 			url: '/pages/index/components/openAccount/openAccount'
					// 		});
					// 		uni.hideLoading();
					// 	}, 2000)

					// } else if (list.data.message === '请先添加银行卡信息') {
					// 	uni.$u.toast('请先添加银行卡');
					// 	setTimeout(() => {
					// 		uni.navigateTo({
					// 			url: '/pages/my/components/bankCard/renewal'
					// 		});
					// 		uni.hideLoading();
					// 	}, 2000)
					// }
					// uni.$u.toast(list.data.message);
					// if (list.data.message != '您还未实名' || '请先添加银行卡信息') {

					// }
				}
			},

			//凭证
			deletePic(event) {
				this[`fileList${event.name}`].splice(event.index, 1)
			},
			// 新增图片
			async afterRead(event) {
				// 当设置 multiple 为 true 时, file 为数组格式，否则为对象格式
				let lists = [].concat(event.file)
				let fileListLen = this[`fileList${event.name}`].length
				lists.map((item) => {
					this[`fileList${event.name}`].push({
						...item,
					})
				})
				for (let i = 0; i < lists.length; i++) {
					const result = await this.uploadFilePromise(lists[i].url)
					let item = this[`fileList${event.name}`][fileListLen]
					this[`fileList${event.name}`].splice(fileListLen, 1, Object.assign(item, {
						status: 'success',
						message: '',
						url: result
					}))
					fileListLen++
				}
			},
			//个人信息
			async gaint_info() {
				let list = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				})
				this.userInformation = list.data.data
			},
			uploadFilePromise(url) {
				// console.log(url)
				pathToBase64(url).then(base64 => {
						// 这就是转为base64格式的图片
						this.is_url = base64
						// console.log(base64)
					})
					.catch(error => {
						console.error(error)
					})
			},
			//显示银行信息
			async queryPassword() {
				let list = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				})
				this.queryFunction = list.data.data.bank_card_info
				// console.log(this.queryFunction, '收款人银行');
			},
			//点击验证
			async testVerify() {

				let list = await this.$http.get('api/app/config', {
					// language: this.$i18n.locale
				})
				this.BankUser = list.data.data[13].value
				this.BankName = list.data.data[12].value
				this.BankNo = list.data.data[9].value

				this.BankUser_2 = list.data.data[22].value
				this.BankName_2 = list.data.data[23].value
				this.BankNO_2 = list.data.data[24].value
				uni.hideLoading();


			},
		},

		onLoad(option) {
			this.gaint_info()
			this.testVerify()
		},

	}
</script>

<style lang="scss">
	//充值金额
	.recharge {
		font-size: 28rpx;

		.title {
			color: #333;
		}

		.minimum {
			color: #999;
			font-size: 26rpx;
			margin: 20rpx 0;

			text {
				color: #ffa1a1;
			}
		}

		input {
			background: #f5f5f5;
			border-radius: 10rpx;
			color: #000;
			padding: 30rpx 20rpx;
			font-size: 28rpx;
		}

		.select {
			display: flex;
			justify-content: space-between;
			align-items: center;
			margin: 30rpx 0;
			font-size: 28rpx;

			view {
				background: #f5f5f5;
				color: #999;
				border-radius: 10rpx;
				width: 23%;
				text-align: center;
				padding: 20rpx 0;
			}

			.shadow {
				background-image: linear-gradient(to right, #1a73e8, #014b8d);
			}
		}
	}
</style>