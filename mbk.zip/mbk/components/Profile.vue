<!-- 用户基本信息 -->
<template>
	<view style="padding: 10px;position: fixed;top: 6vh;width: 90%;">
		<view style="display: flex;align-items: center;padding-bottom: 10px;">
			<view style="flex:20%;text-align: center;">
				<image style="border-radius: 100px;" mode="aspectFit" :src="info.avatar?info.avatar:'/static/logo.png'" :style="$util.calcImageSize(120)"></image>
			</view>
			<view style="flex:60%;padding-left: 10px;">
				<view style="font-size: 20px;text-align: left;font-weight: 700;" :style="{color:$util.THEME.TEXT}">
					{{info.real_name}}
				</view>
				<view style="font-size: 12px;text-align: left;font-weight: 700;" :style="{color:$util.THEME.LABEL}">
					{{info.p_mobile}}
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		name: "Profile",
		props: ['info'],
		data() {
			return {
				yan_show: true
			};
		},
		methods:{
			// 提款
			handleWithDraw() {
				uni.navigateTo({
					url: this.$util.PAGE_URL.ACCOUNT_WITHDRAW
				})
			},
		}
	}
</script>

<style>

</style>