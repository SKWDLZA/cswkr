<!-- 인증서에서 은행으로 이체 -->
<template style="background: #f0f0f0;">
	<view>
		<view class="college-bg">
			<view class="account">
				<image src="../../../../static/zuojiantou.png" mode="" @tap="home()"></image>
				<view class="college-text">Withdraw</view>
				<view class=""></view>
			</view>
			<view class="progress"> {{userInformation.money}}</view>
			<view class="vacancies">Current available balance</view>
		</view>
		
		<view class="cash-withdrawal">
			<view class="withdrawal">Withdrawal account</view>
			<view class="money">
				<input  v-model="userInformation.bank_card_info.card_sn" disabled=""></input>
			</view>
		</view>
		
		<view class="cash-withdrawal">
			<view class="withdrawal">Withdrawal amount</view>
			<view class="money">
				<input placeholder="" v-model="value1"></input>
				<view class="" @click="whole(userInformation.money)">Max</view>
			</view>
		</view>
		<view class="cash-withdrawal">
			<view class="withdrawal">password</view>
			<view class="money">
				<input placeholder="" type="password" v-model="value2"></input>
			</view>
		</view>
		<!-- view class="cash-withdrawal">
			<view class="withdrawal">Bank name</view>
			<view class="money">
				<input placeholder="Please enter your bank name" type="text" v-model="value3"></input>
			</view>
		</view> -->
		<view class="purchase" @click="to_withdraw()">Confirm withdrawal</view>

		<view class="point-out">
			<view>1.Currently there is a position order, so withdrawal is not available</view>
			<view>2.The withdrawal request is automatically directed to the bank account previously verified with real-name authentication before being transferred to the trading account. It is essential that the bank account holder matches the trading account holder, and transfers to accounts held by others are not permitted. The company disclaims any responsibility for any loss of funds.</view>
			<view>3. Withdrawal times are 9:30 am to 11:30 am and 1:00 pm to 3:00 pm on stock trading days.</view>
			<view>4. The minimum amount of each cash withdrawal is 2000 INR</view>
			<view>
				5.<text>During the withdrawal period, withdrawals generally arrive within 2 hours, and the withdrawal time varies depending on the interbank settlement time. The arrival time at each bank is different, and the latest arrival time is T+1 before 24:00 the next day.</text>
			</view>
		</view>



	</view>
</template>

<script>
	export default {
		data() {
			return {
				value1: '',
				value2: '',
				value3: "",
				userInformation: ''
			};
		},
		methods: {
			async to_withdraw() {
				uni.showLoading({
					title: "Withdrawal is in progress, so please wait....",
					mask: true, // 显示透明蒙层，防止触摸穿透
				});
				let list = await this.$http.post('api/app/withdraw', {
					type: 1,
					total: this.value1,
					pay_pass: this.value2,
					remakes: this.value3,
				})
				// console.log(list.data.code, 'code');
				if (list.data.code == 0) {

					uni.$u.toast(list.data.message);
					setTimeout(() => {
						uni.switchTab({
							url: '/pages/my/my'
						});
						uni.hideLoading();
					}, 500)
				} else {
					uni.$u.toast(list.data.message);
					// uni.navigateTo({
					// 	url: '/pages/my/components/bankCard/renewal',
						
					// });
				}
			},
			home() {
				uni.switchTab({
					url: '/pages/my/my'
				});
			},
			whole(money) {
				this.value1 = money
				// console.log(this.value1, '123');
			},
			//用户信息
			async gaint_info() {
				let list = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				})
				this.userInformation = list.data.data
			},
			

		},
		onShow() {
			this.gaint_info()
		},
		onLoad(option) {
			
		}
	}
</script>

<style lang="scss">
	.college-bg {
		padding: 60rpx 30rpx 0;
		height: 280rpx;
		background-image: linear-gradient(to right, #1a73e8, #5ef7d1);

		.account {
			display: flex;
			text-align: center;
			justify-content: space-between;
			align-items: center;

			image {
				width: 20rpx;
				height: 40rpx;

			}

			.college-text {

				color: #fff;
				font-weight: 800;
				font-size: 36rpx;
			}
		}

		.progress {
			text-align: center;
			font-size: 52rpx;
			color: #fff;
			// font-weight: 600;
			margin: 60rpx 0 10rpx;
		}

		.vacancies {
			text-align: center;
			color: #ffffff;
			font-size: 26rpx;
		}
	}

	.cash-withdrawal {
		border-radius: 30rpx 30rpx 0 0;
		margin-top: -30rpx;
		background: #fff;
		padding: 30rpx;
		font-size: 28rpx;

		.withdrawal {
			color: #333;
		}

		.money {
			display: flex;
			justify-content: space-between;
			align-items: center;
			background: #f5f5f5;
			padding: 30rpx;
			margin: 20rpx 0;
			border-radius: 10rpx;

			input {
				font-size: 28rpx;
			}

		}
	}

	.purchase {
		background-image: linear-gradient(to right, #1a73e8, #014b8d);
		margin: 30rpx;
		border-radius: 10rpx;
		padding: 20rpx 0;
		text-align: center;
		color: #fff;
		font-weight: 600;
		font-size: 30rpx;
	}

	.point-out {
		margin: 30rpx;
		color: #666;
		font-size: 28rpx;

		text {
			color: #cb1a1e;
		}
	}
</style>