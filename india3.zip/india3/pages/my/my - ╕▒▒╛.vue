<template>
	<view>
		<!-- <view style="position: relative;top: 80rpx;">
			<view style="position: absolute;left: 25%;transform: translate(-50%, -50%);color:#fff ;font-size: 22px;font-weight: 700;">
				东兴证券综合账户
			</view>
		</view> -->
		<view class="head-background">
			
			<view class="toux display">
				<view class="tl display">
					<!-- <image src="../../static/grzx.png" mode=""></image> -->
					<u-avatar size='60' :src="userInformation.avatar" shape="circle"></u-avatar>
					<view class="attestation">
						<view class="">{{userInformation.p_mobile}}
						</view>
						<view class="certification-icon display" v-if="userInformation.is_check==-1">
							<image src="../../static/renzheng.png" mode=""></image>
							<view class="" @tap="notCertified()">인증되지 않음</view>
							<image class="you" src="../../static/jiantou.png" mode=""></image>
						</view>
						<view class="certification-icon display" v-if="userInformation.is_check==0">
							<image src="../../static/renzheng.png" mode=""></image>
							<view class="" @tap="notCertified()">검토중</view>
							<image class="you" src="../../static/jiantou.png" mode=""></image>
						</view>
						<view class="certification-icon display" v-if="userInformation.is_check==2">
							<image src="../../static/renzheng.png" mode=""></image>
							<view class="" @tap="notCertified()">실패했습니다. 다시 인증해 주세요.</view>
							<image class="you" src="../../static/jiantou.png" mode=""></image>
						</view>

						<!-- 这是认证成功的 -->
						<view class="certification-icon success" v-if="userInformation.is_check==1">
							<image src="../../static/renzheng2.png" mode=""></image>
							<view class=""> 검증됨</view>
						</view>
					</view>
				</view>
				<view class="set-up" @tap="setUp(userInformation.mobile,userInformation.avatar)">
					<image src="../../static/shezhi.png" mode=""></image>
				</view>
			</view>
		</view>

		
		<view class="press">
			<view class="bank-to-securities"
				@click="silver(userInformation.money,userInformation.bank_card_info,userInformation.idno)">
				<text>은행 송금 증명서</text>
			</view>
			<view class="certificate-to-bank" @tap="prove(userInformation.money)">
				<text>인증서에서 은행으로 이체</text>
			</view>
		</view>
		<view class="tile">
			공통 기능
		</view>
		<view class="common-use">
			<view class="" @tap="changePassword()">
				<image src="../../static/my/11.png" mode=""></image>
				<view class="">
					비밀번호 변경
				</view>
			</view>
			<view class="" @tap="fundPassword()">
				<image src="../../static/my/22.png" mode=""></image>
				<view class="">
					펀드 비밀번호
				</view>
			</view>
			<view class="" @tap="capitalDetails()">
				<image src="../../static/my/33.png" mode=""></image>
				<view class="">
				자본 흐름
				</view>
			</view>
		
			<view class="">
				<view class="" v-if="cardManagement==null" @tap="manages()">
					<image src="../../static/my/yinhangka.png" mode=""></image>
					<view class="">
						카드 관리
					</view>
				</view>
				<view class="" v-if="cardManagement!=null"
					@tap="manage(cardManagement.bank_name,cardManagement.bank_sub_name,cardManagement.card_sn)">
					<image src="../../static/my/yinhangka.png" mode=""></image>
					<view class="">
						카드 관리
					</view>
				</view>
			</view>
		</view>
		<view class="tile">
			기타 기능
		</view>

		<view class="ganh">
			<view class="renew" @tap="Update()">
				<view class="version-update">
					<view class="renew-img">
						<image class="" src="../../static/my/111.png" mode=""></image>
					</view>
					<view>새 버전 업데이트</view>
				</view>
				<view class="right-side">
					<image src="../../static/jiantou.png" mode=""></image>
				</view>
			</view>
		
			<view class="thread"></view>
			<view class="renew" @tap="privacyAgreement()">
				<view class="version-update">
					<view class="renew-img">
						<image class="" src="../../static/my/333.png" mode=""></image>
					</view>
					<view>개인 정보 보호 계약</view>
				</view>
				<view class="right-side">
					<image src="../../static/jiantou.png" mode=""></image>
				</view>
			</view>
			<view class="thread"></view>
			<view class="renew" @tap="aboutUs()">
				<view class="version-update">
					<view class="renew-img">
						<image class="" src="../../static/my/444.png" mode=""></image>
					</view>
					<view>회사 소개</view>
				</view>
				<view class="right-side">
					<image src="../../static/jiantou.png" mode=""></image>
				</view>
			</view>
			<view class="thread"></view>
		</view>

		<view style="background: #fff;height: 20rpx;">

		</view>
	</view>
</template>

<script>
	// import annular from "./components/annular/annular.vue"
	export default {
		
		data() {
			return {
				//是否更新
				// updateFlag: false,
				// //每次版本更新都要修改
				// version: '2.1',
				// popupshow: true,
				downloadUrl: '',
				updateDesc: "",
				update: '',
				closeOnClickOverlay: false,
				//手机号
				tel: '',
				userInformation: '',
				is_check: '',
				cardManagement: '',
				item: '',
			}
		},
		onShow() {
			this.phoneNumShow()
		},
		//下拉刷新
		onPullDownRefresh() {
			uni.showLoading({
				title: '로드 중',
			});
			//关闭加载提示
			setTimeout(() => {
				uni.hideLoading();
			}, 1000);
			this.gaint_info()
			uni.stopPullDownRefresh()
		},

		methods: {
			//客服
			customer() {
				uni.navigateTo({
					url: '/pages/index/components/customer/customer'
				});
			},
			//隐藏手机号
			phoneNumShow() {
				let that = this;
				let number = this.tel; //获取到手机号码字段
				let mphone = number.substring(0, 3) + '****' + number.substring(7);
				that.tel = mphone
			},
			// 跳转到设置
			setUp(mobile, avatar) {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的设置
					url: '/pages/my/components/setUp/setUp'
					// url: '/pages/my/components/setUp/setUp' + `?mobile=${mobile}&avatar=${avatar}`
				});

			},
			// 银转证
			silver(money, bank_card_info, idno) {
				if (bank_card_info && idno !== null) {
					uni.navigateTo({
						//保留当前页面，跳转到应用内的某个页面
						url: '/pages/my/components/certificateBank/silver' + `?money=${money}`
					});
				} else if (bank_card_info == null) {
					uni.$u.toast('은행 카드에 묶여 있지 않음');
					setTimeout(() => {
						uni.navigateTo({
							//保留当前页面，跳转到应用内的某个页面
							url: '/pages/my/components/bankCard/renewal'
						});
					}, 2000)
				} else if (idno == null) {
					uni.$u.toast('실명인증 불가');
					setTimeout(() => {
						uni.navigateTo({
							//保留当前页面，跳转到应用内的某个页面
							url: '/pages/index/components/openAccount/openAccount'
						});
					}, 2000)
				}

			},
			// 인증서에서 은행으로 이체
			prove(money) {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/my/components/certificateBank/prove' + `?money=${money}`
				});
			},
			//修改密码
			changePassword() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/my/components/commonFunctions/changePassword'
				});
			},
			//펀드 비밀번호
			fundPassword() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/my/components/commonFunctions/fundPassword'
				});
			},
			//资金流水
			capitalDetails() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/my/components/commonFunctions/capitalDetails?index=0'
				});
			},
			// 卡管理
			manage(bank_name, bank_sub_name, card_sn) {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/my/components/bankCard/binding' +
						`?bank_name=${bank_name}&bank_sub_name=${bank_sub_name}&card_sn=${card_sn}`
				});
				// console.log(bank_name, '22222');
			},
			manages() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/my/components/bankCard/renewal'
				});
			},
			//版本更新
			Update() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/my/components/other/versionUpdate'
				});
			},
			//用户协议
			userAgreement() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/my/components/other/userAgreement'
				});
			},
			//隐私协议
			privacyAgreement() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/my/components/other/privacyAgreement'
				});
			},

			//关于我们
			aboutUs() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/my/components/other/aboutUs'
				});
			},
			//实名认证
			notCertified() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/index/components/openAccount/openAccount'
				});
			},


			//用户信息
			async gaint_info() {
				let list = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				})
				this.userInformation = list.data.data
				this.cardManagement = list.data.data.bank_card_info
			},

			//版本更新
			is_token() {
				let token = uni.getStorageSync('token') || '';
			},
			async versionUpdate() {
				let list = await this.$http.get('api/version/detail', {})
				this.update = list.data.data
				let version = list.data.data.version
				let old_version = uni.getStorageSync('version') || 1.0
				// console.log(old_version, '当前版本111111111111111');
				if (old_version < version) {
					this.updateFlag = true
					this.$refs.update.upgrade()
					uni.setStorageSync('version', version)
				}
				// console.log(list.data.data, '版本更新');
			},

		},
		
		onShow() {
			this.gaint_info()
			this.versionUpdate()
			this.is_token()
		},

	}
</script>kk

<style lang="scss">
	// 封装display
	.display {
		display: flex;
		justify-content: space-between;
		align-items: center;
	}

	.head-background {
		// background-image: url('../../static/bjing.b7cbcd97.png');
		background-image: linear-gradient(to right, #1a73e8, #014b8d);
		width: 100%;
		height: 300rpx;
		background-size: 100%;
		margin: 0 auto;
		z-index: -1;
		padding: 20rpx 0 0;
		
		.nav-slot {
			display: flex;
			justify-content: space-between;
			align-items: center;
			margin: 20rpx 30rpx;

			image {
				width: 50rpx;
				height: 50rpx;
				margin-top: 10rpx;
				margin-right: 30rpx;
			}

			.ziti {
				width: 280rpx;
				height: 50rpx;
				margin-left: 30rpx;

				image {
					width: 100%;
					height: 100%;
				}
			}

		}

		.toux {
			padding: 80rpx 60rpx;

			.tl {
				image {
					width: 120rpx;
					height: 120rpx;

				}
			}

			.attestation {
				margin-left: 40rpx;
				color: #fff;

				.success {
					display: flex;
					justify-content: center;
					align-items: center;
				}

				.certification-icon {
					margin-top: 20rpx;
					padding: 4rpx 10rpx;
					background: #90bae7;
					border-radius: 40rpx;
					font-size: 28rpx;


					image {
						width: 30rpx;
						height: 30rpx;
						margin: 0;
					}

					view {
						margin: 0 10rpx;
					}

					.you {
						width: 20rpx;
						height: 20rpx;
					}
				}
			}

			.set-up {
				image {
					width: 40rpx;
					height: 40rpx;
				}
			}
		}
	}


	//总资产
	.total-assets {
		box-shadow: 0 2rpx 2rpx 0 #e3e3e3;
		background: #fff;
		border-radius: 20rpx;
		margin: -100rpx 30rpx 0rpx;
		// display: flex;
		// justify-content: space-between;
		flex-wrap: wrap;
		align-items: center;
		padding: 30rpx;

		.account {
			// border: 20rpx solid #ea3544;
			border-radius: 30rpx;
			padding: 60rpx;
			margin: 30rpx;
			text-align: center;

			.assets-money {
				color: #ea3544;
				font-size: 46rpx;
				font-weight: 800;
			}

			.assets-text {
				color: #999;
				font-size: 28rpx;
			}
		}


		.fund {
			display: flex;
			flex-wrap: wrap;
			justify-content: space-around;
			align-items: center;
			margin: 30rpx 0;

			.hushen {
				width: 45%;
				font-size: 28rpx;

				image {
					width: 30rpx;
					height: 30rpx;
					margin-right: 10rpx;
				}

				.money {
					margin-left: 30rpx;
					color: #ea3544;
					font-size: 28rpx;
					margin-bottom: 20rpx;
					font-weight: 700;

				}
			}

		}

	}

	.press {
		// width: 100%;
		// box-shadow: 0rpx 2rpx 2rpx 2rpx #cfcfcf;
		margin: 30rpx 10rpx;
		padding: 10rpx 20rpx;
		border-radius: 10px;

		.bank-to-securities {
			padding: 24rpx 0;
			// width: 48%;
			// background: linear-gradient(to left, #4CA1AF, #C4E0E5);
			background: #045097;

			border-radius: 10rpx;
			color: #fff;
			flex-wrap: 800;
			font-size: 30rpx;
			text-align: center;
			margin: 30rpx 0;
			box-shadow: 0rpx 2rpx 2rpx 2rpx #e3e3e3;
		}

		.certificate-to-bank {
			padding: 24rpx 0;
			// width: 48%;
			// background: linear-gradient(to left, #f85252, #d5aeb3);
			background: #ea3544;
			border-radius: 10rpx;
			color: #fff;
			flex-wrap: 800;
			font-size: 30rpx;
			text-align: center;
			margin: 30rpx 0;
			box-shadow: 0rpx 2rpx 2rpx 2rpx #e3e3e3;
		}
	}

	.tile {
		margin: 30rpx;
	}

	.common-use {
		display: flex;
		justify-content: space-around;
		align-items: center;
		text-align: center;
		background: #fff;
		box-shadow: 0rpx 2rpx 2rpx 2rpx #f4f4f4;
		border-radius: 10px;
		// border: 1rpx solid #cfcfcf;
		margin: 30rpx;
		padding: 40rpx 20rpx;
		font-size: 28rpx;

		image {
			width: 60rpx;
			height: 60rpx;

		}
	}

	.card {
		display: flex;
		justify-content: space-between;
		align-items: center;
		margin: 60rpx 30rpx;

		image {
			width: 20rpx;
			height: 20rpx;
			margin-left: 10rpx;
		}
	}

	//线
	.thread {
		height: 1rpx;
		width: 100%;
		background: #e0e0e0;
	}

	.ganh {
		background: #fff;
		box-shadow: 0rpx 2rpx 2rpx 2rpx #f4f4f4;
		border-radius: 10px;
		margin: 30rpx;
		font-size: 28rpx;

		.renew {
			display: flex;
			justify-content: space-between;
			align-items: center;
			padding: 20rpx;

			.version-update {
				display: flex;
				justify-content: flex-start;
				align-items: center;
			}

			.renew-img {
				margin: 10rpx 10rpx 0 0;

				image {
					width: 40rpx;
					height: 40rpx;
				}


			}

			.right-side {
				image {
					width: 20rpx;
					height: 20rpx;
				}
			}

		}


	}
</style>