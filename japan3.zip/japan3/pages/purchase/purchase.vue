<!-- 下单 -->
<template>
	<view>
		<CustomHeader :title="detailedData.name" @action="$u.route({type:'navigateBack'});"></CustomHeader>
		<view class="common_block" style="padding: 6px;">
			<view style="display: flex;align-items: center;justify-content: space-around;">
				<text style="color: #4b5fcc;padding: 5px;border-radius: 10px;font-weight: 700;font-size: 20px;">
					{{$t('index.gffh')}}</text>
				<text style="padding: 5px;border-radius: 10px;font-weight: 700;font-size: 20px;"
					:style="{color:$util.THEME.PRIMARY_COLOR}">
					{{$util.formatNumber(userinfo.money)}}円</text>
			</view>
		</view>

		<view class="common_block" style="padding: 6px 16px;" v-if="detailedData">
			<view style="margin: 0 -20px;display: flex;align-items: center;">
				<view style="border-radius: 0 16rpx 16rpx 0;width: 5px;height: 30px;background-color: #283480;margin-left: 5px;"></view>
				<view style="flex:50%;">{{detailedData.name}}</view>
				<view style="flex:15%;"> {{$util.formatNumber(detailedData.current_price)}} </view>
				<view :class="detailedData.rate>0?'red':'green'" style="flex:15%;">{{detailedData.rate}}%</view>
			</view>

			<view class="margin-top-20 bold">
				{{$t('index.sl')}}
			</view>
			<view class="margin-top-10 text-center">


				<u-row justify="space-between" gutter="10">
					<u-col span="4">
						<view :class="quantity==50?'actity':'noactity'" @click="quantity=50;quantity1=''">50</view>
					</u-col>
					<u-col span="4">
						<view :class="quantity==100?'actity':'noactity'" @click="quantity=100;quantity1=''">100
						</view>
					</u-col>
					<u-col span="4">
						<view :class="quantity==150?'actity':'noactity'" @click="quantity=150;quantity1=''">150
						</view>
					</u-col>

				</u-row>
				<u-row justify="space-between" gutter="10">
					<u-col span="4">
						<view :class="quantity==200?'actity':'noactity'" @click="quantity=200;quantity1=''">200
						</view>
					</u-col>
					<u-col span="4">
						<view :class="quantity==250?'actity':'noactity'" @click="quantity=250;quantity1=''">250
						</view>
					</u-col>
					<u-col span="4">
						<view :class="quantity==300?'actity':'noactity'" @click="quantity=300;quantity1=''">300
						</view>
					</u-col>

				</u-row>
			</view>
			<input :placeholder="$t('index.qsrgmsl')" type="number" class="f-dis-input" v-model="quantity1" @input="sl_input" />

			<!-- <view class="margin-top-20 bold">
				{{$t('index.ooop')}}
			</view> -->
			<view class="margin-top-10 text-center">


				<!-- <u-grid :border="false" col="3">
					<u-grid-item v-for="(item,index) in userinfo.ganggan">
						<view style="width: 90%;" :class="ganggan==item?'actity':'noactity'" @click="ganggan=item">
							{{item}}
						</view>
					</u-grid-item>
				</u-grid> -->


			</view>
			<!-- <view class="flex" style="color: #7a7a7a;font-size: 28rpx;">
				<view class="flex-1">{{$t('index.fkje')}}</view>
				<view class="flex-2 text-right"><text
						v-if="detailedData.project_type_id==2">$</text>{{detailedData.current_price*this.quantity/this.ganggan|addZero}}
				</view>
			</view>
			<view class="flex" style="color: #7a7a7a;font-size: 28rpx;">
				<view class="flex-1">{{$t('index.gmfy')}}</view>
				<view class="flex-2 text-right"><text
						v-if="detailedData.project_type_id==2">$</text>{{detailedData.current_price*this.quantity/this.ganggan*0.0015|addZero}}
				</view>
			</view> -->

			<view class="purchase" @click="placeOrder()" style="background-color: #4b5fcc;">
				{{$t('index.BUY')}}
			</view>
		</view>


		<u-picker :show="show" :columns="columns" @cancel="show = false" @confirm="confirm" :cancelText="$t('index.xc')" :confirmText="$t('index.qrtx')"></u-picker>


	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	var flag = false;
	export default {
		components: {
			CustomHeader
		},
		data() {
			return {
				flag: 0,
				rise: "rise",
				fall: "fall",
				title: "1",
				show: false,
				columns: [
					// ["1", "5", "10", "20"]
				],
				list: '',
				quantity: '50',
				detailedData: "",
				quantity1: "",
				ganggan: 1,
				userinfo: ''
			};
		},
		methods: {
			sl_input(e) {
				console.log(e.detail.value);
				this.quantity = e.detail.value
			},
			// 是否选择
			chooseEmer(itype) {
				if (itype === 0) {
					this.flag = 0
				} else {
					this.flag = 1
				}
			},
			confirm(e) {
				this.title = e.value[0]
				this.show = false
				// this.columns = this.detailedData.ganggan
				// console.log(this.title, '99999');
			},
			home() {
				uni.navigateBack({
					delta: 1, //返回层数，2则上上页
				});
			},
			// 产品详情
			async product(code) {
				let list = await this.$http.get('api/product/info', {
					code: code,
				})
				this.list = list
				this.detailedData = list.data.data[0]
			},
			//购买
			placeOrder() {
				if (flag) return;

				let money = (this.detailedData.current_price * this.quantity * 1).toString().replace(
					/\B(?=(\d{3})+(?!\d))/g, ",")
				uni.showModal({
					title:  this.$t('index.Purchase_Success'),
					content: this.detailedData.name + ' ' + this.quantity.toString().replace(
						/\B(?=(\d{3})+(?!\d))/g, ",") + "支払金額 " + money + "円",
					cancelText: this.$t('index.xc'), // 取消按钮的文字
					confirmText: this.$t('index.qrtx'), // 确认按钮的文字
					showCancel: true, // 是否显示取消按钮，默认为 true
					confirmColor: '#f55850',
					cancelColor: '#39B54A',
					success: (res) => {
						if (res.confirm) {
							console.log('comfirm') //点击确定之后执行的代码
							this.buy()
						} else {
							console.log('cancel') //点击取消之后执行的代码
						}
					}
				})
			},
			buy() {
				flag = true;
				uni.showLoading({
					mask: true, // 显示透明蒙层，防止触摸穿透
				});
				this.$http.post('api/product/purchase', {
					num: this.quantity || 0,
					gid: this.detailedData.gid,
					price: this.detailedData.current_price,
					ganggan: this.ganggan
				}).then(res => {
					flag = false;
					uni.hideLoading();
					if (res.data.code == 0) {
						uni.$u.toast(res.data.data.message);
						setTimeout(() => {
							uni.switchTab({
								url: '/pages/position/position',
							});
						}, 1000)
					} else {
						uni.$u.toast(res.data.message);
					}
					setTimeout(() => {
						flag = false;
					}, 2000)
				}).catch(er => {
					setTimeout(() => {
						flag = false;
					}, 2000)
				})
			},
			//实名认证
			async userInfo() {
				let list = await this.$http.get('api/user/info', {})


				this.userinfo = list.data.data
			},
		},
		filters: {
			addZero: function(data) {
				return data.toFixed(0).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")
			}
		},
		mounted() {
			this.userInfo()
		},
		onLoad(option) {
			this.product(option.code)
			// const item = JSON.parse(decodeURIComponent(option.item));
			// this.objData = item;
			// this.columns = [item.ganggan]
			// const productDetails = JSON.parse(decodeURIComponent(option.productDetails));
			// this.detailedData = productDetails
			// this.columns = [productDetails.ganggan]

		}
	}
</script>

<style lang="scss">
	.page {
		min-height: 100vh;
		background-color: #F3F4F8;
	}

	.gp_type {
		position: fixed;
		top: 220rpx;
		background-color: #ed4344;
		color: #fff;
		width: 80rpx;
		padding: 14rpx;
		right: 40rpx;
		text-align: center;
	}

	.purchase {
		width: 90%;
		height: 80rpx;
		border-radius: 20rpx;
		font-weight: 700;
		color: #fff;
		font-size: 40rpx;
		display: flex;
		align-items: center;
		justify-content: center;
		margin: 40rpx 5%;
	}

	.actity {
		background-color: #fef6e6;
		color: #f71f27;
		font-weight: 700;
		height: 80rpx;
		line-height: 80rpx;
		text-align: center;
		margin-bottom: 20rpx;
	}

	.noactity {
		background-color: #fff;
		color: #979898;
		border: 1px solid #f1f5f9;
		height: 80rpx;
		line-height: 80rpx;
		text-align: center;
		margin-bottom: 20rpx;
	}

	.f-dis-input {
		padding: 26rpx 24rpx;
		background: #f6f6f6;
		border-radius: 10rpx;
		color: #262626;
		font-size: 32rpx;
	}

	.yue {
		margin: 10px 20px;
		color: #fff;
		font-size: 56rpx;
		font-weight: 700;
	}
</style>