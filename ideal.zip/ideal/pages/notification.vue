<template>
	<view :style="{height:`${ $util.calcPageHeight()}px`}">
		<CustomHeader title="알림" @action="$u.route({type:'navigateBack'})"></CustomHeader>
		<view class="common_block" style="height: 92vh;margin:0 20px 20px 20px;">
			<view
				style="width: 100%;display:flex;flex-direction: column;justify-items: center;align-items: center;padding: 23vh 0;">
				<u-image src="/static/email.png" width="411px" mode="aspectFit"></u-image>
				<view style="font-size: 14px;padding-top:30px;text-align: center;"
					 :style="{color:$util.THEME.LABEL}">메시지 없음</view>
			</view>
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components: {
			CustomHeader,
		},
	}
</script>