<template>
	<view>
		<Header></Header>

		<view style="margin-top: 10px;">
			<TradeInfo :info="userInfo"></TradeInfo>
		</view>

		<view class="common_block" style="margin-top: 20px;padding:10px;">
			<view
				style="display: flex;align-items: center;justify-content:space-between;font-size: 16px;padding: 10px;font-weight: 700;">
				<image mode="aspectFit" src="/static/refresh.png" :style="$util.calcImageSize(20)"
					@click="handleRefresh()">
					<view :style="{color:isHold? $util.THEME.PRIMARY:$util.THEME.TEXT}" @click="handleChangeList(0)">
						{{$lang.STOCK_HOLD_STATUS}}
					</view>
					<view :style="{color:!isHold? $util.THEME.PRIMARY:$util.THEME.TEXT}" @click="handleChangeList(1)">
						{{$lang.STOCK_SALES_HISTORY}}
					</view>
				</image>
				<view>
					<view style="display: inline-block;padding-right:6px;"
						:style="{color:isSelf? $util.THEME.PRIMARY:$util.THEME.TEXT}" @click="handleChangeLocation(0)">
						{{$lang.STOCK_COUNTRY_SELF}}
					</view>
					<view style="display: inline-block;" :style="{color:!isSelf? $util.THEME.PRIMARY:$util.THEME.TEXT}"
						@click="handleChangeLocation(1)">
						{{$lang.STOCK_COUNTRY_OTHER}}
					</view>
				</view>
			</view>

			<view style="display: flex;align-items: center;" :style="{color:$util.THEME.LABEL}">
				<view style="flex:25%;margin:0 2px;border: 2px solid #c2dbf4;padding:2px;">
					<view> 종목명</view>
					<view> 구분 </view>
				</view>
				<view style="flex:25%;margin:0 2px;border: 2px solid #c2dbf4;padding: 2px;">
					<view> 평가손익</view>
					<view> 수익률 </view>
				</view>
				<view style="flex:25%;margin:0 2px;border: 2px solid #c2dbf4;padding: 2px;">
					<view> 잔고수량</view>
					<view> 평가금액 </view>
				</view>
				<view style="flex:25%;margin:0 2px;border: 2px solid #c2dbf4;padding: 2px;">
					<view> 평균매입가</view>
					<view>매도가</view>
				</view>
			</view>

			<view>
				<block v-for="(item,index) in list" :key="index">
					<view @tap="handleShowModal(item)"
						style="display: flex;align-items: center;padding:10px 0;border-bottom: 1px solid #ccc;">
						<view style="flex:25%;">
							<view :style="{color:$util.THEME.LABEL}"> {{item.goods_info.name}}</view>
							<!-- <view :style="{color:$util.THEME.TEXT}"> {{item.goods_info.number_code}}</view> -->
						</view>
						<view style="flex:25%;text-align: right;">
							<template v-if="isHold">
								<view :style="$util.calcStyleRiseFall(item.order_buy.float_yingkui>0)">
									{{$util.formatNumber(item.order_buy.yingkui)}}
								</view>
								<view :style="{color:$util.THEME.TEXT}">
									<!-- 持仓盈利率 =（最终价 - 买入价） / 买入价 *100% -->
									{{$util.formatNumber(((item.goods_info.current_price*1-item.order_buy.price*1)/item.order_buy.price*100),2)}}%
								</view>
							</template>
							<template v-else>
								<view :style="$util.calcStyleRiseFall(item.order_sell.yingkui>0)">
									{{$util.formatNumber(item.order_sell.yingkui)}}
								</view>
								<view :style="{color:$util.THEME.TEXT}">
									<!-- 买入，卖出，盈利率计算： 盈利比=（卖出价 - 买入价） / 买入价 *100% -->
									{{$util.formatNumber(((item.order_sell.price*1-item.order_buy.price*1)/item.order_buy.price*100),2)}}%
								</view>
							</template>
						</view>
						<view style="flex:25%;text-align: right;" :style="{color:$util.THEME.TEXT}">
							<view> {{$util.formatNumber(item.order_buy.num)}}</view>
							<!-- <view>{{$util.formatNumber(item.goods_info.current_price*1*item.order_buy.num)}}</view> -->
							<template v-if="isHold">
								<view>
									{{$util.formatNumber(item.goods_info.current_price*1*item.order_buy.num)}}
								</view>
							</template>
							<template v-else>
								<template v-if="item.order_sell">
									<view>
										{{$util.formatNumber(item.order_sell.price*1*item.order_buy.num)}}
									</view>
								</template>
							</template>
						</view>
						<view style="flex:25%;text-align: right;">
							<view :style="{color:$util.THEME.TEXT}">{{$util.formatNumber(item.order_buy.price)}}</view>
							<view :style="{color:$util.THEME.TEXT}">
								{{$util.formatNumber(isHold? item.goods_info.current_price:item.order_sell.price)}}
							</view>
						</view>
					</view>
				</block>
			</view>
		</view>

		<template v-if="isShow">
			<view class="common_mask" @click="isShow=false">
				<view class="common_block common_popup" style="min-height:35vh;margin:auto">
					<view class="popup_header" :style="{backgroundColor:$util.THEME.PRIMARY}" style="margin: 0;">
						<text style="text-align: center;font-size: 16px;color:#FFF;">세부</text>
						<image src="/static/close.png" :style="$util.calcImageSize(24)" @click="isShow=false"
							style="position: absolute;right: 10px;top:8px;"></image>
					</view>
					<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
						<view style="flex: 25%;" :style="{color:$util.THEME.LABEL}">{{$lang.STOCK_NAME}}</view>
						<view style="flex: 75%;" :style="{color:$util.THEME.TEXT}">{{info.goods_info.name}}</view>
					</view>
					<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
						<view style="flex: 25%;" :style="{color:$util.THEME.LABEL}">{{$lang.BUY_DATETIME}}</view>
						<view style="flex: 75%;" :style="{color:$util.THEME.TEXT}">{{info.order_buy.created_at}}</view>
					</view>
					<template v-if="!isHold">
						<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
							<view style="flex: 25%;" :style="{color:$util.THEME.LABEL}">{{$lang.SELL_DATETIME}}</view>
							<view style="flex: 75%;" :style="{color:$util.THEME.TEXT}">{{info.order_sell.created_at}}
							</view>
						</view>
					</template>
					<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
						<view style="flex: 25%;" :style="{color:$util.THEME.LABEL}">{{$lang.CURRENT_PROFIT_LOSS}}</view>
						<view style="flex: 25%;" :style="{color:$util.THEME.TEXT}">
							{{$util.formatNumber(isHold?info.order_buy.float_yingkui:info.order_sell.float_yingkui)}}
						</view>
						<view style="flex: 25%;" :style="{color:$util.THEME.LABEL}">{{$lang.LEVER}}</view>
						<view style="flex: 25%;" :style="{color:$util.THEME.TEXT}">{{info.order_buy.double}}</view>
					</view>

					<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
						<view style="flex: 25%;" :style="{color:$util.THEME.LABEL}">{{$lang.TOTAL_PROFIT_LOSS_AMOUNT}}
						</view>
						<view style="flex: 25%;" :style="{color:$util.THEME.TEXT}">
							{{$util.formatNumber(isHold?info.order_buy.yingkui:info.order_sell.yingkui)}}
						</view>
						<view style="flex: 25%;" :style="{color:$util.THEME.LABEL}">{{$lang.BUY_PRICE}}</view>
						<view style="flex: 25%;" :style="{color:$util.THEME.TEXT}">
							{{$util.formatNumber(info.order_buy.price)}}
						</view>
					</view>

					<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
						<view style="flex: 25%;" :style="{color:$util.THEME.LABEL}">{{$lang.BUY_NUM}}</view>
						<view style="flex: 25%;" :style="{color:$util.THEME.TEXT}">
							{{$util.formatNumber(info.order_buy.num)}}
						</view>
						<view style="flex: 25%;" :style="{color:$util.THEME.LABEL}">{{$lang.FEE_BUY_SELL}}</view>
						<view style="flex: 25%;" :style="{color:$util.THEME.TEXT}">
							{{$util.formatNumber(isHold?info.order_buy.buy_fee:info.order_sell.sell_fee)}}
						</view>
					</view>

					<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
						<view style="flex: 25%;" :style="{color:$util.THEME.LABEL}">{{$lang.BUY_TOTAL_AMOUNT}}</view>
						<view style="flex: 25%;" :style="{color:$util.THEME.TEXT}">
							{{$util.formatNumber(info.order_buy.amount)}}
						</view>
						<view style="flex: 25%;" :style="{color:$util.THEME.LABEL}">{{$lang.CODE}}</view>
						<view style="flex: 25%;" :style="{color:$util.THEME.TEXT}">
							{{info.goods_info.number_code}}
						</view>
					</view>

					<view
						style="border-radius: 0 0 20px 20px;display: flex;align-items: center;justify-content: space-around;padding-top: 20px;"
						v-if="isHold">
						<view class="common_btn btn_primary" style="width: 40%;"
							@tap="handleStockDetail(info.goods_info.number_code,info.goods_info.id)">
							{{$lang.STOCK_DETAIL}}
						</view>
						<view class="common_btn btn_secondary" style="width: 40%;" @tap="handleSell(info.id)">
							{{$lang.STOCK_SELL}}
						</view>
					</view>
				</view>
			</view>
		</template>

	</view>
</template>

<script>
	import Header from '@/components/Header.vue';
	import TradeInfo from '@/components/TradeInfo.vue';
	export default {
		components: {
			Header,
			TradeInfo,
		},
		data() {
			return {
				isHold: true, // 是否是持股状态，否则为销售历史
				list: [],
				isSelf: true, // 国内，false:海外
				userInfo: {},
				isShow: false, // 买卖弹出
			}
		},
		//下拉刷新
		onPullDownRefresh() {
			this.handleRefresh()
			uni.stopPullDownRefresh()
		},
		onShow() {
			this.getUserInfo();
			this.handleRefresh()
		},

		onUnload() {
			console.log('포지션 종료됨1');
			clearInterval(this.timerId);
		},
		onHide() {
			console.log('포지션 종료됨2');
			clearInterval(this.timerId);
		},
		methods: {
			handleChangeList(val) {
				this.isHold = val == 0;
				this.handleRefresh();
			},
			handleChangeLocation(val) {
				this.isSelf = val == 0;
				this.handleRefresh();
			},

			handleShowModal(item) {
				this.isShow = true;
				this.info = item
			},

			handleRefresh() {
				uni.showLoading({
					mask: true
				})
				this.getList();
			},
			// 平仓/卖出
			handleSell(id) {
				const _this = this;
				uni.showModal({
					title: this.$lang.STOCK_SELL_TIP,
					cancelText: this.$lang.CANCEL,
					confirmText: this.$lang.CONFIRM,
					success: function(res) {
						this.isShow = false;
						if (res.confirm) {
							uni.hideLoading();
							_this.confirmSell(id);
						} else if (res.cancel) {
							console.log('사용자가 취소를 클릭합니다.');
						}
					}
				})
			},
			// //定时器
			// startTimer() {
			// 	const storedTimerId = uni.getStorageSync('timerId');
			// 	if (storedTimerId) {
			// 		clearInterval(storedTimerId);
			// 	}
			// 	this.timerId = setInterval(() => {
			// 		console.log('위치요청');
			// 		this.handleRefresh()
			// 		this.gaint_info()
			// 	}, 8000);
			// 	uni.setStorageSync('timerId', this.timerId);
			// },
			// 平仓功能
			async confirmSell(id) {
				uni.showLoading({
					title: this.$lang.TIP_SELLING,
					mask: true, // 显示透明蒙层，防止触摸穿透
				});
				const result = await this.$http.post(this.$http.API_URL.USER_SELL, {
					id
				})
				if (result.data.code == 0) {
					this.handleRefresh()
					uni.$u.toast(result.data.message);
					uni.hideLoading();
				} else {
					uni.$u.toast(result.data.message);
					uni.hideLoading();
				}
			},

			handleStockDetail(code, id) {
				uni.navigateTo({
					url: `${this.$util.PAGE_URL.STOCK_OVERVIEW}?code=${code}`
				});
			},

			async getList() {
				this.list = [];
				uni.showLoading({
					title: this.$lang.LOADING,
				})
				const result = await this.$http.get(this.$http.API_URL.USER_ORDER, {
					status: this.isHold ? 1 : 2, // 1持仓，2历史
					gp_index: this.isSelf ? 0 : 1,
				})
				if (result.data.code == 0) {
					this.list = result.data.data;
					uni.hideLoading()
				} else {
					uni.$u.toast(result.data.message);
					uni.hideLoading()
				}
			},

			async getUserInfo() {
				uni.showLoading({
					title: this.$lang.LOADING,
				})
				const result = await this.$http.get(this.$http.API_URL.USER_INFO, {})
				if (result.data.code == 0) {
					this.userInfo = result.data.data;
					uni.hideLoading()
				} else {
					uni.$u.toast(result.data.message);
					uni.hideLoading()
				}
			},

		},
	}
</script>