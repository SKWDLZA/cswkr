<template>
	<view class="page">
		<view class="flex" style="background-color: #212265;padding: 10px;">
			<view class="flex-1" style="color: #fff;font-size: 38rpx;">내정보</view>
			<view class="flex-2 flex" @click="$u.route({url:'/pages/searchFor/searchFor'});">
				<u--input shape="circle" suffixIconStyle="font-size: 24px;color: #fff;margin-right:10px"
					suffixIcon="/static/sousuo.png"  type="number" maxlength="11" border="none"
					:disabled="true" style="pointer-events: none"
					customStyle="background: rgba(255,255,255,0.25);height:60rpx;width:50%;margin-left: auto;pointer-events: none"></u--input>
			</view>
			<view @click="$u.route({url:'/pages/email/email'});">
				<!-- <u-icon name="/static/laba.png" style="margin-left: 10px;"></u-icon> -->
			</view>

		</view>
		<view style="background-color: #fff;padding: 10px;">
			<view class="align-center justify-center flex">
				<u-avatar size='80' :src="userInformation.avatar" default-url="/static/logo.png" shape="circle" ></u-avatar>
			</view>
			<view class="text-center bold font-size-20">
				{{userInformation.real_name}}
			</view>
			<view class="text-center margin-bottom-10 margin-top-10" style="color: #bcbec2;">
				{{userInformation.p_mobile}}
			</view>
			
		
			<view style="width: 90%;background-color: #eef4ff;border: 1px #212265 solid;margin-left: 5%;border-radius: 10px;margin-bottom: 10px;" class="flex flex-wrap">
				<view class="padding-10 flex-1" >
					<view class="flex align-center">
						총자산
						<u-image src="/static/my/biyan.png" style="margin-left: 5px;" width="20px" height="auto" mode="widthFix" @click="yan_show=false" v-if="yan_show"></u-image>
						
						<u-image src="/static/my/zhengyan.png" style="margin-left: 5px;" width="20px" height="auto" mode="widthFix" @click="yan_show=true" v-if="!yan_show"></u-image>
					</view>
					
					<view class="margin-top-10 bold font-size-16" v-if="yan_show">
						{{userInformation.totalZichan}}
					</view>
					<view class="margin-top-10 bold font-size-16" v-if="!yan_show">
						****
					</view>
				</view>
				<view class="padding-10 flex-1" >
					<view class="flex align-center">
						가용 자금
					</view>
					
					<view class="margin-top-10 bold font-size-16" v-if="yan_show">
						{{userInformation.money}}
					</view>
					<view class="margin-top-10 bold font-size-16" v-if="!yan_show">
						****
					</view>
				</view>
				<view class="padding-10 flex-1"  @click="$u.route({url:'/pages/my/components/aiBank/aiBank'});">
					<view class="flex align-center" >
						AI 계정
					</view>
					
					<view class="margin-top-10 bold font-size-16" v-if="yan_show">
						{{userInformation.aiMoney}}
					</view>
					<view class="margin-top-10 bold font-size-16" v-if="!yan_show">
						****
					</view>
				</view>
			</view>
		</view>
		<!-- <view class="margin-top-10" style="background-color: #fff;">
			<u-cell-group>
				<u-cell  title="확인됨[인증되지 않음]" :isLink="true" titleStyle="margin-left:10px;font-weight:700;color:#e82d28" v-if="userInformation.is_check==-1" @tap="notCertified()">
					<u-icon slot="icon" size="32" name="/static/my/sm.png" :bold="true"></u-icon>
				</u-cell>
				
				<u-cell  title="확인됨[검토중]" :isLink="true" titleStyle="margin-left:10px;font-weight:700;color:#77cfad" v-if="userInformation.is_check==0" @tap="notCertified()">
					<u-icon slot="icon" size="32" name="/static/my/sm.png" :bold="true"></u-icon>
				</u-cell>
				
				<u-cell  title="확인됨[감사 실패]" :isLink="true" titleStyle="margin-left:10px;font-weight:700;color:#e82d28" v-if="userInformation.is_check==2" @tap="notCertified()">
					<u-icon slot="icon" size="32" name="/static/my/sm.png" :bold="true"></u-icon>
				</u-cell>
				
				<u-cell  title="고객센터" :isLink="true" titleStyle="margin-left:10px;font-weight:700" url="/pages/index/components/customer/customer">
					<u-icon slot="icon" size="32" name="/static/my/kefu.png" :bold="true"></u-icon>
				</u-cell>
				
			</u-cell-group>
		</view> -->
		
		<view class="margin-top-10" style="background-color: #fff;">
			<u-cell-group>
				
				<u-cell  title="로그인 비밀번호 변경" :isLink="true" titleStyle="margin-left:10px;font-weight:700" @tap="changePassword()">
					<u-icon slot="icon" size="32" name="/static/my/yaoshi.png" :bold="true"></u-icon>
				</u-cell>
				
				
				<u-cell  title="결제 비밀번호 변경" :isLink="true" titleStyle="margin-left:10px;font-weight:700" @tap="fundPassword()">
					<u-icon slot="icon" size="32" name="/static/my/suo.png" :bold="true"></u-icon>
				</u-cell>
				
				<u-cell  title="입출금 계좌 연동" :isLink="true" titleStyle="margin-left:10px;font-weight:700" @tap="manages()">
					<u-icon slot="icon" size="32" name="/static/my/ka.png" :bold="true"></u-icon>
				</u-cell>
				
				
				<u-cell  title="입출금 내역" :isLink="true" titleStyle="margin-left:10px;font-weight:700" @tap="capitalDetails()">
					<u-icon slot="icon" size="32" name="/static/my/jilu.png" :bold="true"></u-icon>
				</u-cell>
				
				<u-cell  title="회사 소개" :isLink="true" titleStyle="margin-left:10px;font-weight:700" @tap="aboutUs()">
					<u-icon slot="icon" size="32" name="/static/my/about.png" :bold="true"></u-icon>
				</u-cell>
				
				
			</u-cell-group>
		</view>
		<!-- <view style="width: 90%;background-color: #212265;margin-left: 5%;height: 40px;line-height: 40px;border-radius: 6px;text-align: center;color: #fff;margin-top: 20px;margin-bottom: 100px;" @click="clear">로그인 종료</view> -->
		<view style="position: fixed;bottom: 50px;border-radius: 10px;background-color: #fff;width: 100%;">
			<view class="flex flex-b gap10 padding-10">
				<view style="background-color: #212265;" class="padding-10 radius10 color-white bold flex-1 text-center" @click="silver()">
					입금신청
				</view>
				<view style="background-color: #fff;border: 1px #212265 solid;" class="flex-1 radius10 padding-10 text-center" @click="clear">
					로그아웃
				</view>
			</view>
			
		</view>
	</view>
</template>

<script>
	// import annular from "./components/annular/annular.vue"
	export default {

		data() {
			return {
				//是否更新
				// updateFlag: false,
				// //每次版本更新都要修改
				// version: '2.1',
				// popupshow: true,
				downloadUrl: '',
				updateDesc: "",
				update: '',
				closeOnClickOverlay: false,
				//手机号
				tel: '',
				userInformation: {},
				is_check: '',
				cardManagement: '',
				item: '',
				yan_show:true
			}
		},
		onShow() {
			this.phoneNumShow()
		},
		//下拉刷新
		onPullDownRefresh() {
			uni.showLoading({
				title: '로드 중',
			});
			//关闭加载提示
			setTimeout(() => {
				uni.hideLoading();
			}, 1000);
			this.gaint_info()
			uni.stopPullDownRefresh()
		},

		methods: {
			clear() {
				this.$http.post('api/app/logout', )
				//清理缓存
				try {
					let version = uni.getStorageSync('version')
					uni.clearStorageSync();
					uni.setStorageSync('version', version)
				} catch (e) {
					// error
				}
				uni.$u.toast('성공적으로 종료');
				setTimeout(() => {
					uni.navigateTo({
						url: '/pages/logon/logon/logon'
					});
					// 登录成功之后强制刷新页面
					this.$router.go(0)
				}, 500)
			
			},
			link(type, url) {
				if (type == 1) {
					uni.switchTab({
						url: url
					})
				} else if (type == 3) {
					uni.reLaunch({
						url: url
					})
				} else {
					uni.navigateTo({
						url: url
					})
				}
			},
			//客服
			customer() {
				uni.navigateTo({
					url: '/pages/index/components/customer/customer'
				});
			},
			//隐藏手机号
			phoneNumShow() {
				let that = this;
				let number = this.tel; //获取到手机号码字段
				let mphone = number.substring(0, 3) + '****' + number.substring(7);
				that.tel = mphone
			},
			setAiBank(){
				uni.navigateTo({
					url:'/pages/my/components/aiBank/aiBank'
				})
			},
			// 跳转到设置
			setUp(mobile, avatar) {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的设置
					url: '/pages/my/components/setUp/setUp'
					// url: '/pages/my/components/setUp/setUp' + `?mobile=${mobile}&avatar=${avatar}`
				});

			},
			// 银转证
			silver() {
				uni.navigateTo({
					url:"/pages/index/components/customer/customer"
				})
				// if (bank_card_info && idno !== null) {
					
				// uni.navigateTo({
				// 	url: '/pages/index/components/customer/customer'
				// });
				
				// } else if (bank_card_info == null) {
				// 	uni.$u.toast('은행 카드에 묶여 있지 않음');
				// 	setTimeout(() => {
				// 		uni.navigateTo({
				// 			//保留当前页面，跳转到应用内的某个页面
				// 			url: '/pages/my/components/bankCard/renewal'
				// 		});
				// 	}, 2000)
				// } else if (idno == null) {
				// 	uni.$u.toast('실명인증 불가');
				// 	setTimeout(() => {
				// 		uni.navigateTo({
				// 			//保留当前页面，跳转到应用内的某个页面
				// 			url: '/pages/index/components/openAccount/openAccount'
				// 		});
				// 	}, 2000)
				// }

			},
			// 실시간 이체
			prove(money) {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/my/components/certificateBank/prove' + `?money=${money}`
				});
			},
			//修改密码
			changePassword() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/my/components/commonFunctions/changePassword'
				});
			},
			//펀드 비밀번호
			fundPassword() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/my/components/commonFunctions/fundPassword'
				});
			},
			//资金流水
			capitalDetails() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/my/components/commonFunctions/capitalDetails?index=0'
				});
			},
			// 卡管理
			manage(bank_name, bank_sub_name, card_sn) {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/my/components/bankCard/binding' +
						`?bank_name=${bank_name}&bank_sub_name=${bank_sub_name}&card_sn=${card_sn}`
				});
				// console.log(bank_name, '22222');
			},
			manages() {
				if(this.cardManagement){
					uni.navigateTo({
						url: '/pages/my/components/bankCard/binding'
					});
				}else{
					uni.navigateTo({
						//保留当前页面，跳转到应用内的某个页面
						url: '/pages/my/components/bankCard/renewal'
					});
				}
				
			},
			//版本更新
			Update() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/my/components/other/versionUpdate'
				});
			},
			//用户协议
			userAgreement() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/my/components/other/userAgreement'
				});
			},
			//隐私协议
			privacyAgreement() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/my/components/other/privacyAgreement'
				});
			},

			//关于我们
			aboutUs() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/my/components/other/aboutUs'
				});
			},
			//实名认证
			notCertified() {
				console.log('?');
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/marketQuotations/authentication'
				});
			},


			//用户信息
			async gaint_info() {
				let list = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				})
				const _fmtTotal = list.data.data.totalZichan.toString().length<3?list.data.data.totalZichan:list.data.data.totalZichan.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
				const _fmtMoney = list.data.data.money.toString().length<3?list.data.data.money:list.data.data.money.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
				this.userInformation = {...list.data.data,totalZichan :_fmtTotal,money:_fmtMoney}
				this.cardManagement = list.data.data.bank_card_info
			},

			//版本更新
			is_token() {
				let token = uni.getStorageSync('token') || '';
			},
			

		},

		onShow() {
			this.gaint_info()
			this.is_token()
		},

	}
</script>

<style lang="scss">
	page{
		background-color: #f3f4f8;
	}
</style>