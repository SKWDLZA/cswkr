<template>
	<view >
		<CustomHeader title="로그인 비밀번호 재설정" @action="handleBack()"></CustomHeader>

		<view
			style="display: flex;flex-direction: column;justify-content: center;align-items: center;padding-top:3vh;">
			<view class="common_input_wrapper" style="margin: 20px 0;width:80%;">
				<image mode="aspectFit" src="/static/password.png" :style="$util.calcImageSize(20)">
				</image>
				<input v-model="value" type="password" :placeholder="$lang.OLD_PWD" style="width:100%;"></input>
			</view>

			<view class="common_input_wrapper" style="margin: 20px 0;width:80%;">
				<image mode="aspectFit" src="/static/password.png" :style="$util.calcImageSize(20)">
				</image>
				<input v-model="value2" type="password" :placeholder="$lang.NEW_PWD"  style="width:100%;"></input>
			</view>

			<view class="common_input_wrapper" style="margin: 20px 0;width:80%;">
				<image mode="aspectFit" src="/static/password.png" :style="$util.calcImageSize(20)">
				</image>
				<input v-model="value3" type="password" :placeholder="$lang.NEW_PWD2"  style="width:100%;"></input>
			</view>

			<view class="common_btn btn_primary" style="width:50%;margin-top: 20px;" @click="changePassword">확인</view>
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components: {
			CustomHeader,
		},
		data() {
			return {
				value: "",
				value2: "",
				value3: "",
			};
		},
		methods: {
			handleBack() {
				uni.navigateBack({
					delta: 1
				});
			},
			//修改登录密码
			async changePassword() {
				const result = await this.$http.post(this.$http.API_URL.SIGNIN_PASSWORD, {
					oldpass: this.value,
					newpass: this.value2,
					confirmpass: this.value3,
				})
				if (result.data.code == 0) {
					uni.$u.toast('수정되었습니다.');
					setTimeout(() => {
						uni.switchTab({
							url: this.$util.PAGE_URL.ACCOUNT_CENTER
						});
					}, 1000)
				} else {
					uni.$u.toast(result.data.message);
				}
			},
		},
	}
</script>