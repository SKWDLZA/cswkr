<template>
	<view>
			<view class="college-bg">
				<image src="@/static/zuojiantou.png" mode="" @tap="home()"></image>
				<view class="college-text">Loan</view>
				<view class=""></view>
			</view>
			<view class="college-content">
				<view class="hui2">
					Lending Institution
				</view>
				<view class="cipher" @click="show=true">
					<input maxlength="11" placeholder="Please select a lending institution"   disabled="" v-model="dk_name"></input>
				</view>
				<view class="hui2">
					Loan minimum amount
				</view>
				<view class="cipher">
					<input maxlength="12" placeholder="Please enter the minimum loan amount" type="text" v-model="x_amount"></input>
				</view>
				
				<view class="hui2">
					Maximum loan amount
				</view>
				<view class="cipher">
					<input maxlength="12" placeholder="Please enter the maximum loan amount" type="text" v-model="d_amount"></input>
				</view>
			</view>
	
			<view class="purchase" @click="submit">
				Confirm
			</view>
			
			<u-picker :show="show" :columns="columns" confirmText="Confirm" cancelText="Cancel" @confirm="jigou_click" @cancel="show=false"></u-picker>
		</view>
</template>

<script>
	export default {
		data() {

			return {
				show: false,
				columns: [
					['Citibank','State Bank of india','Punjab National Bank','ICICI Bank','Bank Of Baroda','Bank Of india','Central Bank Of India','Airtel Payments Bank Limited','Canara Bank','Union Bank Of India']
				],
				money: "",
				top_index: 0,
				list: "",
				bid:"",
				dk_name:"",
				x_amount:"",
				d_amount:""
			}
		},

		methods: {
			jigou_click(item){
				console.log(item);
				console.log(item.indexs[0]);
				
				this.bid=item.indexs[0]*1+1
				this.dk_name=item.value[0]
				this.show=false
			},
			dianji(index) {
				this.top_index = index;
				this.list = ""
				if (index == 3) {
					this.sq_list()
				} else if (index == 1) {
					this.order_list()
				} else if (index == 2) {
					this.sell_list()
				}
			},
			home() {
				uni.navigateBack({
					delta: 1, //返回层数，2则上上页
				});
			},
		
			async submit() {
				if (!this.bid) {
					return uni.$u.toast('Please select a lending institution');
				}
				if (!this.x_amount) {
					return uni.$u.toast('Please enter the minimum loan amount');
				}
				if (!this.d_amount) {
					return uni.$u.toast('Please enter the maximum loan amount');
				}
				let list = await this.$http.post('api/daikuan/shenqing', {
					bid: this.bid,
					x_amount: this.x_amount,
					d_amount: this.d_amount,
					
				})
				if (list.data.code == 1) {
					return uni.$u.toast(list.data.message);
				} else {
			
					return uni.$u.toast(list.data.data);

				}
			},
			
			//版本更新
			is_token() {
				let token = uni.getStorageSync('token') || '';
			},
		},

		onShow() {
			this.gaint_info()
			this.is_token()
		},
		onLoad() {

		},

	}
</script>

<style lang="scss">
	.college-bg {
		padding: 60rpx 30rpx 0;
		height: 100rpx;
		background-image: linear-gradient(to right, #1a73e8, #014b8d);
		display: flex;
		justify-content: space-between;
		// align-items: center;
		text-align: center;
	
		image {
			width: 20rpx;
			height: 40rpx;
		}
	
		.college-text {
	
			color: #fff;
			font-weight: 800;
			font-size: 36rpx;
		}
	
	}
	
	.college-content {
		margin-top: -30rpx;
		border-radius: 30rpx 30rpx 0 0;
		background: #fff;
		padding: 30rpx;
	
		.cipher {
			padding: 20rpx;
			margin: 30rpx 0;
			background: #f5f5f5;
			border-radius: 10rpx;
	
		}
	
	}
	
	/deep/.uni-input-placeholder {
		color: #C0C4CC;
		font-size: 28rpx;
	}
	
	.purchase {
		background-image: linear-gradient(to right, #1a73e8, #014b8d);
		margin: 60rpx 30rpx;
		border-radius: 10rpx;
		padding: 20rpx 0;
		text-align: center;
		color: #fff;
		font-weight: 600;
	}
</style>