<template>
	<view class="page">
		<view class="header flex flex-b" @click="$u.route({type:'navigateBack'});">
			<img class="header-left icon jiantou">
			<view class="header-center flex-1">MY주식거래현황</view>
			<view class="header-right"></view><!---->
		</view>
		
		<view class="toubu">
			<u-tabs :activeStyle="{
		    color: '#fff',
		    fontWeight: 'bold',
			fontSize:'32rpx'
		}"
		:inactiveStyle="{
		    color: '#fff',
			fontSize:'32rpx'
		}" lineColor="#fd0e00" :list="gp_select" :current="gp_index" @click="gp_select_click"></u-tabs>
			
		</view>
		
		<view class="dabokl">
			<view class="available-balance">
				<view class="" v-if="gp_index==0">
					<view class="available">사용 가능한 잔액</view>
					<view class="balance">{{userInformation.money.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}원</view>
				</view>
				<view class="" v-if="gp_index==1">
					<view class="available">USD</view>
					<view class="balance">${{userInformation.usd.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</view>
				</view>
				<view>
					<view class="change"@click="silver">입금 내역</view>
					<view class="change"@click="duihuan" style="margin-top: 20rpx;background-color:#f85252 ;text-align: center;">출금 내역</view>
				</view>
				
			</view>

			<view class="funding-situation">
				<view class="situation">
					<view class="">총 매입</view>
					<view class="">{{userInformation.frozen.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</view>
				</view>
				<view class="xian"></view>
				<view class="situation">
					<view class="">총 평가</view>
					<view class="">{{userInformation.holdYingli.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</view>
				</view>
				<!-- 				<view class="xian"></view>
				<view class="situation">
					<view class="">冻结资金</view>
					<view class="">{{userInformation.frozen}}</view>
				</view> -->
			</view>

			<view class="sert">
				<view class="inv-h-w">
					<block v-for="(item,index) in items" :key="index">
						<view :class="['inv-h',Inv== index?'inv-h-se':'']" @click="qiehuan(index)">{{item}}</view>
					</block>
				</view>
				<u-divider></u-divider>
				<view v-show="Inv == 0" class="up-and-down-range">
					<view class="" style="border-bottom: 1px solid #e9e9e9;padding: 30rpx 0 ;"
						v-for="(item,index) in storehouse" :key="index">
						<view class="display" style="margin:0 30rpx ;">
							<view class="share-certificate" @tap="productDetails(item.goods_info.number_code)">
								<h6>{{item.goods_info.name}} </h6>
								
							</view>
							<view> X{{item.order_buy.double}}</view>

							<view class="position" @click="position(item.id)">매도</view>
							<!-- 	<view class="position" @click="closingFunction(item)">
								平仓
							</view> -->
						</view>

						<view class="" @tap="productDetails(item.goods_info.number_code)">
							<view class="display" style="margin: 30rpx 30rpx 20rpx;font-size: 26rpx;">
								<view class="up-date">현재가:<text>{{item.goods_info.current_price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</text></view>
								<!-- <view class="buy-up" v-if="item.direct=1">买涨↑</view> -->
								<view class="time">매수시간:{{item.order_buy.created_at}}</view>
							</view>
							<view class="shadow">
								<view class="display">
									<view class="">유동손익:</view>
									<view class="quantity">{{item.order_buy.float_yingkui.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</view>
								</view>
								<view class="display">
									<view class="">총손익:</view>
									<view class="quantity">{{item.order_buy.yingkui.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</view>
								</view>
							</view>
							<view class="shadows">
								<view class="display">
									<view class="">매입가:</view>
									<view class="quantity">{{item.order_buy.price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</view>
								</view>
								<view class="display">
									<view class="">수량:</view>
									<view class="quantity">{{item.order_buy.num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</view>
								</view>
							</view>
							<view class="shadows">
								<view class="display">
									<view class="">구매 수수료:</view>
									<view class="quantity">{{item.order_buy.buy_fee.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</view>
								</view>
								<view class="display">
									<view class="">총 매입가:</view>
									<view class="quantity">{{item.order_buy.amount.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</view>
								</view>
							</view>
						</view>
					</view>

					<view class="finished-text">
						보유 내역 없음
					</view>
				</view>
			</view>
			<!-- 弹窗 -->
			<u-modal :show="show" :title="title" @cancel="cancel" @confirm="confirm(confirmation)"
				:showCancelButton='showCancelButton' :content='content' cancel-text="취소" confirm-text="확인">
			</u-modal>


			<view class="transaction" v-show="Inv == 1">
				<view class="" v-if="updata" style="border-bottom: 1px solid #e9e9e9;padding: 30rpx 0 ;"
					v-for="(item,index) in storehouses" :key="index" @tap="productDetails(item.goods_info.number_code)">
					<view class="display" style="margin:0 30rpx ;">
						<view class="share-certificate">
							<h6>{{item.goods_info.name}}</h6>
							
						</view>
					</view>

					<view class="display" style="margin: 30rpx 30rpx 20rpx;font-size: 26rpx;">
						<view class="up-date">매도시간：{{item.order_sell.created_at}} </view>
						<!-- <view class="buy-up">买涨↑</view> -->
						<!-- <view class="time"></view> -->
					</view>
					<view class="shadow">
						<view class="display">
							<view class="">유동손익:</view>
							<view class="quantity">{{item.order_sell.float_yingkui.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</view>
						</view>
						<view class="display">
							<view class="">총손익:</view>
							<view class="quantity">{{item.order_sell.yingkui.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</view>
						</view>
					</view>
					<view class="shadows">
						<view class="display">
							<view class="">종가:</view>
							<view class="quantity">{{item.order_sell.price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</view>
						</view>
						<view class="display">
							<view class="">수량:</view>
							<view class="quantity">{{item.order_sell.num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</view>
						</view>
					</view>
					<view class="shadows">
						<view class="display">
							<view class="">마감 수수료:</view>
							<view class="quantity">{{item.order_sell.sell_fee.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</view>
						</view>
						<view class="display">
							<view class="">시장 가치:</view>
							<view class="quantity">{{item.order_sell.amount.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</view>
						</view>
					</view>
					<view class="shadows">
						<view class="display">
							<view class="">인지세:</view>
							<view class="quantity">{{item.order_sell.yinghua_fee.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</view>
						</view>
						<view class="display">
							<view class="">구매 수수료:</view>
							<view class="quantity">{{item.order_buy.buy_fee.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</view>
						</view>
					</view>

				</view>
				<view class="finished-text">
					보유 내역 없음
				</view>
			</view>


			<view class="transaction" v-show="Inv == 2">
				<view class="" style="border-bottom: 1px solid #e9e9e9;padding: 30rpx 0 ;"
					v-for="(item,index) in luckyNumber" :key="index">
					<view class="display" style="margin:0 30rpx ;">
						<view class="share-certificate" @tap="productDetails(item.goods_info.number_code)">
							<h6>{{item.goods_info.name}}</h6>
						
						</view>

						<view class="position" @click="position(item.id)">
							포지션 마감
						</view>
						<!-- 	<view class="position" @click="closingFunction(item)">
						平仓
					</view> -->
					</view>

					<view class="" @tap="productDetails(item.goods_info.number_code)">
						<view class="display" style="margin: 30rpx 30rpx 20rpx;font-size: 26rpx;">
							<view class="up-date">최신 정보:<text>{{item.goods_info.current_price}}</text></view>
							<!-- <view class="buy-up" v-if="item.direct=1">买涨↑</view> -->
							<view class="time">매도시간:{{item.order_buy.created_at}}</view>
						</view>
						<view class="shadow">
							<view class="display">
								<view class="">유동손익:</view>
								<view class="quantity">{{item.order_buy.float_yingkui}}</view>
							</view>
							<view class="display">
								<view class="">총손익:</view>
								<view class="quantity">{{item.order_buy.yingkui}}</view>
							</view>
						</view>
						<view class="shadows">
							<view class="display">
								<view class="">구매 가격:</view>
								<view class="quantity">{{item.order_buy.price}}</view>
							</view>
							<view class="display">
								<view class="">	수량:</view>
								<view class="quantity">{{item.order_buy.num}}</view>
							</view>
						</view>
						<view class="shadows">
							<view class="display">
								<view class="">구매 수수료:</view>
								<view class="quantity">{{item.order_buy.buy_fee}}</view>
							</view>
							<view class="display">
								<view class="">시장 가치:</view>
								<view class="quantity">{{item.order_buy.amount}}</view>
							</view>
						</view>
					</view>
				</view>

				<view class="finished-text">
					보유 내역 없음
				</view>
			</view>
			<view class="transaction" v-show="Inv == 3">

				<view class="" v-if="updata" style="border-bottom: 1px solid #e9e9e9;padding: 30rpx 0 ;"
					v-for="(item,index) in subscribe" :key="index" @tap="productDetails(item.goods_info.number_code)">
					<view class="display" style="margin:0 30rpx ;">
						<view class="share-certificate">
							<h6>{{item.goods.name}}</h6>
							
						</view>
					</view>

					<view class="display" style="margin: 30rpx 30rpx 20rpx;font-size: 26rpx;">
						<view class="up-date">구독 가격：{{item.price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}} </view>
						<!-- <view class="buy-up">买涨↑</view> -->
						<!-- <view class="time"></view> -->
					</view>
					<view class="shadow">
						<view class="display">
							<view class="">구독 수량:</view>
							<view class="quantity">{{item.apply_amount.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</view>
						</view>
						<view class="display">
							<view class="">구독 금액:</view>
							<view class="quantity">{{item.apply_num_amount.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</view>
						</view>
					</view>
					<view class="shadows">
						<view class="shadows-dis">
							<view class="">구독 시간:</view>
							<view class="quantity">{{item.created_at}}</view>
						</view>
						<view class="shadows-dis">
							<view class="">구독번호:</view>
							<view class="quantity">{{item.order_sn}}</view>
						</view>
					</view>

				</view>




				<view class="finished-text">
					보유 내역 없음
				</view>
			</view>
		</view>
		<!--更新-弹窗 -->
		<lerugeupdate ref="update" :downloadUrl="update.url" :updateDesc="update.title" :force="true" />
	</view>
</template>

<script>
	import lerugeupdate from "../../uni_modules/leruge-update/components/leruge-update/leruge-update.vue"
	export default {
		components: {
			lerugeupdate
		},
		data() {
			return {
				gp_select: [{
					name: "국내",
				}, {
					name: "해외",
				}
				],
				gp_index:0,
				// //是否更新
				// updateFlag: false,
				// //每次版本更新都要修改
				// version: '2.1',
				// popupshow: true,
				downloadUrl: '',
				updateDesc: "",
				update: '',
				// closeOnClickOverlay: false,
				Inv: 0,
				items: ['종목 보유 현황', '매매 내역', 
				// '보유수량', '매매내역'
				],
				show: false,
				title: '매도 주문',
				content: '매도 하시겠습니까?',
				showCancelButton: true,
				storehouse: '',
				storehouses: '',
				subscribe: '',
				luckyNumber: '',
				userInformation: '',
				updata: true,
				timerId: null,

			}
		},
		// watch: {
		// 	Inv: 'position'
		// },
		//下拉刷新
		onPullDownRefresh() {
			uni.showLoading({
				title: '로드 중',
			});
			//关闭加载提示
			setTimeout(() => {
				uni.hideLoading();
			}, 1000);
			this.hold()
			this.flat()
			uni.stopPullDownRefresh()
		},

		methods: {
			qiehuan(index){
				this.Inv=index
			},
			gp_select_click(e){
				this.storehouse=""
				
				this.gp_index=e.index
				this.Inv=0
				this.hold();
				this.flat()
			},
			// 平仓
			position(id) {
				this.show = true;
				this.confirmation = id


			},
			//点击取消
			cancel() {
				this.show = false;
			},
			// 点击确认
			confirm(confirmation) {
				// this.show = false;
				// console.log(confirmation, '点击确定');
				this.closingFunction(confirmation)
				this.show = false;
			},
			//产品세부
			productDetails(code) {
				uni.navigateTo({
					url: '/pages/marketQuotations/productDetails' +
						`?code=${code}`
				});
			},

			//点击下标
			subscript() {
				this.Inv == items.index
				// console.log(this.Inv, '下标');
			},
			//搜索
			searchFor() {
				uni.navigateTo({
					url: '/pages/searchFor/searchFor'
				});
			},
			// 银转证
			silver() {
				if (this.userInformation.bank_card_info && this.userInformation.idno !== null) {
					uni.navigateTo({
						//保留当前页面，跳转到应用内的某个页面
						url: '/pages/my/components/commonFunctions/capitalDetails?index=1'
					});
				} else if (this.userInformation.bank_card_info == null) {
					uni.$u.toast('은행 카드에 묶여 있지 않음');
					setTimeout(() => {
						uni.navigateTo({
							//保留当前页面，跳转到应用内的某个页面
							url: '/pages/my/components/bankCard/renewal'
						});
					}, 2000)
				} else if (this.userInformation.idno == null) {
					uni.$u.toast('실명인증 불가');
					setTimeout(() => {
						uni.navigateTo({
							//保留当前页面，跳转到应用内的某个页面
							url: '/pages/index/components/openAccount/openAccount'
						});
					}, 2000)
				}

			},
			//用户信息
			async gaint_info() {
				let list = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				})
				this.userInformation = list.data.data
			},
			// 新股持仓
			async holdings(e) {
				let list = await this.$http.post('api/user/sg-order', {
					gp_index:this.gp_index
				})
				this.luckyNumber = list.data.data

			},

			// 구독기록
			async shengou(e) {
				let list = await this.$http.post('api/goods-shengou/user-all-apply-log', {
					gp_index:this.gp_index
				})
				this.subscribe = list.data.data
				console.log(this.subscribe, '1111111111')
				// console.log(list.data.data)
			},



			// 持仓
			async hold() {
				let list = await this.$http.get('api/user/order', {
					// language: this.$i18n.locale
					status: 1,
					gp_index:this.gp_index
				})
				this.storehouse = list.data.data
				// console.log(list.data.data, '持仓');

			},
			//持仓
			async flat() {
				let list = await this.$http.post('api/user/order', {
					// language: this.$i18n.locale
					status: 2,
					gp_index:this.gp_index
				})
				this.storehouses = list.data.data
				// console.log(list.data.data, '持仓');
				// setTimeout(() => {
				// 	this.marketQuotations()
				// }, 10000)
			},
			// 平仓功能
			async closingFunction(confirmation) {
				uni.showLoading({
					title: "포지션을 마감 중입니다. 잠시 기다려 주세요....",
					mask: true, // 显示透明蒙层，防止触摸穿透
				});
				let list = await this.$http.post('api/user/sell', {
					id: confirmation,
					// price: item.price
				})
				// console.log(item.id, '平仓功能');
				if (list.data.code == 0) {
					this.updata = false
					this.updata = true
					this.hold()
					this.flat()
					uni.$u.toast(list.data.message);
					// this.$router.go(0)
					uni.hideLoading();

				} else {
					uni.$u.toast(list.data.message);
					uni.hideLoading();
				}

			},
			//版本更新
			is_token() {
				let token = uni.getStorageSync('token') || '';
			},
			async versionUpdate() {
				let list = await this.$http.get('api/version/detail', {})
				this.update = list.data.data
				let version = list.data.data.version
				let old_version = uni.getStorageSync('version') || 1.0
				// console.log(old_version, '当前版本111111111111111');
				if (old_version < version) {
					this.updateFlag = true
					this.$refs.update.upgrade()
					uni.setStorageSync('version', version)
				}
				// console.log(list.data.data, '版本更新');
			},
			//定时器
			startTimer() {
				const storedTimerId = uni.getStorageSync('timerId');
				if (storedTimerId) {
					clearInterval(storedTimerId);
				}
				this.timerId = setInterval(() => {
					console.log('위치요청');
					this.hold();
					this.flat()
					this.gaint_info()
				}, 8000);
				uni.setStorageSync('timerId', this.timerId);
				// 在这里立即执行一次请求
				
			},
			
			duihuan(){
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					// url: '/pages/my/components/duihuan/index'
					url:"/pages/my/components/certificateBank/prove"
				});
			}
		},
		
		onShow() {
			this.is_token()
			this.gaint_info()
			this.flat()
			this.hold()
			this.startTimer()
		},
		
		onUnload() {
			console.log('포지션 종료됨1');
			clearInterval(this.timerId);
		},
		onHide() {
			console.log('포지션 종료됨2');
			clearInterval(this.timerId);
		},

	}
</script>

<style lang="scss">
	.page {
	    padding: 53px 0 26px;
	}
	.page {
	    background: #fff;
	    min-height: 100vh;
	}
	uni-view, uni-text {
	    box-sizing: border-box;
	}

	
	.header{
	    height: 53px;
	    background: #1e50dc;
	    padding: 0 16px;
	    width: 100vw;
	    position: fixed;
	    top: 0;
	    left: 0;
	    z-index: 999;
		.header-left {
		    width: 12px;
		    height: 20px;
		}
		.header-center {
		    font-size: 17px;
		    font-weight: 700;
		    color: #fff;
		    text-align: center;
		}
		.header-right {
		    width: 9px;
		    height: 17px;
		}
	}
	/deep/.u-modal__content__text {
		text-align: center;
	}
	//깊은
	.deep {
		width: 30rpx;
		height: 30rpx;
		background: #1e50dc;
		border-radius: 0.4rpx;
		text-align: center;
		line-height: 30rpx;
		color: #fff;
		font-size: 24rpx;
		display: inline-block;
	}
	.deep-number {
		display: inline-block;
		padding: 0 0.04rem;
		background: rgba(59, 79, 222, .1);
		border-radius: 10rpx;
		color: #1e50dc;
		font-size: 24rpx;
		vertical-align: middle;
	}
	.toubu {
		width: 100%;
		background-image: linear-gradient(to right, #1e50dc, #1e50dc);
		display: flex;
		justify-content: space-between;
		color: #fff;
	}

	.dabokl {
		background: #fff;
		width: 100%;
		border-radius: 30rpx 30rpx 0 0;
		padding-top: 30rpx;

		.available-balance {
			display: flex;
			align-items: center;
			justify-content: space-between;
			padding: 30rpx;
			border-bottom: 10rpx solid #f4f4f4;
			font-size: 30rpx;

			.balance {
				font-weight: 600;
			}


			.change {
				background: #1e50dc;
				color: #FFFFFF;
				padding: 10rpx 50rpx;
				font-size: 24rpx;
				border-radius: 20rpx;
			}
		}

		.funding-situation {
			display: flex;
			align-items: center;
			justify-content: space-around;
			text-align: center;
			padding: 30rpx;
			border-bottom: 10rpx solid #f4f4f4;
			font-size: 30rpx;

			.xian {
				height: 100rpx;
				width: 2rpx;
				background: #9e9e9e;
			}


		}


		.inv-h-w {
			background-color: #FFFFFF;
			height: 80rpx;
			display: flex;
			margin-top: 50rpx;
		}

		.inv-h {
			font-size: 28rpx;
			flex: 1;
			text-align: center;
			color: #666666;

			position: relative;
		}

		.inv-h-se {
			font-size: 30rpx;
			font-family: PingFang SC;
			font-weight: bold;
			color: #1e50dc;
		}

		.inv-h-se:after {
			content: '';
			position: absolute;
			bottom: 20rpx;
			// top: auto;
			left: 42%;
			height: 6rpx;
			width: 44rpx;
			background-color: #1e50dc;
		}

		//我的持仓
		.up-and-down-range {

			// padding: 0 30rpx;
			.share-certificate {
				h6 {
					font-size: 30rpx;
					margin: 10rpx 0;
				}
			}

			.position {
				background-image: linear-gradient(to right, #1e50dc, #1e50dc);
				color: #fff;
				padding: 10rpx 30rpx;
				border-radius: 30rpx;
				font-size: 28rpx;
			}

			.up-date {
				width: 30%;

				text {
					color: #ff0a0a;
					font-weight: 600;
				}
			}

			.buy-up {
				color: red;
				width: 30%;
			}

			.time {
				color: #666;
				// width: 60%;
				text-align: right;
			}

			.shadow {
				background: #aac0ff;
				display: flex;
				justify-content: space-between;
				align-items: center;
				padding: 20rpx 30rpx;

				font-size: 26rpx;

				.display {
					width: 40%;

					.quantity {
						color: #ff0a0a;
					}
				}
			}

			.shadows {

				display: flex;
				justify-content: space-between;
				align-items: center;
				padding: 6rpx 30rpx;
				font-size: 26rpx;

				.display {
					width: 40%;

					.quantity {
						color: #ff0a0a;
						text-align: right;
						width: 50%;
					}
				}
			}

		}

		// 没有更多
		.finished-text {
			color: #969799;
			font-size: 28rpx;
			margin: 30rpx auto;
			text-align: center;
			padding: 30rpx 0;
		}

		// 我的交易
		.transaction {

			// padding: 0 30rpx;
			// padding: 0 30rpx;
			.share-certificate {
				h6 {
					font-size: 30rpx;
					margin: 10rpx 0;
				}
			}

			.position {
				background-image: linear-gradient(to right, #1a73e8, #1e50dc);
				color: #fff;
				padding: 10rpx 30rpx;
				border-radius: 30rpx;
				font-size: 28rpx;
			}

			.up-date {
				text {
					color: #ff0a0a;
					font-weight: 600;
				}
			}

			.buy-up {
				color: red;
			}

			.time {
				color: #666;
			}

			.shadow {
				background: #aac0ff;
				display: flex;
				justify-content: space-between;
				align-items: center;
				padding: 20rpx 30rpx;
				font-size: 26rpx;

				.display {
					width: 40%;

					.quantity {
						color: #ff0a0a;
					}
				}
			}

			.shadows {

				display: flex;
				justify-content: space-between;
				align-items: center;
				padding: 6rpx 30rpx;
				font-size: 26rpx;

				.shadows-dis {
					width: 40%;

					.quantity {
						margin: 10rpx 0;
						color: #ff0a0a;
					}
				}

				.display {
					width: 40%;

					.quantity {
						color: #ff0a0a;
					}
				}
			}


			// 没有更多
			.finished-text {
				color: #969799;
				font-size: 28rpx;
				margin: 30rpx auto;
				text-align: center;
				padding: 30rpx 0;
			}
		}

	}
</style>