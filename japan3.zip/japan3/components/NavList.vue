<!-- 用于纵向导航，如：个人中心 -->
<template>
	<view class="common_block" style="padding: 6px;">
		<view v-for="(item,index) in list" :key="index"
			style="width: 100%; display: flex;align-items: center;padding-bottom: 10px;padding-left: 20px;" @click="actionEvent(item.url,index)">
			<view style="flex: 12%;">
				<image style="width: 32px; height: 32px;" mode="aspectFit" :src="`/static/${item.icon}.png`"></image>
			</view>
			<text style="flex: 70%;font-weight: 700;font-size: 15px;">{{item.name}}</text>
			<view style="flex: 12%;">
				<image style="width: 14px; height: 14px;" mode="aspectFit" src="/static/jiantou.png"></image>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		name: "NavList",
		props: ['list'],
		data() {
			return {

			};
		},
		methods: {
			actionEvent(url, index) {
				if (url.includes('bankCard')) {
					this.$emit('action', url);
				}else if (url.includes('capitalDetails')) {
					uni.navigateTo({
						url: `/pages/capitalDetails/${url}`,
					})
				} else {
					uni.navigateTo({
						url: `/pages/${url}/${url}`,
					})
				}
			},
		}
	}
</script>

<style>

</style>