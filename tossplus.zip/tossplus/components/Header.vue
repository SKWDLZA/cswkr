<template>
	<view class="common_header">
		<view class="primary_header_left" @click="$u.route({url:$util.PAGE_URL.SEARCH});">
			<image mode="aspectFit" src="/static/search.png" :style="$util.calcImageSize(30)"></image>
		</view>
		<view class="primary_header_right">
			<image mode="aspectFit" src="/static/more.png" :style="$util.calcImageSize(40)" @click="handleLink()"
				style="padding-right: 45rpx;"></image>
			<image mode="aspectFit" src="/static/notification.png" :style="$util.calcImageSize(40)"
				@click="$u.route({url:$util.PAGE_URL.NOTIFICATION});" style="padding-right:  8rpx;"></image>
		</view>
	</view>
</template>

<script>
	export default {
		name: "Header",
		data() {
			return {};
		},
		methods: {
			// 跳转到个人中心
			handleLink() {
				uni.switchTab({
					url: this.$util.PAGE_URL.ACCOUNT_CENTER
				})
			},
		}
	}
</script>