<!-- 资金明细 -->
<template>
	<view>
		<view class="college-bg">
			<image src="@/static/zuojiantou.png" mode="" @tap="home()"></image>
			<view class="college-text">입출금 세부 내역</view>
			<view class=""></view>
		</view>
		<view class="college-content margin-top-10">
			<u-tabs lineColor="#2E67F6" :current="current" :list="list1" @click="select"
				:activeStyle="{color: '#fff',fontWeight: 'bold',background:'#2E67F6',padding:'10px',borderRadius:'10px'}"
				:inactiveStyle="{color: '#666'}"></u-tabs>
			<view v-if="current == 0">
				<view class="bg-white padding-10 margin-10 radius20"
					style="box-shadow: rgba(0, 0, 0, 0.24) 0px 3px 8px;" v-for="(item,index) in fundDetails"
					:key="index">
					<view class="margin-10">
						<view class="flex flex-b">
							<view style="color:#666666">입금</view>
							<view style="color: #2E67F6;" class="bold">
								{{item.money.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}원
							</view>
						</view>
						<view class="flex flex-b margin-top-10">
							<view style="color:#666666">잔액</view>
							<view style="color: #2E67F6;" class="bold">
								{{item.after.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}원
							</view>
						</view>
						<view class="flex flex-b margin-top-10">
							<view style="color:#666666">거래전 잔액</view>
							<view style="color: #FFC156;" class="bold">
								{{item.before}}원
							</view>
						</view>



						<view class="flex flex-b margin-top-10">
							<view style="color:#666666">시간</view>
							<view style="color: #000;">{{item.time1}}</view>
						</view>
						<view class="flex flex-b margin-top-10">
							<view style="color:#666666">시간</view>
							<view style="color: #000;">{{item.time2}}</view>
						</view>

						<view class="flex flex-b margin-top-10">
							<view style="color:#666666"></view>
							<view style="color: #000;">{{item.desc}}</view>
						</view>
					</view>
				</view>
			</view>
			<view v-if="current == 1">
				<view class="bg-white padding-10 margin-10 radius20"
					style="box-shadow: rgba(0, 0, 0, 0.24) 0px 3px 8px;" v-for="(item,index) in rechargeRecord"
					:key="index">
					<view class="margin-10">
						<view class="flex flex-b">
							<view style="color:#666666">상태</view>
							<view style="color: #d50000;" v-if="item.status==0">검토중</view>
							<view style="color: #5AC725;" v-if="item.status==1">이체 완료</view>
							<view style="color: #000;" v-if="item.status==2">충전에 실패했습니다. 고객센터에 문의하세요.</view>

						</view>

						<view class="flex flex-b margin-top-10">
							<view style="color:#666666">입금</view>
							<view style="color: #2E67F6;" class="bold">
								{{item.money.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}
							</view>
						</view>

						<view class="flex flex-b margin-top-10">
							<view style="color:#666666">주문 번호</view>
							<view style="color: #000;">{{item.order_sn}}</view>
						</view>
						<view class="flex flex-b margin-top-10">
							<view style="color:#666666">시간</view>
							<view style="color: #000;">{{item.created_at}}</view>
						</view>

						<view class="flex flex-b margin-top-10" v-if="item.status==2">
							<view style="color:#666666">이유</view>
							<view style="color: #000;">{{item.reason}}</view>
						</view>
					</view>

				</view>


			</view>
			<view v-if="current == 2">

				<view class="bg-white padding-10 margin-10 radius20"
					style="box-shadow: rgba(0, 0, 0, 0.24) 0px 3px 8px;" v-for="(item,index) in withdrawalRecords"
					:key="index">
					<view class="margin-10">
						<view class="flex flex-b">
							<view style="color:#666666">상태</view>
							<view style="color: #d50000;" v-if="item.status==0">검토중</view>
							<view style="color: #5AC725;" v-if="item.status==1">성공적으로 출금됨</view>
							<view style="color: #000;" v-if="item.status==2">출금에 실패했습니다. 고객센터에 문의하세요.</view>
							<view style="color: #F9AE3D;" v-if="item.status==3">취소 된</view>
						</view>

						<view class="flex flex-b margin-top-10">
							<view style="color:#666666">입금</view>
							<view style="color: #2E67F6;" class="bold">{{item.money.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}
							</view>
						</view>
						<view class="flex flex-b margin-top-10">
							<view style="color:#666666">주문 번호</view>
							<view style="color: #000;">{{item.order_sn}}
							</view>
						</view>
						<view class="flex flex-b margin-top-10">
							<view style="color:#666666">시간</view>
							<view style="color: #000;">{{item.created_at}}
							</view>
						</view>
						<view class="flex flex-b margin-top-10" v-if="item.status==2">
							<view style="color:#666666">이유</view>
							<view style="color: #000;">{{item.reason}}</view>
						</view>
						<view class="order">
							<u-button text="취소" type="error" @click="qx(item.id)" v-if="item.status==0"></u-button>
						</view>
					</view>
				
					
				</view>

			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				current: 0,
				list1: [{
						name: '입출금 세부 내역'
					},
					{
						name: '입금 내역'
					},
					{
						name: '출금 내역'
					},
				],
				fundDetails: '',
				rechargeRecord: '',
				withdrawalRecords: ''
			};
		},
		onLoad(item) {
			if (item.index == 0) {
				this.current = 0
				// this.current = item.index;
			}
			if (item.index == 1) {
				this.current = 1
				// this.current = item.index;
			}
			if (item.index == 2) {
				this.current = 2
				// this.current = item.index;
			}

		},
		methods: {
			qx(id) {
				var that = this;
				uni.showModal({
					title: "정말로 인출을 취소하시겠습니까?",
					cancelText: "취소",
					confirmText: "확인",
					success: function(res) {
						if (res.confirm) {
							that.qx_post(id)
						} else if (res.cancel) {
							console.log('사용자가 취소를 클릭합니다.');
						}
					}
				})
			},
			async qx_post(id) {
				let list = await this.$http.post('api/app/qx', {
					id: id
				});
				console.log(list)
				if (list.data.code == 0) {
					uni.$u.toast(list.data.message);
					this.withdrawal()
				} else {
					uni.$u.toast(list.data.message);
				}
			},
			home() {
				uni.switchTab({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/my/my'
				});
			},
			select(item) {
				// console.log(item);
				this.current = item.index;
				// console.log(this.current, '9989999999');
			},
			// 资金明细
			async fund() {
				let list = await this.$http.get('api/user/finance', {})
				this.fundDetails = list.data.data
				console.log(this.fundDetails);
			},
			//充值记录
			async recharge() {
				let list = await this.$http.get('api/user/recharge', {

				})
				this.rechargeRecord = list.data.data
			},
			//提现记录
			async withdrawal() {
				let list = await this.$http.get('api/user/withdraw', {

				})
				this.withdrawalRecords = list.data.data
			},

		},
		mounted() {
			this.fund()
			this.recharge()
			this.withdrawal()
		},
	}
</script>

<style lang="scss">
	page {
		background-color: #F8F8F8;
	}

	.college-bg {

		padding: 20rpx;

		height: 80rpx;

		background-color: #fff;
		display: flex;
		justify-content: space-between;
		align-items: center;
		text-align: center;

		image {
			width: 20rpx;
			height: 40rpx;
		}

		.college-text {

			color: #000;
			font-weight: 800;
			font-size: 36rpx;
		}

	}

	/deep/.u-tabs__wrapper__nav {
		justify-content: space-between;
		border-bottom: 1rpx solid #e0e0e0;
		padding: 0 30rpx;

	}

	.college-content {
		width: 100%;

		//选项卡一
		.fund {
			margin: 30rpx;

			.display {
				margin-top: 20rpx;
			}

			.time {
				color: #999;
				font-size: 24rpx;
			}

			.amount {
				color: #999;
				font-weight: 600;
				font-size: 30rpx;
				margin-top: 10rpx;
			}
		}

		//选项卡二
		.takeNotes {
			margin: 30rpx;
			padding: 20rpx 0;
			border-bottom: 2rpx solid #eeeeee;
			font-size: 26rpx;


			.business {
				display: flex;

				.corporate {
					background-color: #7266ba;
					color: #fff;
					border-radius: 4rpx;
					padding: 2rpx 10rpx;
					font-size: 24rpx;

				}

				.recharge {
					font-weight: 700;
					color: #000;
					margin: 0 20rpx 0 0;
				}

				.money {
					color: #BB1815;
					font-weight: 600;
				}

			}

			.underReview {
				display: flex;
				align-items: baseline;
				color: #d50000;
			}

			.underReview_b {
				display: flex;
				align-items: baseline;
				color: #5AC725;
			}

			.underReview_c {
				display: flex;
				align-items: baseline;
				color: #F9AE3D;
			}


			.order {
				margin-top: 10rpx;
				display: flex;
				font-size: 24rpx;
				color: #666;

				text {
					margin: 0 20rpx 0 10rpx;
				}
			}
		}
	}
</style>