<template>
	<view class="common_block" style="padding: 0 6px 6px 0;">
		<view
			style="border-radius:10px 0 7px 0px;padding:4px 10px;width: 70px;text-align: center;font-size: 13px;color: #fff;" :style="{backgroundColor:$util.THEME.SECONDARY_COLOR}">
			{{$lang.FAVORITES}}
		</view>
		<view style="overflow-y: scroll;height:110px;">
			<view v-for="(item,index) in list" @click="$u.route('/pages/productDetails/productDetails',{code:item.goods.code});"
				style="padding-top: 6px;margin-left:10px;width: 96%;display: flex;line-height: 36px;border-bottom:1px solid #e3ebfa;"
				:style="{backgroundColor:index%2===0?'#fff':'#f0f3fa'}">
				<view style="display: inline-block;flex:10%;">
					<template v-if="!item.goods.logo || item.goods.logo==''">
						<view :style="$util.calcImageSize(30)"
							style="background-color:#2d2c62;text-align: center;line-height: 30px;color: #FFFFFF;margin-bottom: 4px;border-radius: 100%;">
							{{item.goods.name.slice(0,1)}}
						</view>
					</template>
					<template v-else>
						<image mode="aspectFit" :src="$BaseUrl+item.goods.logo" :style="$util.calcImageSize(30)"
							style="border-radius: 100%;"></image>
					</template>
					<!-- <u--image :src="$BaseUrl+item.goods.logo" shape="circle"
						width="30px" height="30px"></u--image> -->
						
						</view>
				<view style="margin-left:10px;display: inline-block;flex:36%;">
					{{item.goods.name}}
				</view>
				<text style="display: inline-block;flex:20%;margin:0 10px;"
					:style="{color:`${item.goods.rate>0?'#ff3636':'#2DD872'}`}">{{$util.formatNumber(item.goods.current_price*1)}}
				</text>
				<view style="border-radius: 3px;font-weight: 700; display: inline-block;flex:29%;"
					:style="{color:`${item.goods.rate>0?'#ff3636':'#2DD872'}`}">
					<u-icon :name="`/static/${item.goods.rate>0?'up':'down'}.png`" size="12"
						style="display: inline-block;padding-right:10px;"></u-icon>
					{{item.goods.rate>0?'+':""}}{{(1*item.goods.rate).toFixed(2)}}%

				</view>
			</view>
			<EmptyData v-if="list.length<=0"></EmptyData>
		</view>		
	</view>
</template>

<script>
 import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: "Favorites",
		props:['list'],
		components: {
			EmptyData,
		},
		data() {
			return {};
		}
	}
</script>

<style>

</style>