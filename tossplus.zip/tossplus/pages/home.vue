<!-- 主页 -->
<template>
	<view :style="$util.setPageBG('bg_home')">
		<Header></Header>

		<view style="margin-top: 15vh;">
			<ButtonGroup :btns="$util.BTNS_CONFIG_HOME"></ButtonGroup>

			<view style="padding:4px 10px;display: flex;flex-wrap: nowrap;align-items: center;margin-left: 10px;">
				<image mode="aspectFit" src="/static/stock_all.png" :style="$util.setImageSize(6,36)"></image>
				<view style="padding-left: 10px; font-size:36rpx;" :style="{color:$util.THEME.TITLE}">
					{{ $lang.STOCK_HOT}}
				</view>
				<!-- <view style="font-size: 14px;" @click="handleAllList()" :style="{color:$util.THEME.TIP}">
					{{$lang.MORE}}
					<view class="arrow rotate_45" :style="$util.calcImageSize(10)"></view>
				</view> -->
			</view>
			<GoodsList ref="goods"></GoodsList>
		</view>

		<!-- 每次由登入跳转进入时，显示该弹层，关闭后，不再显示。 -->
		<template v-if="isShow">
			<view class="mask" @click="handleClose">
				<view style="position: fixed;top: 26vh;right: 12vw;z-index: 1000;" @click="handleClose">
					<image src="/static/close.png" mode="widthFix" style="width: 30px;height: 30px;"></image>
				</view>
				<view style="position: fixed;top:25vh;left: 50%;transform: translateX(-50%);">
					<view class="bg_ad"
						style="display: flex;flex-wrap: nowrap;flex-direction: column; align-items: center;justify-content: center;border-radius: 20px;">
						<view style="text-align: center;font-size: 36rpx;color:#ff3636;padding-bottom: 16px;">
							{{userInfo.nick_name}}님 축하합니다 .
						</view>
						<view
							style="width: 90%;background-color: #fbfdff;border-radius: 6px;text-align: center;padding:10px 10px 20px 10px;margin-top: 0px;">
							<view style="font-size: 20px;padding: 10px 0 2px 0;color:rgb(49, 130, 247);">
								【{{ipoSuccessItem.goods.number_code}}】 {{ipoSuccessItem.goods.name}}
							</view>
							<view style="font-size: 12px;color:#999;padding:2px 0 10px 0;">
								공모주청약 당첨되었습니다.
							</view>
							<view
								style="padding: 10px 0;display: flex;align-items: center;justify-content: space-around;">
								<view>배치 수량</view>
								<text style="font-weight: 700;color:#ff3636;font-size: 16px;">
									{{$util.formatNumber(ipoSuccessItem.success)}}</text>
							</view>
							<view
								style="padding: 10px 0;display: flex;align-items: center;justify-content: space-around;">
								<view>일시금</view>
								<text
									style="font-weight: 700;color:#ff3636;font-size: 16px;">{{$util.formatNumber(ipoSuccessItem.total)}}</text>
							</view>
							<view
								style="padding: 10px 0;line-height: 1;background-color:rgb(49, 130, 247);border-radius: 100px;color:#FFF;margin:20px 30px;"
								@click="$u.route('/pages/trade/ipoSuccess');">바로보기</view>
						</view>
					</view>
				</view>
			</view>
		</template>
	</view>
</template>

<script>
	import Header from '@/components/Header.vue';
	import ButtonGroup from '@/components/ButtonGroup.vue';
	import EmptyData from '@/components/EmptyData.vue';
	import GoodsList from '@/components/GoodsList.vue';
	export default {
		components: {
			Header,
			ButtonGroup,
			EmptyData,
			GoodsList,
		},
		data() {
			return {
				isShow: false, // 是否显示ad层,
				ipoSuccessItem: {},
				userInfo: {}, // 用户信息
				timer: null,
				page: 1,
				gp_index: 0,
			}
		},
		onLoad() {
			this.ipoSuccess();
			this.gaint_info();
		},
		onShow() {
			this.startTimer();
			if (this.$refs.goods) {
				this.$refs.goods.getList();
			}
		},
		onHide() {
			clearInterval(this.timer);
		},

		// onReachBottom() {
		// 	this.page = this.page + 1;
		// 	this.$refs.goods.getList(this.page);
		// },
		onUnload() {
			uni.$off('onSuccess');
		},
		methods: {
			// 用户信息
			async gaint_info() {
				const result = await this.$http.get(this.$http.API_URL.USER_INFO, {
					// language: this.$i18n.locale
				})
				this.userInfo = result.data.data;
				// this.cardManagement = result.data.data.bank_card_info
			},

			// 获取IPO成功记录
			async ipoSuccess() {
				const result = await this.$http.get('api/goods-shengou/user-success-log', {})
				if (result.data.data[0]) {
					this.isShow = true;
					this.ipoSuccessItem = result.data.data[0];
				}
				console.log('抢筹', result.data.data[0]);
			},
			// AD层关闭
			handleClose() {
				this.isShow = false;
			},
			handleIPO() {
				uni.navigateTo({
					url: this.$util.PAGE_URL.TRADE_IPO
				});
			},
			startTimer() {
				this.timer = setInterval(() => {
					// this.$refs.free.getList();
					this.$refs.goods.getList();
				}, 3000);
			},

			// 银转证
			async silver() {
				uni.navigateTo({
					url: this.$util.PAGE_URL.SERVICE
				});
			},
		},
	}
</script>

<style>
	.mask {
		background-color: rgba(0, 0, 0, 0.35);
		position: fixed;
		top: 0;
		left: 0;
		width: 100vw;
		height: 100vh;
		z-index: 999;
	}

	.bg_ad {
		background-image: url(/static/bg_common.png);
		background-size: cover;
		background-position: center;
		background-repeat: no-repeat;
		height: 50vh;
		width: 80vw;
	}
</style>