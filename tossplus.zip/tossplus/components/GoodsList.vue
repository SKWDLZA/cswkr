<template>
	<view class="common_block" style="padding-bottom: 6px;border-top-left-radius: 15px;border-top-right-radius: 15px;">
		<EmptyData v-if="list && list.length<=0"></EmptyData>
		<block v-for="(item,index) in list" :key="index">
			<view @click="handleDetail(item.code)"
				style="padding-top: 24rpx;margin-left:10px;display: flex;align-items: center;">
				<view style="flex:6%;">
					<template v-if="!item.logo || item.logo==''">
						<view :style="$util.calcImageSize(80)" style="background-color:#2d2c62;text-align: center;line-height: 80rpx;color: #FFFFFF;margin-bottom: 4px;border-radius: 100%;font-size: 18px;">{{item.ko_name.slice(0,1)}}</view>
					</template>
					<template v-else>
						<image mode="aspectFit" :src="item.logo" :style="$util.calcImageSize(80)" style="border-radius: 100%;"></image>
					</template>	
				</view>
				<view style="flex:44%;padding-left: 6px;font-size: 30rpx;" :style="{color:$util.THEME.STOCK_NAME}">
					{{item.ko_name}}
				</view>
				
				<view
					style="flex:40%;text-align: right;margin-right: 10px;"
					:style="$util.calcStyleRiseFall(item.returns>0)">
					<view style="padding-right:4px;padding-right: 10px;font-size: 30rpx;font-weight: 700;" :style="{paddingBottom:item.returns>0?'12rpx':''}">
						{{item.returns>0?'+':""}}{{(1*item.returns).toFixed(2)}}%
					</view>
					<view style="text-align: right;padding-right: 10px;font-size: 25rpx;"
						:style="{color:$util.THEME.STOCK_NAME}">{{$util.formatNumber(item.close*1)}}원
					</view>
				</view>
			</view>
		</block>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: "GoodsList",
		components: {
			EmptyData,
		},
		data() {
			return {
				list: [],
			};
		},
		mounted() {
			this.getList();
		},
		methods: {
			// handleAllList() {
			// 	console.log('???')
			// 	uni.navigateTo({
			// 		url: `${this.$util.PAGE_URL.STOCK_ALL}?type=0`,
			// 	})
			// },
			handleDetail(code) {
				uni.navigateTo({
					url: `${this.$util.PAGE_URL.STOCK_OVERVIEW}?code=${code}`,
				})
			},
			async getList() {
				// if (this.list.length <= 0) {
				// 	uni.showLoading({
				// 		title: this.$lang.LOADING,
				// 	})
				// }
				const result = await this.$http.get(this.$http.API_URL.GOODS_LIST, {
					page: 1,
					gp_index: 0
				})
				if (result.data.code == 0) {
					this.list = result.data.data;
				} else {
					uni.$u.toast(result.data.message);
				}
			},
		}
	}
</script>