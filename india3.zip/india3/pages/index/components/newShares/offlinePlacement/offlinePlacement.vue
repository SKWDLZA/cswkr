<template>
	<view>
		<view class="college-bg">
			<view class="account">
				<image src="../../../../../static/zuojiantou.png" mode="" @tap="home()"></image>
				<view class="college-text">신주 배정</view>
				<view class=""></view>
			</view>
		</view>
		<view class="xuanhze">
			<view class="">
				<view class="corporation">{{scrambleFor.goods.name}}</view>
				<view class="area" v-if="scrambleFor.goods.locate=='깊은'">
					<view class="deep">{{scrambleFor.goods.locate}}</view>
					<view class="deep-number">{{scrambleFor.goods.code}}</view>
				</view>
				<view class="area" v-if="scrambleFor.goods.locate=='북쪽'">
					<view class="north">{{scrambleFor.goods.locate}}</view>
					<view class="north-number">{{scrambleFor.goods.code}}</view>
				</view>
				<view class="area" v-if="scrambleFor.goods.locate=='상하이'">
					<view class="shanghai">{{scrambleFor.goods.locate}}</view>
					<view class="shanghai-number">{{scrambleFor.goods.code}}</view>
				</view>
			</view>
			<view class="price">
				
발행 가격 <text>{{scrambleFor.price}}</text>
			</view>
			<view class="price">
				
배치 가격<text>{{peishou_price}}</text>
			</view>
			<view class="price">
				상장일
				<text v-if="scrambleFor.online_date!=null">{{scrambleFor.online_date}}</text>
				<text v-if="scrambleFor.online_date==null">예고 없는</text>
			</view>
		</view>

				<view class="kunm">
			<view class="display custom">
				<view class=""></view>
				<view class="hand">사용자 정의 구독(공유)</view>
				<view class="">
					<image src="../../../../../static/yuangou.png" mode=""></image>
				</view>
			</view>
			<input placeholder="
수량을 입력해주세요" type="number" class="inpl" v-model="quantity">
			<view class="amount">배치 금액 : <text>{{peishou_price*this.quantity|addZero}} </text> </view>
		</view>

		<view class="queren" @click="placeOrder(scrambleFor.id)">
			배치 확인
		</view>

	</view>
</template>

<script>
	export default {
		data() {
			return {
				quantity: '',
				scrambleFor: "",
				peishou_price: ''
			};
		},
		methods: {
			home() {
				uni.navigateBack({
					delta: 1, //返回层数，2则上上页
				});
			},
			async scrambleForFunds(id) {
				let list = await this.$http.get('api/goods-scramble/detail', {
					id: this.id
				})
				this.scrambleFor = list.data.data
				console.log(list.data.data, '자금을 서두르다');
			},
			async placeOrder(id) {
				let list = await this.$http.post('api/goods-scramble/doOrder', {
					num: this.quantity,
					id: id,
					price: this.scrambleFor.price,
					double: 1
				})
				if (list.data.code == 0) {
					uni.$u.toast(list.data.message);
					setTimeout(() => {
						uni.navigateTo({
							url: '/pages/index/components/newShares/ration/ration'
						});
					}, 2000)
				} else {
					uni.$u.toast(list.data.message);
				}
			},
		},
		filters: {
			addZero: function(data) {
				return data.toFixed(2)
			}
		},
		onLoad(option) {
			// const item = JSON.parse(decodeURIComponent(option.item));
			// this.objData = item;
			// console.log(this.objData);
			this.id = option.id
			this.peishou_price = option.peishou_price
		},
		mounted() {
			this.scrambleForFunds()
		},


	}
</script>

<style lang="scss">
	.college-bg {
		padding: 60rpx 30rpx 0;
		height: 100rpx;
		background-image: linear-gradient(to right, #1a73e8, #014b8d);

		.account {
			display: flex;
			justify-content: space-between;
			align-items: center;
			text-align: center;

			image {
				width: 20rpx;
				height: 40rpx;

			}

			.college-text {
				// width: 97%;
				color: #fff;
				font-weight: 800;
				font-size: 36rpx;
			}
		}
	}

	.xuanhze {
		// width: 100%;
		background: #fff;
		margin-top: -30rpx;
		border-radius: 30rpx 30rpx 0 0;
		padding: 30rpx;
		// border-bottom: 4rpx solid #e0e0e0;


		.corporation {
			font-weight: 600;
			color: #333;
			font-size: 32rpx;
		}

		.area {
			margin: 10rpx 0 30rpx 0;
		}

		.price {
			color: #666;
			margin: 20rpx 0;
			padding-bottom: 30rpx;
			border-bottom: 2rpx solid #f3f3f3;
			font-size: 28rpx;

			text {
				color: #f85252;
				margin-left: 20rpx;
			}
		}

	}

	.kunm {
		padding: 30rpx;
		// border: 1rpx solid #f85252;
		box-shadow: 1px 1px 1px 1px #ececec;
		border-radius: 30rpx;
		margin: 30rpx;

		.custom {
			.hand {
				font-size: 30rpx;
				font-weight: bold;
			}

			image {
				width: 30rpx;
				height: 30rpx;
			}
		}

		.inpl {
			border: 1rpx solid #ccc;
			border-radius: 10rpx;
			margin: 20rpx 0;
			font-size: 30rpx;
			color: #000;
			padding: 20rpx;
		}

		.amount {
			font-size: 24rpx;
			color: #666;

			text {
				color: #f33030;
				margin-left: 20rpx;
			}
		}
	}

	.queren {

		height: 80rpx;
		background-image: linear-gradient(to right, #1a73e8, #014b8d);
		text-align: center;
		line-height: 80rpx;
		color: #fff;
		font-size: 32rpx;
		margin: 30rpx;
		border-radius: 10rpx;
	}
</style>