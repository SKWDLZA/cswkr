
<template>
	<view class="page">
		<view class="topNav">
			<view class="flex flex-c mb-30">
				
				<view class="back" @click="tiaozhuan">
					
					<img
						src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACYAAABECAMAAADa37fNAAAAAXNSR0IArs4c6QAAAQhQTFRFAAAA////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////kOfX3wAAAFd0Uk5TAAECAwQFBgcICQsNDxETFBYZGx4hJSgsLzM3S1dcYmdsbXJzd3h5fX5/g4SFh4qLkJGWm5yhpqerrLCxtbq+wsPHy8/S09bZ2t3g4+bo6+3w8/T1/P3+u0EIlAAAAUpJREFUSMel1ldPAlEUBOCFFaQqWLFiwV6pNoqAoqIuKsr9///EGPVOeJhlEs7zl93cNuc4jn8te/0TZ2QtvRljDkepTM/81J6/WvTMb+X81MLrnzLvPmr+5V+ZD67mnq36XKVqtmvV1xpVM09WDdapSj9YZbJUpTpQm1RN3UFtU5VsQ+1SlWhBHVAVb0IdUxVrQJ1RFa1D5amarEEVqApXoUoBpkLXUOUgU+4l1IXLVLACdTVBVRnqJsRUoAhVDdNFFqBqEarOoepRqk6hbmNUHUE141TtQ7USVO1AtZNUbUHdT1O1AdVJUZUdWPWY5hng4WMrzthM/Km4BHVD1O1VD0s9evUiqddSveTqkxEfoPqch8Oh4nKnRY0aXGoMqqGqRrQa+Gr7UJuR2trURqm2XbWJqyOBOmAMjSv98YcfdZRSBzN1zLND4zemxPXfZVlm2QAAAABJRU5ErkJggg==" style="height: 20px;">
				</view>
				<view class="text-center pt-20" style="margin-top: 10px;">
					<view>{{productDetails.name}}</view><uni-text><span>{{productDetails.code}}</span></uni-text>
				</view>
			
			</view>
			<view class="flex flex-b ml-30" v-if="productDetails">
				<view class="price text-center flex flex-b" style="width: 100%;">
					<view class="flex-1 font-size-26">
						<span>{{productDetails.price}}</span>
					</view>
					<view style="text-align: right;margin: 20px;" class="flex-1" >
						<view class="mr-30">{{productDetails.rate_num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</view>
						<view>{{productDetails.rate}}%</view>
					</view>
				</view>
				<!-- <view class="favo flex" @click="handleClickDelProduct(productDetails.gid)">
					<view>
						<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAECAYAAACUY/8YAAAAAXNSR0IArs4c6QAAABZJREFUKFNjfG1s/Z+BhoBx1AJCoQsAzz4JZcQ1KyIAAAAASUVORK5CYII="  style="height: 1px;" v-if="productDetails.is_collected==1">
						<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYAQMAAADaua+7AAAAAXNSR0IArs4c6QAAAAZQTFRFAAAA6zM7RbAKmgAAAAF0Uk5TAEDm2GYAAAAWSURBVAjXY2CwYWAgBv///x8FE6kPAB9NEKUs3v6MAAAAAElFTkSuQmCC"  style="height: 6px;" v-else>
					</view>
					<view>{{productDetails.is_collected==1?"Delete item of interest":"Add items of interest"}}</view>
				</view> -->
			</view>
		</view>
		<!-- <view class="top" v-if="productDetails">
			<view class="list flex flex-b">
				<view class="flex item">
					<view class="t2">Volume (Shares)</view>
					<view class="t3">{{productDetails.project_type_id==1?productDetails.data.response2.data.companyDetails.nse_volume:productDetails.data.response2.data.companyDetails.bse_volume}}</view>
				</view>
				<view class="flex item">
					<view class="t2">Market Cap (₹ Cr)</view>
					<view class="t3">{{productDetails.project_type_id==1?productDetails.data.response2.data.companyDetails.nse_market_capital:productDetails.data.response2.data.companyDetails.bse_market_capital}}</view>
				</view>
				<view class="flex item">
					<view class="t2">Turnover (₹ Cr)</view>
					<view class="t3">{{productDetails.project_type_id==1?(productDetails.data.response2.data.companyDetails.nse_turnover/100000000).toFixed(2):(productDetails.data.response2.data.companyDetails.bse_turnover/100000000).toFixed(2)}}</view>
				</view>
				<view class="flex item">
					<view class="t2">Face Value</view>
					<view class="t3">{{productDetails.data.response2.data.companyOverview['key-fundamentals'][0].face_value}}</view>
				</view>
				
			</view>
		</view> -->
		<!-- <view class="nav-box">
			<view class="nav-item" :class="curren==0?'active':''" @click="curren_click(0)">Latest News<span></span></view>
			<view class="nav-item" :class="curren==1?'active':''" @click="curren_click(1)">Summary<span></span></view>
			<view class="nav-item" :class="curren==2?'active':''" @click="curren_click(2)">Issue<span></span></view>
		</view> -->
		
		<view v-show="curren==0" style="margin-top: 20px;">
			<view class="stock-chart">
				<view class="chart-time" style="position: relative;">
					<view class="txt" :class="ac_time==0?'active':''" @click="ac_time_click(0)">{{$t('index.Min')}}</view>
					<view class="txt" :class="ac_time==1?'active':''" @click="ac_time_click(1)">{{$t('index.Daily')}}</view>
					<view class="txt" :class="ac_time==2?'active':''" @click="ac_time_click(2)">{{$t('index.Monthly')}}</view>
					
				</view>
				<view class="chart" id="chart-type-k-line" style="width: 100%;height: 600rpx;" >
				</view>
			</view>
			<view class="stock-detail" >
				<view class="stock-right flex-1 flex" style="margin: 10px;">
		
					<view class="b-btn" style="margin-right: 10px;" @click="purchase(1)">
					{{$t('index.BUY')}}</view>
					<view class="b-btn" style="background-color: #1677ff;" @click="purchase(2)">
					{{$t('index.SELL')}}</view>
				</view>
			</view>
		</view>
		<InfoTwo v-if="curren==1" :code='code'  :productDetails='productDetails'>
			
		</InfoTwo>
		
		<InfoThree v-if="curren==2" :code='code'  :productDetails='productDetails'>
			
		</InfoThree>
		
	</view>
</template>

<script>
	import InfoTwo from '@/components/info/InfoTwo.vue'
	import InfoThree from '@/components/info/InfoThree.vue'
	import {
		init,
		registerLocale,
		dispose
	} from 'klinecharts'
	// import generatedKLineDataList from '@/utils/generatedKLineDataList.js'
registerLocale('zh-HK', {
				  time: '時間:',
				  open: '始値:',
				  high: '高値:',
				  low: '安値:',
				  close: '終値:',
				  volume: '出来高:',
				  turnover: '売買代金:',
				  change: '変動幅:'
				})
	export default {
		components: {
			InfoTwo,
			InfoThree
		},
		data() {
			return {
				zuoshou: 0,
				updata: true,
				productDetails: "",
				today: '',
				yesterday: '',
				buy: "",
				sell: "",
				divide: '',
				sky: '',
				circumference: '',
				moon: '',
				onePoint: '',
				halfhour: '',
				timerId: null,
				option: {},
				time_index: 0,
				list: [],
				gid: 0,
				kLineChart: [],
				ac_time: 0,
				curren: 0
			};

		},
		mounted() {
			this.kLineChart = init('chart-type-k-line')
			this.init()
		},
		methods: {
			
			tiaozhuan(){
				uni.switchTab({
					url:"/pages/marketQuotations/marketQuotations"
				})
			},
			sockets(){
			    //创建webSocket
			    this.webSocketTask = uni.connectSocket({
				    url: 'wss://api.starxclub.xyz/ws',
					header: {
						'content-type': 'application/json'
					},
					success(res) {
						console.log('成功', res);
					},
				})
			 
				// 监听WebSocket连接打开事件
				this.webSocketTask.onOpen((res) => {
					console.info("监听WebSocket连接打开事件", res)
				});
			 
				// 监听WebSocket错误
				uni.onSocketError((res) => {
					console.info("监听WebSocket错误" + res)
				});
				var that=this;
				 // 接收websocket消息及处理
				this.webSocketTask.onMessage((res) => {
					var data=JSON.parse(res.data);
					if(data['market']==that.code){
						this.productDetails.price=data.lastPrice
						this.productDetails.rate=data.rate
						this.productDetails.rate_num=data.rate_num
					}
					// console.log(data);
					// that.quotation[data.market].price=data.lastPrice
					// that.quotation[data.market].rate=data.rate
				});
			},
			sell_link(){
				uni.switchTab({
					url:"/pages/position/position"
				})
			},
			init() {

				this.kLineChart.setLocale("zh-HK")
				this.product()
				this.startTimer()
			},
			curren_click(index) {
				this.curren = index;

				this.$forceUpdate()
			},
			ac_time_click(index) {
				this.ac_time = index;
				this.qiehuan()
			},
			async qiehuan() {

				let list = await this.$http.post('api/bi/lishi', {
					code: this.code,
					type: this.type,
					ac_time: this.ac_time
				})
				// if (this.ac_time >= 1) {

				// 	this.kLineChart.setStyles({
				// 		"candle": {
				// 			"type": "candle_solid",
				// 			"bar":{
				// 				"downColor":"#1677ff",
				// 				"upColor":"#F92855",
							
				// 				      "upBorderColor": '#F92855',
				// 				      "downBorderColor": '#1677ff',
								   
				// 				      "upWickColor": '#F92855',
				// 				      "downWickColor": '#1677ff',
				// 			},
				// 			"priceMark":{
				// 				"last":{
				// 					"upColor": '#F92855',
				// 					"downColor": '#1677ff',
				// 				}
				// 			}
							
				// 		}
				// 	});
				// } else {

				// 	this.kLineChart.setStyles({
				// 		"candle": {
				// 			"type": "area",
				// 		}
				// 	});
				// }
				this.kLineChart.setStyles({
					"candle": {
						"type": "candle_solid",
					}
				});
				this.kLineChart.applyNewData(list.data.data)
			},
			time_click(i) {
				this.time_index = i.index
				this.product()
			},
			home() {
				uni.navigateBack({
					delta: 1, //返回层数，2则上上页
				})
			},
			// 买入
			purchase(fx) {
				uni.navigateTo({
					url: '/pages/marketQuotations/bibuy?code=' + this.code+"&fx="+fx

				});
			},
			// 产品详情
			async product() {
				
				let list = await this.$http.get('api/bi/info', {
					code: this.code,
					time_index: this.time_index,
					type:this.type
				})
				// uni.hideLoading()
				this.productDetails = list.data.data[0]
				this.qiehuan()

			},
			//定时器
			startTimer() {
				const storedTimerId = uni.getStorageSync('timerId');
				if (storedTimerId) {
					clearInterval(storedTimerId);
				}
				this.timerId = setInterval(() => {
					// this.product()
				}, 3000);
				uni.setStorageSync('timerId', this.timerId);
				// 在这里立即执行一次请求
			},
			//删除
			async handleClickDelProduct(e) {
				let list = await this.$http.post('api/user/collect_edit', {
					gid: e,
				})
				if (list.data.code == 0) {
					uni.$u.toast(list.data.message);
					this.updata = !this.updata
					this.updata = true
					//按键样式判断
					this.productDetails.is_collected = this.productDetails.is_collected == 1 ? 0 : 1
				} else {
					this.show = false
					uni.$u.toast(list.data.message);
				}
			},

		},

		onLoad(option) {
			this.code = option.code
			this.type=option.type
		},
		// onShow() {
		// 	uni.showLoading({
				
		// 	})
		// 	// this.startTimer()
		// 	this.sockets()
		// },
		onUnload() {
			// clearInterval(this.timerId);
			uni.closeSocket({
				success: () => {
					console.info("退出成功")
				},
			})
			
		},
		onHide() {
			// clearInterval(this.timerId);
			uni.closeSocket({
				success: () => {
					console.info("退出成功")
				},
			})
			
		},

	}
</script>

<style lang="scss">
	.page {
	    padding: 176px 0 27px 0;
	}

	.page {
		background: #fff;
		min-height: 100vh;
	}

	view,
	uni-text {
		box-sizing: border-box;
	}
	.topNav {
	    min-height: 150px;
	    width: 100%;
	    background: #141517;
	    position: fixed;
	    top: 0;
	    left: 0;
	    z-index: 500;
	    font-size: 20px;
	    font-weight: 500;
	    color: #fff;
		.back{
		    position: absolute;
		    top: 16px;
		    left: 16px;
			uni-image {
			    width: 11px;
			}
		}
		uni-text{
		    font-size: 12px;
		    color: #f8b2b2;
		    font-weight: 400;
		}
		.search {
		    position: absolute;
		    top: 16px;
		    right: 16px;
			uni-image {
			    width: 18px;
			}
		}
		.price {
		    font-size: 14px;
			uni-text {
			    font-size: 39px;
			    color: #fff;
				font-weight: 400;
			}
		}
		.favo {
		    height: 27px;
		    background: #fff;
		    border-radius: 55px 0px 0px 55px;
		    padding: 0 16px;
		    font-size: 13px;
		    color: #eb333b;
			
			img {
			    width: 6px;
			    display: block;
			    margin-right: 8px;
			}
			
		}
		
	}

	.header {
		height: 53px;
		background: #eb333b;
		padding: 0 16px;
		width: 100vw;
		position: fixed;
		top: 0;
		left: 0;
		z-index: 999;

		.header-left {
			width: 12px;
			height: 20px;
		}

		.header-center {
			font-size: 17px;
			font-weight: 700;
			color: #fff;
			text-align: center;
		}

		.header-right {
			width: 9px;
			height: 17px;
		}
	}
	.top {
	    padding: 16px 0px 11px 16px;
	    border-bottom: 5px solid #f3f4f9;
		.list {
		    -webkit-flex-wrap: wrap;
		    flex-wrap: wrap;
		}
		.item {
		    width: 50%;
		    line-height: 22px;
		    margin-bottom: 5px;
			.t2 {
			    font-size: 14px;
			    color: #666;
			    margin-right: 3px;
			}
			.t3 {
			    font-family: Roboto;
			    font-size: 15px;
			    color: #333;
			}
		}
	}
	.top1 {
		padding: 16px 5px 5px;

		.pd10 {
			padding: 0 5px;
		}

		.t {
			font-size: 19px;
			font-weight: 700;
			color: #333;
		}

		.bt {
			background: #eb333b;
			border-radius: 10px;
			padding: 5px 10px;

			.icon {
				margin-right: 10px;
			}

			view {
				font-size: 17px;
				color: #fefefe;
			}
		}

		.mt30 {
			margin-top: 16px;
		}

		.t1 {
			font-size: 32px;
			font-family: Roboto;
			font-weight: 700;
			color: #333;
			margin-right: 10px;
		}

		.r-bg {
			background: #f7e8e8;
			border-radius: 10px;
			padding: 5px 10px;

			.icon {
				margin-right: 5px;
			}

			span {
				font-family: Roboto;
				font-weight: 700;
				color: #ff3636;
			}
		}

		.b-bg {
			background: #e7f1f9;
			border-radius: 10px;
			padding: 5px 10px;

			span {
				font-family: Roboto;
				font-weight: 700;
				color: #eb333b;
			}
		}

		.list1 {
			background: #f2f5f7;
			border-radius: 8px;
			padding: 10px 5px;
			-webkit-flex-wrap: wrap;
			flex-wrap: wrap;
			margin-top: 10px;

			.item {
				width: 32%;
				line-height: 21px;
			}

			.t2 {
				font-size: 12px;
				color: #999;
			}

			.t3 {
				font-size: 12px;
				color: #333;
				font-family: Roboto;
			}
		}
	}

	.nav-box {
		margin-bottom: 16px;
		height: 51px;
		border-bottom: 1px solid #e5e8f6;
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
		-webkit-box-align: center;
		-webkit-align-items: center;
		align-items: center;
		-webkit-box-pack: center;
		-webkit-justify-content: center;
		justify-content: center;


		.nav-item {
			height: 51px;
			width: 50%;
			display: -webkit-box;
			display: -webkit-flex;
			display: flex;
			-webkit-box-orient: vertical;
			-webkit-box-direction: normal;
			-webkit-flex-direction: column;
			flex-direction: column;
			-webkit-box-align: center;
			-webkit-align-items: center;
			align-items: center;
			-webkit-box-pack: end;
			-webkit-justify-content: flex-end;
			justify-content: flex-end;
			font-size: 17px;
			color: #333;

			span {
				width: 100%;
				height: 3px;
				background: transparent;
				margin-top: 10px;
				display: block;
			}
		}

		.active {
			font-size: 17px;
			font-weight: 700;
			color: #eb333b;

			span {
				background: #eb333b;
			}
		}

	}

	.stock-chart {
		background: #fff;

		.chart-time {
			background: #f2f2f2;
			border: 1px solid #999;
			border-radius: 5px;
			display: -webkit-box;
			display: -webkit-flex;
			display: flex;
			-webkit-box-pack: justify;
			-webkit-justify-content: space-between;
			justify-content: space-between;
			-webkit-box-align: center;
			-webkit-align-items: center;
			align-items: center;
			margin: 0 10px 10px;

			.txt {
				-webkit-box-flex: 1;
				-webkit-flex: 1;
				flex: 1;
				text-align: center;
				color: #999;
				border-radius: 5px;
				padding: 10px 0;
			}

			.active.txt {
				color: #eb333b;
				border: 1px solid #eb333b;
			}
		}
	}

	.b-btn {
		width: 100%;
		height: 46px;
		line-height: 46px;
		background: #eb333b;
		border-radius: 10px;
		text-align: center;
		font-size: 17px;
		font-weight: 500;
		color: #fff;
		margin: 26px 0;
	}

	.b-btn {
		width: 95%;
		margin: 16px auto 0;
	}
</style>