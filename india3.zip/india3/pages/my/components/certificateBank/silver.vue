<!-- 银转证 -->
<template style="background: #f0f0f0;">
	<view>
		<view class="college-bg">
			<view class="account">
				<image src="../../../../static/zuojiantou.png" mode="" @tap="home()"></image>
				<view class="college-text">Deposit information</view>
				<view class=""></view>
			</view>
			<view class="progress"> {{userInformation.money}}</view>
			<view class="vacancies">Current available balance</view>
		</view>
		<!-- 
		<u-tabs lineColor="#f85252" :list="list1" @click="strike"
			:activeStyle="{color: '#fff',background:'#f85252',padding:'10px 20px',}"></u-tabs> -->

		<!-- <view class="inv-h-w">
			<block v-for="(item,index) in items" :key="index">
				<view :class="['inv-h',Inv== index?'inv-h-se':'']" @click="Inv=index">{{item}}</view>
			</block>

		</view> -->

		<view v-show="Inv == 0">
			<view class="collections">
				<view class="call">
					<view class="beneficiaryName">BANK</view>
					<view class="">{{BankName}}</view>
					<view class="duplicate" @click="copy(BankName)">Copy</view>
				</view>
			</view>
			<view class="xian"></view>
			<view class="collections">
				<view class="call">
					<view class="beneficiaryName">Corporate Name</view>
					<view class="">{{Corporate}}</view>
					<view class="duplicate" @click="copy(Corporate)">Copy</view>
					<!-- <view class="duplicate" @tap="customer()">客服</view> -->
				</view>
			</view>
			<view class="xian"></view>
			<view class="make-collections">
				<view class="call">
					<view class="beneficiaryName">Acc number</view>
					<view class="">{{BankNo}}</view>
					<view class="duplicate" @click="copy(BankNo)">Copy</view>
				</view>
			</view>
			<view class="xian"></view>

			<view class="make-collections">
				<view class="call">
					<view class="beneficiaryName">IFSC</view>
					<view class="">{{IFSC}}</view>
					<view class="duplicate" @click="copy(IFSC)">Copy</view>
				</view>
			</view>
			<view class="xian"></view>
			<view class="make-collections">
				<view class="call">
					<view class="beneficiaryName">Branch</view>
					<view class="">{{BankUser}}</view>
					<view class="duplicate" @click="copy(BankUser)">Copy</view>
				</view>
			</view>
			<view class="xian"></view>
			<!-- 密码 -->
			<view class="make-collections">
				Account type - Current
				<view class="call">
					<!-- <view class="beneficiaryName">Passward</view> -->
					<view class="beneficiaryinput">
						<u-input placeholder="Enter  password " type="password" v-model="value3"></u-input>
					</view>
					<view class="duplicate" style="color: red; font-weight: 900;" @click="testVerify()">Verify</view>
				</view>
			</view>
		</view>
		<view v-show="Inv == 1">
			<view class="collections">
				<view class="call">
					<view class="beneficiaryName">Corporate Name</view>
					<view class="">{{BankUser_2}}</view>
					<view class="duplicate" @click="copy(BankUser_2)">Copy</view>
					<!-- <view class="duplicate" @tap="customer()">客服</view> -->
				</view>
			</view>
			<view class="xian"></view>
			<view class="make-collections">
				<view class="call">
					<view class="beneficiaryName">Acc number</view>
					<view class="">{{BankName_2}}</view>
					<view class="duplicate" @click="copy(BankName_2)">Copy</view>
				</view>
			</view>
			<view class="xian"></view>

			<view class="make-collections">
				<view class="call">
					<view class="beneficiaryName">IFSC</view>
					<view class="">{{BankNO_2}}</view>
					<view class="duplicate" @click="copy(BankNO_2)">Copy</view>
				</view>
			</view>
			<view class="xian"></view>
			<!-- 密码 -->
			<!-- <view class="make-collections">
				<view class="call">
					<view class="beneficiaryName">输入密码</view>
					<view class="beneficiaryinput">
						<u-input placeholder="输入密码,可查看银行信息" type="password" v-model="value4"></u-input>
					</view>
					<view class="duplicate" style="color: red; font-weight: 900;" @click="testVerify_2()">验证</view>
				</view>
			</view> -->
		</view>



		<view class="xian"></view>

		<!-- 查看 -->
		<view class="make-collections">
			<view class="call">
				<view class="beneficiaryName">Charging record</view>
				<view class=""></view>
				<view class="duplicate" @tap="capitalDetails()">Check</view>
			</view>
		</view>
		<view class="xian"></view>
		<!-- 充值金额 -->

		<view class="recharge">
			<view class="title">Charge amount</view>
			<view class="minimum" style="font-size: 16px;">The minimum recharge amount is <text>10000 INR</text> </view>
			<input placeholder="Please enter the recharge amount" type="number" v-model="value1"></input>
			<view class="select">
				<view class="" :style="{ 'background':shadow,'color':character}" @click="quantity('50000')">50000
				</view>
				<view class="" :style="{ 'background':shadow1, 'color':character1}" @click="quantity('100000')">100000
				</view>
				<view class="" :style="{ 'background':shadow2, 'color':character2}" @click="quantity('300000')">300000
				</view>
				<view class="" :style="{ 'background':shadow3, 'color':character3}" @click="quantity('500000')">500000
				</view>

			</view>


		</view>

		<view class="uploadVoucher">Upload Receipt</view>
		<view class="success">
				<u-upload :fileList="fileList6" @afterRead="afterRead" @delete="deletePic" name="6" multiple :maxCount="1" width="" height="200"  style="z-index: 10;">
					<view class="" style="text-align: center;margin: 30rpx 0; font-size: 24rpx;color: #95918a;">Click to upload proof of successful transfer.</view>
					
						<image src="../../../../static/my/22.png" mode="heightFix" style="margin: 0 auto;"></image>
					
					
				</u-upload>
		</view>
		
		<view class="recharge">
			<input placeholder="Please fill in transaction UTR  code" type="number" v-model="utr"></input>
		</view>
		
		<view class="purchase" @click="to_recharge()" style="z-index: 9999;">Recharge now</view>



		<view class="point-out">
			<view class="">Friendly tips</view>
			<view>1.Deposit time: Weekdays 09:00~18:00, closed on public holidays.</view>
			<view>2.Thank you for choosing us. To ensure the safety of your funds,
Please make sure that the account you wish to transfer is one that is displayed in real time on the platform.
Please check with staff each time you transfer.
You are responsible for any losses incurred by depositing funds from a bank account other than the account displayed in real time on the Platform.</view>
		</view>
		<view style="height: 30rpx;"></view>



	</view>
</template>

<script>
	import {
		pathToBase64
	} from '@/utils/js_sdk.js'
	export default {
		data() {
			return {
				customerService: 'Please contact customer service to view.',
				value1: '',
				shadow: '',
				shadow1: '',
				shadow2: '',
				shadow3: '',
				character: '',
				character1: '',
				character2: '',
				character3: '',
				utr:"",
				fileList6: [],
				userInformation: "",
				queryFunction: '',
				value3: '',
				value4: "",
				// lookOver: "",
				BankUser: '',
				BankName: '',
				BankNo: '',
				IFSC: '',
				BankUser_2: '',
				BankName_2: '',
				BankNO_2: '',
				current: 0,
				list1: [{
						name: 'Channel 1'
					},
					{
						name: 'Channel 2'
					},
				],
				Inv: 0,
				items: ['Channel 1', 'Channel 2']
			};
		},
		methods: {

			//选项卡
			strike(item) {
				// console.log(item);
				this.current = item.index;
			},
			//选项卡
			changeTab(Inv) {
				that.navIdx = Inv;

			},
			home() {
				uni.switchTab({
					url: '/pages/my/my'
				});
			},
			//客服
			customer() {
				uni.navigateTo({
					url: '/pages/index/components/customer/customer'
				});
			},

			//充值记录
			capitalDetails() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/my/components/commonFunctions/capitalDetails?index=1'
				});
			},



			copy(value) {
				//提示模板
				if (value == '') {
					uni.$u.toast('Please check your password first');
				} else {
					uni.setClipboardData({
						data: value, //要被复制的内容
						success: () => { //复制成功的回调函数
							// console.log(value);
							uni.showToast({
								title: 'Copied Successfully',
								duration: 2000,
								icon: 'success'
							})
						}
					});
				}

			},
			quantity(value1) {
				if (value1 == 50000) {
					this.value1 = 50000
					// this.shadow = "#ea4445";
					// this.character = "#fff";
				}
				// else if (value1 != 50000) {
				// 	this.shadow = "";
				// 	this.character = "";
				// }
				if (value1 == 100000) {
					this.value1 = 100000
					// this.shadow1 = "#ea4445";
					// this.character1 = "#fff";
				}
				// else if (value1 != 100000) {
				// 	this.shadow1 = "";
				// 	this.character1 = "";
				// }
				if (value1 == 300000) {
					this.value1 = 300000
					// this.shadow2 = "#ea4445";
					// this.character2 = "#fff";
				}
				// else if (value1 != 300000) {
				// 	this.shadow2 = "";
				// 	this.character2 = "";
				// }
				if (value1 == 500000) {
					this.value1 = 500000
					// this.shadow3 = "#ea4445";
					// this.character3 = "#fff";
				}
				// else if (value1 != 500000) {
				// 	this.shadow3 = "";
				// 	this.character3 = "";
				// }
				// if (value1 != 50000 || value1 != 100000 || value1 != 300000 || value1 != 500000) {
				// 	// this.shadow3 = "";
				// 	// this.character3 = "";
				// }
			},
			// 回调参数为包含columnIndex、value、values
			async to_recharge() {
				uni.showLoading({
					title: "Charging. Please wait a moment....",
					mask: true, // 显示透明蒙层，防止触摸穿透
				});
				let list = await this.$http.post('api/app/recharge', {
					money: this.value1,
					type: 5,
					image: this.is_url,
					desc: this.value2,
					utr:this.utr
				})

				if (list.data.code == 0) {
					uni.$u.toast(list.data.message);
					this.value2 = '';
					this.value1 = '';
					this.is_url = '';
					this.fileList6 = [];
					this.title = 'Bank card',
						setTimeout(() => {
							uni.switchTab({
								url: '/pages/my/my'
							});
							uni.hideLoading();
						}, 2000)
				} else {
					uni.$u.toast(list.data.message);
					uni.hideLoading();
					// if (list.data.message === '充值金额错误') {
					// 	uni.$u.toast('请填写充值金额金额');
					// } else if (list.data.message === '您还未实名') {
					// 	uni.$u.toast('请先实名认证');
					// 	setTimeout(() => {
					// 		uni.navigateTo({
					// 			url: '/pages/index/components/openAccount/openAccount'
					// 		});
					// 		uni.hideLoading();
					// 	}, 2000)

					// } else if (list.data.message === '请先添加银行卡信息') {
					// 	uni.$u.toast('请先添加银行卡');
					// 	setTimeout(() => {
					// 		uni.navigateTo({
					// 			url: '/pages/my/components/bankCard/renewal'
					// 		});
					// 		uni.hideLoading();
					// 	}, 2000)
					// }
					// uni.$u.toast(list.data.message);
					// if (list.data.message != '您还未实名' || '请先添加银行卡信息') {

					// }
				}
			},

			//凭证
			deletePic(event) {
				this[`fileList${event.name}`].splice(event.index, 1)
			},
			// 新增图片
			async afterRead(event) {
				// 当设置 multiple 为 true 时, file 为数组格式，否则为对象格式
				let lists = [].concat(event.file)
				let fileListLen = this[`fileList${event.name}`].length
				lists.map((item) => {
					this[`fileList${event.name}`].push({
						...item,
					})
				})
				for (let i = 0; i < lists.length; i++) {
					const result = await this.uploadFilePromise(lists[i].url)
					let item = this[`fileList${event.name}`][fileListLen]
					this[`fileList${event.name}`].splice(fileListLen, 1, Object.assign(item, {
						status: 'success',
						message: '',
						url: result
					}))
					fileListLen++
				}
			},
			//个人信息
			async gaint_info() {
				let list = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				})
				this.userInformation = list.data.data
			},
			uploadFilePromise(url) {
				// console.log(url)
				pathToBase64(url).then(base64 => {
						// 这就是转为base64格式的图片
						this.is_url = base64
						// console.log(base64)
					})
					.catch(error => {
						console.error(error)
					})
			},
			//显示银行信息
			async queryPassword() {
				let list = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				})
				this.queryFunction = list.data.data.bank_card_info
				// console.log(this.queryFunction, '收款人银行');
			},
			//点击验证
			async testVerify() {
				if(!this.value3){
					return uni.$u.toast('Please enter password');
				}
				let list = await this.$http.get('api/app/config', {
					// language: this.$i18n.locale
					
				})
				let password=list.data.data[7].value
				if(password!=this.value3){
					return uni.$u.toast('Incorrect password');
				}
				this.BankUser = list.data.data[3].value
				this.BankName = list.data.data[2].value
				this.BankNo = list.data.data[1].value
				this.IFSC = list.data.data[17].value
				this.Corporate=list.data.data[21].value
				
				uni.hideLoading();
			

			},
		},

		onLoad(option) {
			this.gaint_info()
			// this.testVerify()
		},
		
	}
</script>

<style lang="scss">
	.college-bg {
		padding: 60rpx 30rpx 0;
		height: 280rpx;
		background-image: linear-gradient(to right, #1a73e8, #5ef7d1);


		.account {
			display: flex;
			text-align: center;
			justify-content: space-between;
			align-items: center;

			image {
				width: 20rpx;
				height: 40rpx;

			}

			.college-text {

				color: #fff;
				font-weight: 800;
				font-size: 36rpx;
			}
		}

		.progress {
			text-align: center;
			font-size: 52rpx;
			color: #fff;
			// font-weight: 600;
			margin: 60rpx 0 10rpx;
		}

		.vacancies {
			text-align: center;
			color: #f47b78;
			font-size: 26rpx;
		}
	}

	.xian {
		width: 100%;
		height: 2rpx;
		background: #e9e9e9;
	}

	/deep/.u-tabs {
		border-radius: 30rpx 30rpx 0 0 !important;
		margin-top: -30rpx !important;
		background: #fff;
	}

	/deep/.u-tabs__wrapper__nav {
		justify-content: space-around;
	}

	.collections {
		// border-radius: 30rpx 30rpx 0 0;
		// margin-top: -30rpx;
		background: #fff;
		padding: 20rpx 30rpx;

		.call {
			display: flex;
			justify-content: space-between;
			align-items: center;
			// border-bottom: 2rpx solid #e0e0e0;
			padding: 20rpx 0;
			font-size: 26rpx;

			.beneficiaryName {
				color: #000;
				font-weight: 700;
			}

			.duplicate {
				color: #000;
				font-weight: 700;

			}
		}
	}

	.make-collections {
		// border-radius: 30rpx 30rpx 0 0;
		// margin-top: -30rpx;
		// background: #fff;
		padding: 20rpx 30rpx;

		.call {
			display: flex;
			justify-content: space-between;
			align-items: center;
			// border-bottom: 2rpx solid #e0e0e0;
			padding: 20rpx 0;
			font-size: 26rpx;

			.beneficiaryName {
				color: #000;
				font-weight: 700;
			}

			.duplicate {
				color: #000;
				font-weight: 700;

			}
		}
	}

	//充值金额
	.recharge {
		margin: 30rpx;
		font-size: 28rpx;

		.title {
			color: #333;
		}

		.minimum {
			color: #999;
			font-size: 26rpx;
			margin: 20rpx 0;

			text {
				color: #ffa1a1;
			}
		}

		input {
			background: #f5f5f5;
			border-radius: 10rpx;
			color: #000;
			padding: 30rpx 20rpx;
			font-size: 28rpx;
		}

		.select {
			display: flex;
			justify-content: space-between;
			align-items: center;
			margin: 30rpx 0;
			font-size: 28rpx;

			view {
				background: #f5f5f5;
				color: #999;
				border-radius: 10rpx;
				width: 23%;
				text-align: center;
				padding: 20rpx 0;
			}

			.shadow {
				background-image: linear-gradient(to right, #1a73e8, #014b8d);
			}
		}
	}


	.cash-withdrawal {

		padding: 30rpx;

		.withdrawal {
			color: #333;
		}

		.money {
			display: flex;
			justify-content: space-between;
			align-items: center;
			background: #f5f5f5;
			padding: 30rpx;
			margin: 20rpx 0;
			border-radius: 10rpx;

		}
	}

	.purchase {
		background-image: linear-gradient(to right, #1a73e8, #014b8d);
		margin: 30rpx;
		border-radius: 10rpx;
		padding: 20rpx 0;
		text-align: center;
		color: #fff;
		font-weight: 600;
		font-size: 30rpx;
	}

	.uploadVoucher {
		margin: 30rpx;
		color: #333;
		font-size: 28rpx;
	}

	.success {
		// width: 100%;
		height: 420rpx;
		margin: 30rpx;
		display: flex;
		
		image {
			width: 100%;
			height: 100%;
		}
		
		/deep/.u-upload__wrap {
			width: 100% !important;
			height: 400rpx !important;
			flex-wrap: nowrap;
			flex: none;

			view {
				width: 100%;
			}
		}

		/deep/.u-upload__wrap__preview__image {
			height: 420rpx !important;
		}

		/deep/.u-upload__wrap__preview__image {
			width: 100% !important;
		}

		/deep/ .u-upload__deletable {
			width: 14px !important;
		}

		/deep/ .u-upload__success {
			width: 60rpx !important;
			border-right-color: transparent;
		}
	}

	.point-out {
		margin: 30rpx;
		color: #666;
		font-size: 28rpx;

	}

	.beneficiaryinput {
		width: 80%;
		word-break: break-word; //文本超出 自动换行

		input {
			word-break: break-word; //文本超出 自动换行
			font-size: 26rpx;
			overflow: hidden;
			white-space: nowrap;
			text-overflow: ellipsis;
			text-align: left;
		}
	}

	.inv-h-w {
		background-color: #FFFFFF;
		display: flex;
		justify-content: space-between;
		align-items: center;
		border-radius: 30rpx 30rpx 0 0 !important;
		margin-top: -30rpx !important;
		padding: 30rpx 100rpx;

	}

	.inv-h {
		font-size: 28rpx;
		flex: 1;
		text-align: center;
		color: #666666;
		position: relative;

	}

	.inv-h-se {
		font-size: 28rpx;
		color: #fff;
		background: #f85252;
		border-radius: 40rpx;
		padding: 10rpx 0;
	}

	.inv-h-se:after {
		content: '';
		position: absolute;
		bottom: -2rpx;
		top: auto;
		left: 42%;
		height: 6rpx;
		width: 44rpx;
		background-color: #4DB046;
		display: none;
	}
</style>