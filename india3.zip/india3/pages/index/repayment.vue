<template>
	<view>
		     <!-- 贷款信息展示 -->
			<view class="college-bg">
				<image src="@/static/zuojiantou.png" mode="" @tap="home()"></image>
				<view class="college-text">Repayment</view>
				<view class=""></view>
			</view>
			<view class="college-content">
				<view class="hui2">
					Total borrowing
				</view>
				<view class="cipher" >
					<text>Total borrowing:{{data.new_amount}}</text>
				</view>
				<view class="hui2">
					Total repayment
				</view>
				<view class="cipher">
					<span>Total repayment: {{data.hk_amount}}</span>
				</view>
				
				<view class="hui2"> 
					Remaining repayment
				</view>
				<view class="cipher">
				<span>Remaining repayment: {{data.sy_amount}}</span>
				</view>
			</view>
	
		<!-- 	<view class="purchase" @click="submit">
				Confirm
			</view> -->
			
			<!-- <u-picker :show="show" :columns="columns" confirmText="Confirm" cancelText="Cancel" @confirm="jigou_click" @cancel="show=false"></u-picker> -->
		</view>
</template>

<script>
	export default {
		data() {

			return {
				list: '',
				item: '',
				data:''
			}
		},
		onload(){
			// 页面加载的时候执行，只执行一次
		},
		onShow() {
			// 页面显示的时候执行
			this.shengou()
		},
		methods: {
			
			home() {
				uni.navigateBack({
					delta: 1, //返回层数，2则上上页
				});
			},
		
			async shengou() {  
			    try {  
			        let response = await this.$http.post('api/app/chakan', {  
			            // 如果有其他需要的参数，可以在这里添加  
			        });  
			        console.log(7777,response)
			        this.data=response.data.data
					// if()
			    } catch (error) {  
			        // 处理请求错误  
			        console.error('Error fetching data from the server:', error);  
			    }  
			},
			
			//版本更新
			is_token() {
				let token = uni.getStorageSync('token') || '';
			},
		},


	}
</script>

<style lang="scss">
	.college-bg {
		padding: 60rpx 30rpx 0;
		height: 100rpx;
		background-image: linear-gradient(to right, #1a73e8, #014b8d);
		display: flex;
		justify-content: space-between;
		// align-items: center;
		text-align: center;
	
		image {
			width: 20rpx;
			height: 40rpx;
		}
	
		.college-text {
	
			color: #fff;
			font-weight: 800;
			font-size: 36rpx;
		}
	
	}
	
	.college-content {
		margin-top: -30rpx;
		border-radius: 30rpx 30rpx 0 0;
		background: #fff;
		padding: 30rpx;
	
		.cipher {
			padding: 20rpx;
			margin: 30rpx 0;
			background: #f5f5f5;
			border-radius: 10rpx;
	
		}
	
	}
	
	/deep/.uni-input-placeholder {
		color: #C0C4CC;
		font-size: 28rpx;
	}
	
	.purchase {
		background-image: linear-gradient(to right, #1a73e8, #014b8d);
		margin: 60rpx 30rpx;
		border-radius: 10rpx;
		padding: 20rpx 0;
		text-align: center;
		color: #fff;
		font-weight: 600;
	}
</style>