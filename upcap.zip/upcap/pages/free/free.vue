<!-- 收藏的 -->
<template>
	<view>
		<view class="bg_free">
			<Header :title="$lang.FAVORITES"></Header>
		</view>
		<view class="common_block" style="padding: 10px;margin-top: 0;">
			<view style="display: flex;align-items: center;border-bottom: 1px solid #ccc;padding-bottom:10px; ">
				<text style="flex:40%;color: #91a2b1;">주식/코드</text>
				<text style="flex:20%"></text>
				<text style="flex:20%;color: #91a2b1;">등락률</text>
				<text style="flex:10%;color: #91a2b1;">최신</text>
			</view>

			<view style="min-height:64vh;">
				<view class="padding-20 flex" v-for="(item,index) in business"
					@click="$u.route('/pages/productDetails/productDetails',{code:item.goods.number_code});"
					style="padding: 6px;width: 96%;display: flex;line-height: 36px;border-bottom:1px solid #e3ebfa;"
					:style="{backgroundColor:index%2===0?'#fff':'#f0f3fa'}">
					<view style="display: inline-block;flex:10%;color: #4b5fcc;">{{item.goods.number_code}}</view>
					<view style="margin-left:10px;display: inline-block;flex:46%;">
						{{item.goods.name}}
					</view>
					<text style="display: inline-block;flex:14%;margin:0 10px;color: #181945;"
						:style="{color:item.goods.rate>0?'#ff3636':'#2DD872'}">{{$util.formatNumber(item.goods.current_price*1)}}
					</text>
					<view style="border-radius: 3px;font-weight: 700; display: inline-block;flex:16%;"
						:style="{color:item.goods.rate>0?'#ff3636':'#2DD872'}">
						{{item.goods.rate>0?'+':""}}{{(1*item.goods.rate).toFixed(2)}}%
					</view>
					<view style="flex: 4%;margin-left:10px;">
						<image style="width: 12px; height: 12px;" mode="aspectFit" src="/static/star2.png"></image>
					</view>
				</view>
				<EmptyData v-if="business.length<=0"></EmptyData>
			</view>
		</view>
	</view>
</template>

<script>
	import Header from '@/components/Header.vue';
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		components: {
			Header,
			EmptyData
		},
		data() {
			return {
				downloadUrl: '',
				updateDesc: "",
				update: '',
				closeOnClickOverlay: false,
				business: '',
				updata: true,
				// exchange: '',
				timerId: null
			}
		},
		//页面显示了，会触发多次，只要页面隐藏，然后再显示出来都会触发
		onShow() {
			this.free()
			// this.market()
			// this.is_token()
			this.startTimer()
		},
		onLoad() {
			this.startTimer()
		},
		onUnload() {
			clearInterval(this.timerId);
		},
		onHide() {
			clearInterval(this.timerId);
		},
		methods: {
			//产品세부
			productDetails(gid) {
				uni.navigateTo({
					url: `/pages/productDetails/productDetails?gid=${gid}`
				});
			},

			async free() {
				let list = await this.$http.get('api/user/collect_list', {})
				this.business = list.data.data.list;
			},

			// async market() {
			// 	let list = await this.$http.get('api/goods/updownlist', {
			// 		page: 1,
			// 		limit: 10,
			// 	})
			// 	//上证指数
			// 	this.exchange = list.data.data.zhishu
			// },
			//定时器
			startTimer() {
				const storedTimerId = uni.getStorageSync('timerId');
				if (storedTimerId) {
					clearInterval(storedTimerId);
				}
				this.timerId = setInterval(() => {
					this.free();
					// this.market()
				}, 5000);
				uni.setStorageSync('timerId', this.timerId);
				// 在这里立即执行一次请求
			},
		},
	}
</script>