<!-- 个人交易 交易信息 -->
<template>
	<view>
		<view class="bg_trade_info" style="padding: 10px;">
			<view class="flex margin-top-10  radius20" style="padding: 10px 0;background-color: #e5f8fd;width: 96%;margin-left: 2%;">
				<view class="bold font-size-16" style="padding-left: 20px;" >205-01-{{info.uid}}
				</view>
				<view class="font-size-10 " >[CMA]{{info.real_name}}</view>
			</view>
			<view class="flex flex-b margin-top-20">
				<view style="font-size: 18px;padding-left: 2%;color: #fff;" >
					균형<text class="bold">{{$util.formatNumber(info.money)}}</text>
				</view>
				<view class="common_btn " style="width: 20%;margin-right: 10px;background-color: #169FBD;color: #fff;padding: 2px 20px;" @click="handleDeposit">{{$lang.DEPOSIT}}</view>
			</view>
		</view>
		<view class="common_block" style="padding:10px;margin-top: 10px;">
			<view style="display: flex;align-items: center;line-height: 2.5;">
				<view class="trade_info_item">
					<view style="display: inline-block;width: 75px;" :style="{color:$util.THEME.TIP}">
						{{$lang.TOTAL_BUY_AMOUNT}}
					</view>
					<view style="display: inline-block;text-align: right;" :style="{color:$util.THEME.PRIMARY}">
						{{$util.formatNumber(info.frozen)}}
					</view>
				</view>
				<view class="trade_info_item">
					<view style="display: inline-block;width: 75px;" :style="{color:$util.THEME.TIP}">
						{{$lang.VALUATION_GAIN_LOSS}}
					</view>
					<view style="display: inline-block;text-align: right;" :style="{color:$util.THEME.TEXT}">
						{{$util.formatNumber(info.holdYingli)}}
					</view>
				</view>
			</view>
			<view style="display: flex;align-items: center;line-height: 2.5;">
				<view class="trade_info_item">
					<view style="display: inline-block;width: 75px;" :style="{color:$util.THEME.TIP}">
						{{$lang.VALUATION_GAIN_LOSS_AMOUNT}}
					</view>
					<view style="display: inline-block;text-align: right;" :style="{color:$util.THEME.TEXT}">
						{{$util.formatNumber(info.guzhi)}}
					</view>
				</view>
				<view class="trade_info_item">
					<view style="display: inline-block;width: 75px;" :style="{color:$util.THEME.TIP}">
						{{$lang.RATE_RESPONSE}}
					</view>
					<view style="display: inline-block;text-align: right;" :style="{color:$util.THEME.TEXT}">
						{{info.huibao}}%
					</view>
				</view>
			</view>

			<view style="display: flex;align-items: center;line-height: 2.5;">
				<view class="trade_info_item">
					<view style="display: inline-block;width: 75px;" :style="{color:$util.THEME.TIP}">
						{{$lang.AMOUNT_TOTAL}}
					</view>
					<view style="display: inline-block;text-align: right;" :style="{color:$util.THEME.TEXT}">
						{{$util.formatNumber(info.totalZichan)}}
					</view>
				</view>
				<view class="trade_info_item">
					<view style="display: inline-block;width: 75px;" :style="{color:$util.THEME.TIP}">
						{{$lang.TOTAL_GAIN}}
					</view>
					<view style="display: inline-block;text-align: right;"
						:style="$util.calcStyleRiseFall(info.totalYingli>0)">
						{{$util.formatNumber(info.totalYingli)}}
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		name: "TradeInfo",
		data() {
			return {
				info: {},
			};
		},
		mounted() {
			this.getUserInfo()
		},
		methods: {
			handleDeposit() {
				uni.navigateTo({
					url: this.$util.PAGE_URL.ACCOUNT_DEPOSIT
				});
			},
			async getUserInfo() {
				uni.showLoading({
					title: this.$lang.LOADING,
				})
				const result = await this.$http.get(this.$http.API_URL.USER_INFO, {})

				if (result.data.code == 0) {
					this.info = result.data.data;
					uni.hideLoading()
				} else {
					uni.$u.toast(result.data.message);
					uni.hideLoading()
				}
			},
		}
	}
</script>