<template>
	<view>
		<u-tabs :list="list1" style="margin: 10px 10px;border-bottom: 5px solid #f5f5f5;border-top: 5px solid #f5f5f5;"
			activeStyle="color:#014bab;font-weight: 700;" lineColor="#014bab" @change="change" :current="current">
			<view slot="left" style="padding-left: 4px;" @tap="show=true">
				<u-icon name="/static/icon/more.png" size="21" bold></u-icon>
			</view>
		</u-tabs>
		
		<u-picker :show="show" :columns="columns" keyName="name" :defaultIndex="[current]" cancelText="취소" confirmText="확신하는" :closeOnClickOverlay="true" @close="show=false" @cancel="show=false" @confirm="changes"></u-picker>
		
		<view >
			<view class="list">
				<view class="nav-box" v-if="current<=1">
					<view class="nav-item" :class="current1==0?'active':''" @click='qiehuan(0)'>당일<span></span></view>
					<view class="nav-item" :class="current1==1?'active':''" @click='qiehuan(1)'>1주일<span></span></view>
					<view class="nav-item" :class="current1==2?'active':''" @click='qiehuan(2)'>1개월<span></span></view>
					<view class="nav-item" :class="current1==3?'active':''" @click='qiehuan(3)'>3개월<span></span></view>
					<view class="nav-item" :class="current1==4?'active':''" @click='qiehuan(4)'>6개월<span></span></view>
				</view>
				<view class="flex flex-b titles">
					<view class="flex-2">종목명</view>
					<view class="flex-1 t-r">현재가</view>
					<view class="flex-1 t-r">등락률</view>
				</view>
				<view class="item flex flex-b" v-for="(item,index) in list" @click="$u.route('/pages/marketQuotations/productDetails',{code:item.code});">
					<view class="t flex-2"><span class="t" style="margin-right: 10px;" :class="index>2?'num':''">{{index+1}} </span> {{item.ko_name}}</view>
					<view class="t1 flex-1 t-r num-font" :class="item.returns>0?'':'die'">{{item.close.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</view>
					<view class="t1 flex-1 t-r" :class="item.returns>0?'':'die'">{{(item.returns*1).toFixed(2)}}%</view>
					
				</view>
				
				
			</view>
			<view style="text-align: center;color: #999999;" class="content-end-text">특징종목은 총 100위까지<br>순위만 제공합니다.</view>
		</view>
	</view>
</template>

<script>
	export default {
		name: 'TabOne',
		components: {},
		props: {},
		data() {

			return {
				show:false,
				list1: [{
					name: '상승률',
				}, {
					name: '하락률',
				}, {
					name: '신고가'
				}, {
					name: '거래량 상위/하위'
				}, {
					name: '거래대금 상위/하위'
				}, {
					name: '외국인 순매수'
				}, {
					name: '기관 순매수'
				}, {
					name: '신규상장'
				}, {
					name: '공매도 비중'
				}],
				columns:[[{
					name: '상승률',
				}, {
					name: '하락률',
				}, {
					name: '신고가'
				}, {
					name: '거래량 상위/하위'
				}, {
					name: '거래대금 상위/하위'
				}, {
					name: '외국인 순매수'
				}, {
					name: '기관 순매수'
				}, {
					name: '신규상장'
				}, {
					name: '공매도 비중'
				}]],
				list:[],
				page:1,
				current1:0,
				current:0,

			}
		},

		methods: {
			
			async lists() {
				uni.showLoading({
			
				})
				let list = await this.$http.post('api/goods/paihang', {
					current: this.current,
					current1: this.current1,
				})
				this.list = list.data.data
				uni.hideLoading()
			},
			qiehuan(index) {
				console.log(index)
				this.current1 = index;
				this.lists()
			},
			change(index) {
				console.log(index)
				this.current = index.index;
				this.current1 = 0;
				this.lists()
			},
			changes(index) {
				console.log(index)
				this.current = index.indexs[0];
				this.current1 = 0;
				this.show=false;
				this.$forceUpdate()
				this.lists()
			},
		},

		mounted() {
			
			this.lists()
		},

		onLoad() {},
		onUnload() {
			clearInterval(this.timerId);
		},
		onHide() {
			clearInterval(this.timerId);
		},
	}
</script>

<style lang="scss">
	view,
	text {
		box-sizing: border-box;
	}
	.list {
	    padding: 0 0 10px;
		.titles{
		    padding: 10px;
			uni-view{
			    color: #91a2b1;
			}
		}
		.item {
		    padding: 10px;
			.t {
			    font-size: 16px;
			    font-weight: 700;
			    color: #333;
			}
			.t1 {
			    color: #ff3636;
			    font-weight: 600;
			}
			.t1.die {
			    color: #014b8d;
				font-weight: 600;
			}
			.num{
			    color: #999;
			}
		}
	}
	
	.t-r {
	    text-align: right;
	}
	.nav-box{
	    height: 50px;
	    border-bottom: 1px solid #ccc;
	    display: -webkit-box;
	    display: -webkit-flex;
	    display: flex;
	    -webkit-box-align: center;
	    -webkit-align-items: center;
	    align-items: center;
	    -webkit-box-pack: center;
	    -webkit-justify-content: center;
	    justify-content: center;
		
		.nav-item {
		    height: 50px;
		    width: 50%;
		    display: -webkit-box;
		    display: -webkit-flex;
		    display: flex;
		    -webkit-box-orient: vertical;
		    -webkit-box-direction: normal;
		    -webkit-flex-direction: column;
		    flex-direction: column;
		    -webkit-box-align: center;
		    -webkit-align-items: center;
		    align-items: center;
		    -webkit-box-pack: end;
		    -webkit-justify-content: flex-end;
		    justify-content: flex-end;
		    font-size: 16px;
		    color: #333;
			span {
			    width: 100%;
			    height: 3px;
			    background: transparent;
			    margin-top: 10px;
			    display: block;
			}
		}
		.active{
		    font-size: 16px;
		    font-weight: 700;
		    color: #014b8d;
			span{
			    background: #014b8d;
			}
		}
	}
</style>