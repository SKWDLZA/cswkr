<template>
	<view class="page">
		<view>
			<view class="header flex flex-b" >
				<view class="icon jiantou" @click="$u.route({type:'navigateBack'});"></view>
				<view class="header-center flex-1">스마트 주문</view><!---->
				<view class="icon ss" @click="$u.route({url:'/pages/searchFor/searchFor'});"></view>
			</view>
		</view>
		<view style="margin-top: 20px;"></view>
		<u-subsection :height="top_hg" :list="top_list" :current="current" bgColor="#1e50dd" inactive-color="#fff" active-color="#ff3636" @change="sectionChange"></u-subsection>
		
		<view class="list" v-if="current==0">

			<view class="item"  v-for="(item,index) in list" @click="buy(index)">
				<view class="flex"  >
					<view class="t flex-1">{{item.name}}</view>
					<view class="flex-1 t-r"><span class="b-btn bt">종료</span></view>
				</view>
				<view class="flex flex-b">
					<view class="flex-1">
						<view class="per">{{item.syl}}</view>
						<view class="t1">최고수익률</view>
					</view>
					<view class="flex-1">
						<view class="t2 num-font t-r">{{item.zhouqi}} 일</view>
						<view class="t1 t-r">주기</view>
					</view>
				</view>
			</view>
		</view>
		
		<view v-if="current==1">
			<u-row justify="between" gutter="20">
				<u-col span="12" >
					<u-cell-group customStyle='margin:10rpx;border:1px solid #666666 ' v-for="(item,index) in order_list">
						<u-cell icon="order" :title="item.goodname" :value="item.zhouqi+' 일'"></u-cell>
						<u-cell title="구매 금액" :value="toThousandFilter(item.price)"></u-cell>
						<u-cell title="기간" :value="item.zhouqi+' 일'"></u-cell>
						<u-cell title="구입 날짜" :value="item.cretime"></u-cell>
						<u-cell title="마감일" :value="item.endtime"></u-cell>
						<u-cell title="거래 ID" :value="item.ordersn"></u-cell>
						
						<u-cell title="증거금(레버리지)" :value="item.ganggan"></u-cell>
						
						<u-cell title="수익률 %" :value="item.fudul"></u-cell>
						
						
						<u-cell  style="font-weight: 700;"  v-if="item.status==1">
						
							<u-button color="#1e50dd"  @click="sell(item.id)" slot="value">매도</u-button>
						</u-cell>
					
					</u-cell-group>
				</u-col>
			</u-row>
		</view>

		<u-popup :show="show_buy" @close="close" :round="20" mode="bottom" :closeable='true'>
			<view class="largeAmount">
				<view class="business">
					{{goods_buy.name}}
				</view>
				<view class="price">최고수익률</view>
				<view class="purchase-price">{{goods_buy.syl}}</view>
				<view class="purchase-text">
					<u-input type="number" placeholder="구매금액을 입력해주세요" v-model="price" border="none"></u-input>
					<!-- <view class="hand">股</view> -->
				</view>
				<!-- <view class="amount">购买金额 <text>{{detailId.price*this.value1|addZero}} </text> </view> -->
				<!-- <view class="available">
					<u-input type="password" placeholder="请输入资金密码" v-model="value2"></u-input>
				</view> -->
				
				<!-- <view class="available">
					<u-input type="password" placeholder="请输入股东减持密码" v-model="value3"></u-input>
				</view> -->
				
				<view class="fund">구매가능잔액<text>{{userinfo.money.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</text>
				</view>
				<view class="purchase" @click="confirm()">매수</view>
			</view>
		</u-popup>
	</view>


</template>

<script>
	export default {
		data() {
			return {
				ganggan: 1,
				actions: [{
					name: '1',
					index: 1
				}],
				top_list: [{
						name: '종목'
					},
					{
						name: '구매 내역'
					}
				],
				current: 0,
				top_hg: 80,
				show_js: false,
				title: "",
				content: "",
				show_buy: false,
				list: [],
				jijin_name: '',
				goods_buy: [],
				price: '',
				order_list: [],
				xiangqing_show: false,
				xq_list: [],
				userinfo:""
			};
		},
		onShow() {
			this.getlist()
			this.userInfo()
		},
		methods: {

			async sell(id) {
				uni.showModal({
					content: "정말로 매도하시 겠습니까?",
					cancelText: "취소",
					confirmText: "확인",
					success: (res) => {
						if (res.confirm) {
							this._sell(id)
						} else {
							console.log('cancel') //点击取消之后执行的代码
						}
					}

				})

			},
			async _sell(id) {
				var list = await this.$http.get('api/jijin/sell', {
					id: id,
				})
				uni.hideLoading()
				if (list.data.code == 1) {

					uni.$u.toast(list.data.message);
				} else {
					uni.$u.toast(list.data.message);
					this.getlist()
				}
			},
			toThousandFilter(num) {
				return (+num || 0).toFixed(0).replace(/\d{1,3}(?=(\d{3})+(\.\d*)?$)/g, '$&.')
			},
			Select(e) {
				console.log(e);
				this.ganggan = e.index
				// this.columns = this.detailedData.ganggan
				// console.log(this.title, '99999');
			},
			//实名认证
			async userInfo() {
				let list = await this.$http.get('api/user/fastInfo', {})
				this.userinfo=list.data.data
				if (list.data.code == 1) {
					uni.reLaunch({
						url: "/pages/logon/logon/logon"
					})
				}
				this.actions = list.data.data.ganggan
			},
			async xiangqing(id) {

				var list = await this.$http.post('api/jijin/info', {
					id: id,

				})

				console.log(list)
				this.xq_list = list.data
				this.xiangqing_show = true
			},
			buy(index) {
				this.jijin_name = this.list[index].name
				this.show_buy = true
				this.goods_buy = this.list[index]
			},
			jieshao(index) {
				console.log(index);
				this.content = this.list[index].content
				this.show_js = true
			},
			confirm() {
				console.log(this.goods_buy);
				var price = this.price
				this.show_buy = false
				uni.showLoading({

				})
				if (!price || price == '') {
					console.log(price);
					// uni.showToast({
					// 	icon:'none',
					// 	title:'请输入金额'
					// })
					uni.$u.toast('금액을 입력해주세요.');
				}


				this.buy_goods(price)
			},
			async buy_goods(price) {

				var list = await this.$http.get('api/jijin/buy', {
					id: this.goods_buy.id,
					price: price,
					ganggan: this.ganggan
				})
				uni.hideLoading()
				if (list.data.code == 1) {
					this.show_buy = false
					uni.$u.toast(list.data.message);
				} else {
					uni.$u.toast("성공적으로 구매");
					this.getlist()
				}

			},
			close() {
				this.show_buy = false
				// console.log('close');
			},
			async getlist() {
				var list = await this.$http.get('api/jijin/list')
				console.log("기금 목록", list);
				this.list = list.data.jj_list
				this.order_list = list.data.order
			},
			sectionChange(index) {
				console.log(index)
				this.current = index;
				this.getlist()
			},

			home() {
				uni.switchTab({
					url: '/pages/index/index'
				});
			},
			async fundDetails(i) {
				console.log(i)
				let list = await this.$http.get('api/peizi/index', {
					index: i
				})
				uni.navigateTo({
					url: "/pages/index/components/customer/customer"
				})
			}

		}
	}
</script>

<style lang="scss">
	uni-view, uni-text {
	    box-sizing: border-box;
	}
	.page {
	    padding: 50px 0 0;
	}
	.header{
	    height: 55px;
	    background: #fff;
	    box-shadow: 0px 1px 4px 0px rgba(0,0,0,.1);
	    padding: 0 16px;
	    width: 100vw;
	    position: fixed;
	    top: 0;
	    left: 0;
	    z-index: 999;
	
		.header-left {
		    position: absolute;
		    top: 18px;
		    left: 16px;
		    width: 10px;
		    height: 18px;
		}
		.header-center {
		    font-size: 16px;
		    font-weight: 700;
		    color: #333;
		    text-align: center;
		}
	}

	.list {
		padding: 15px;
	}

	.list .item {
		padding: 15px;
		background: #fff;
		border-radius: 4px;
		margin-bottom: 10px;
		box-shadow: 0 0 5px 2px #f5f5f5;

		.t {
			font-size: 19px;
			font-weight: 700;
			color: #333;
		}

		.t1 {
			color: #91a2b1;
			margin: 16px 0;
		}

		.t2 {
			font-size: 16px;
			font-family: DINAlternate-Bold, DINAlternate;
			font-weight: 700;
			color: #1e50dd;
		}

		.per {
			font-size: 17px;
			font-family: Roboto;
			font-weight: 700;
			color: #ff3636;
		}
	}

	.list .b-btn {
		padding: 5px 25px;
		font-size: 12px;
		font-weight: 600;
		color: #fff;
	}

	.b-btn {
		width: 80%;
		height: 46px;
		line-height: 46px;
		background: #1e50dd;
		border-radius: 10px;
		text-align: center;
		font-size: 17px;
		font-weight: 500;
		color: #fff;
	}
	//弹窗
	.largeAmount {
		padding: 30rpx;
	
		.business {
			text-align: center;
			font-size: 30rpx;
			color: #333;
			border-bottom: 1rpx solid #e0e0e0;
			padding-bottom: 30rpx;
	
		}
	
		.price {
			color: #333;
			font-weight: 500;
			margin: 30rpx 0;
		}
	
		.purchase-price {
			color: #ea3544;
			margin: 10rpx;
			font-weight: 600;
		}
	
		.purchase-text {
			display: flex;
			justify-content: space-between;
			align-items: center;
			border: 1rpx solid #ffdcdc;
			padding: 0 20rpx;
			border-radius: 10rpx;
			margin: 20rpx 0;
			height: 40px;
			.hand {
				border-left: 1rpx solid #e0e0e0;
				padding-left: 30rpx;
			}
		}
	
		.amount {
			color: #999;
			font-size: 24rpx;
	
			text {
				color: #f33030;
				margin-left: 20rpx;
			}
		}
	
		.available {
			border: 1rpx solid #ebebeb;
			padding: 0 20rpx;
			border-radius: 10rpx;
			margin: 20rpx 0;
		}
	
		.fund {
			color: #999;
			font-size: 24rpx;
	
			text {
				color: #f33030;
				margin-left: 20rpx;
			}
		}
	
		.purchase {
			background-image: linear-gradient(to right, #ff757a, #f85050);
			margin: 30rpx;
			border-radius: 20rpx;
			padding: 20rpx 0;
			text-align: center;
			color: #fff;
			font-weight: 600;
	
		}
	
	}
</style>