<template>
	<view class="signin">
		<image mode="widthFix" src="/static/logo.png" :style="$util.calcImageSize(180)"></image>


		<view style="background-color: #d3e6f7;width: 100%;height: 100%;"
			class="radius50 margin-top-30 justify-center padding-top-15">

			<view class="common_input_wrapper radius30" style="background-color: rgba(255,255,255,0.85);height: 40px;">
				<image mode="aspectFit" src="/static/user.png" :style="$util.calcImageSize(20)">
				</image>
				<input style="flex:auto;" v-model="value1" type="text" placeholder="기존 비밀번호를 입력해주세요" :placeholderStyle="$util.setStylePlaceholder()"></input>
			</view>

			<view class="common_input_wrapper radius30" style="background-color: rgba(255,255,255,0.85);height: 40px;">
				<image mode="aspectFit" src="/static/password.png" :style="$util.calcImageSize(20)">
				</image>
				<input style="flex:auto;" v-model="value2" type="password" placeholder="새로운 비밀번호를 입력해주세요" :placeholderStyle="$util.setStylePlaceholder()"></input>
			</view>

			<view class="common_input_wrapper radius30" style="background-color: rgba(255,255,255,0.85);height: 40px;">
				<image mode="aspectFit" src="/static/code.png" :style="$util.calcImageSize(20)">
				</image>
				<input style="flex:auto;" v-model="value3" type="text" placeholder="새로운 비밀번호를 다시 입력해주세요" :placeholderStyle="$util.setStylePlaceholder()"></input>
				<view style="width: 80px;">
					<u-code ref="uCode" @change="codeChange" seconds="60" changeText="X초 검색"></u-code>
					<u-button @tap="getCode" text="인증 코드 받기" type="success" size="mini"></u-button>
				</view>
			</view>
			
			<view style="padding:0 10%;display: flex; align-items: center; justify-content:flex-end;">
				<view style="display: inline-block;font-size: 14px;margin-right: 4px;" :style="{color:$util.THEME.TIP}" @click="$u.route({url:$util.PAGE_URL.ACCOUNT_SIGNIN});">
					로그인하려면 클릭하세요
				</view>
			</view>

			<view style="width:90%;margin: auto;margin-top: 20px;background-color: #333077;color: #fff;height: 50px;line-height: 50px;text-align: center;border-radius: 20px;" @tap="handleFindPwd()">{{$lang.CONFIRM}}</view>
			
			<view class="flex-1" style="margin-left: 10%;margin-top: 20px;" :style="{color:$util.THEME.TIP}"
				@click="$u.route({url:$util.PAGE_URL.SERVICE});">
				아이디/비밀번호 찾기 고객센터 문의
			</view>
		</view>
	</view>
</template>

<script>
	export default {

		data() {
			return {
				value1: "",
				value2: '',
				value3: ""
			};
		},
		methods: {
			codeChange(text) {
				this.tips = "인증 코드 받기";
			},

			//重置密码
			async handleFindPwd() {
				if(this.value1 ==''){
					uni.$u.toast('기존 비밀번호를 입력해주세요');
					return false;
				}
				if(this.value2 ==''){
					uni.$u.toast('새로운 비밀번호를 입력해주세요');
					return false;
				}
				if(this.value3 ==''){
					uni.$u.toast('새로운 비밀번호를 다시 입력해주세요');
					return false;
				}
				let list = await this.$http.post('api/app/loginPass', {
					code: this.value3,
					mobile: this.value1,
					newpass: this.value2,
				})
				if (list.data.code == 0) {
					uni.$u.toast('재설정 성공');
					setTimeout(() => {
						uni.navigateTo({
							url: this.$util.PAGE_URL.ACCOUNT_SIGNIN
						});
					}, 500)
				} else {
					uni.$u.toast(list.data.message);
				}
			},
			//验证码
			async getCode() {
				if(this.value1 ==''){
					uni.$u.toast('계좌를 입력해주세요');
					return false;
				}
				if (this.$refs.uCode.canGetCode) {
					// 模拟向后端请求验证码
					let list = await this.$http.post('api/app/sendSmsCode', {
						sence: 4,
						mobile: this.value1,
					})
					if (list.data.code != 0) {
						uni.$u.toast(list.data.message);
					} else {
						uni.showLoading({
							title: "인증 코드 받기"
						})
						setTimeout(() => {
							uni.hideLoading();
							// 这里此提示会被this.start()方法中的提示覆盖
							uni.$u.toast('인증코드가 전송되었습니다');
							// 通知验证码组件内部开始倒计时
							this.$refs.uCode.start();
						}, 2000);
					}
				} else {
					uni.$u.toast(this.$t('Sendcountdown'));
				}
			},
		},
	}
</script>

<style lang="scss">
	.erty {
		text-align: center;
		margin: 100rpx 20rpx 0;

		.input-field {
			display: flex;
			align-items: center;
			background: #f5f5f5;
			border-radius: 10rpx;
			margin: 40rpx 20rpx;
			padding: 20rpx;

			image {
				width: 30rpx;
				height: 30rpx;
			}

			input {
				width: 100%;
				margin-left: 30rpx;
				text-align: left;
				font-size: 32rpx;
			}
		}
	}

	.contact {
		text-align: center;
		font-weight: 800;
		margin-top: 100rpx;
		margin-bottom: 500rpx;


		h2 {
			margin: 60rpx;
			color: #f85050;
		}
	}

	.jump-registration {
		color: #f85050;
		text-align: right;
		margin: 0 40rpx;
	}

	.signIn {
		margin: 100rpx 30rpx 30rpx;
		background-image: linear-gradient(to right, #1a73e8, #014b8d);
		border-radius: 10rpx;
		color: #fff;
		font-weight: 800;
		font-size: 32rpx;
		text-align: center;
		padding: 20rpx;
	}
</style>