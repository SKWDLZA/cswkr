<template>
	<view >
		<Header ></Header>
		<view style="margin-top: 10px;margin-left: 20px;">
			<block v-for="(item,index) in $util.MARKET_TAB" :key="index">
				<view @click="handleChange(index)"
					style="display: inline-block;height: 20px;padding:8px 10px;text-align: center;font-size: 16px;font-weight: 700;width: 18%;"
					:style="$util.calcStyleTabActive(current === index)">
					
					{{item}}
					<view style="height: 4px;width: 110%;background-color: #489CE5;border-radius: 10px;margin-left: -5%;" v-if="current === index"></view>
				</view>
			</block>
		</view>
		<view>
			<TabOne v-if="current==0"></TabOne>
			<TabTwo v-if="current==1"></TabTwo>
			<TabThree v-if="current==2"></TabThree>
			<TabFour v-if="current==3"></TabFour>
		</view>
	</view>
</template>

<script>
	import Header from '@/components/Header.vue';
	import Tbas from '@/components/Tbas.vue';
	import TabOne from '@/components/market/TabOne.vue'
	import TabTwo from '@/components/market/TabTwo.vue'
	import TabThree from '@/components/market/TabThree.vue'
	import TabFour from '@/components/market/TabFour.vue'
	export default {
		components: {
			Header,
			Tbas,
			TabOne,
			TabTwo,
			TabThree,
			TabFour
		},
		data() {
			return {
				current: 0
			}
		},
		onShow() {},
		onLoad(op) {
			if (op.type) {
				this.current = Number(op.type);
			}
		},
		methods: {
			handleChange(val) {
				this.current = val;
			},
		},
	}
</script>