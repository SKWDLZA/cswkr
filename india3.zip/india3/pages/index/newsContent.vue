<template>
	<view>
		<web-view :src="url"></web-view>
	</view>
</template>

<script>
	export default {
		name: 'TabOne',
		components: {},
		props: {},
		data() {

			return {
				url:""
			}
		},

		methods: {
			
		},

		mounted() {
			
		},

		onLoad(ops) {
			console.log(decodeURIComponent(ops.url));
			this.url=decodeURIComponent(ops.url)

		},
		onUnload() {
			clearInterval(this.timerId);
		},
		onHide() {
			clearInterval(this.timerId);
		},
	}
</script>

<style lang="scss">
	view,
	text {
		box-sizing: border-box;
	}

	.list {
		padding: 10px;

		.item{
		    margin-bottom: 16px;
			.img {
			    width: 120px;
			    height: 80px;
			    margin-right: 10px;
			    border-radius: 5px;
				image{
				    width: 100%;
				    height: 100%;
				    border-radius: 5px;
				}
			}
			.t {
			    color: #333;
			}
			.t1{
			    color: #999;
			    margin-top: 10px;
			}
		}
	}

	.t-r {
		text-align: right;
	}

	.nav-box {
		height: 50px;
		border-bottom: 1px solid #ccc;
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
		-webkit-box-align: center;
		-webkit-align-items: center;
		align-items: center;
		-webkit-box-pack: center;
		-webkit-justify-content: center;
		justify-content: center;

		.nav-item {
			height: 50px;
			width: 50%;
			display: -webkit-box;
			display: -webkit-flex;
			display: flex;
			-webkit-box-orient: vertical;
			-webkit-box-direction: normal;
			-webkit-flex-direction: column;
			flex-direction: column;
			-webkit-box-align: center;
			-webkit-align-items: center;
			align-items: center;
			-webkit-box-pack: end;
			-webkit-justify-content: flex-end;
			justify-content: flex-end;
			font-size: 16px;
			color: #333;

			span {
				width: 100%;
				height: 3px;
				background: transparent;
				margin-top: 10px;
				display: block;
			}
		}

		.active {
			font-size: 16px;
			font-weight: 700;
			color: #014b8d;

			span {
				background: #014b8d;
			}
		}
	}
</style>