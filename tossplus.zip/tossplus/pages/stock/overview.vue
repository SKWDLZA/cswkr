<!-- 股票详情 -->
<template>
	<view :style="$util.setPageBG('bg_common')">
		<CustomHeader :title="$lang.STOCK_OVERVIEW" @action="handleBack()"></CustomHeader>

		<view class="top1 common_block">
			<view class="flex flex-b pd10">
				<view class="flex align-center">
					<template v-if="!productDetails.logo || productDetails.logo==''">
						<view :style="$util.calcImageSize(80)" style="background-color:#2d2c62;text-align: center;line-height: 80rpx;color: #FFFFFF;border-radius: 100px;font-size: 18px;">{{productDetails && productDetails.name? productDetails.name[0]:''}}</view>
					</template>
					<template v-else>
						<image v-if="productDetails.logo" :src="getlogo()" mode="aspectFit" :style="$util.calcImageSize(80)"
							style="border-radius: 100px;"></image>
					</template>						
					<view class="margin-left-15">
						<view class="text-center bold" style="font-size: 16px;">{{productDetails.name}}</view>
						<view class="hui1"> {{productDetails.ct_name}} {{productDetails.number_code}}</view>
					</view>
				</view>

				<view class="icon margin-right-10" style="width:20px;height: 20px;"
					:class="productDetails.is_collected==1?'yzx':'wzx'"
					@click="handleClickDelProduct(productDetails.gid)"></view>
			</view>

			<template v-if="productDetails">
				<view style="display: flex;align-items: center;justify-content: space-around;padding: 10px 20px;"
					:style="$util.calcStyleRiseFall(productDetails.rate>0)">
					<view style="font-size: 20px; font-weight: 700;">
						{{$util.formatNumber(productDetails.current_price)}}<text style="padding:0 4px">원</text>
					</view>
					<view style="font-size: 20px; font-weight: 700;">{{$util.formatNumber(productDetails.rate_num)}}
					</view>
					<view style="font-size: 20px; font-weight: 700;">{{$util.formatNumber(productDetails.rate)}}%</view>
				</view>

				<view class="list1 flex flex-b" style="background-color: #03527812;">
					<view class="flex flex-b item">
						<view class="t2">시가</view>
						<view class="t3">{{$util.formatNumber(productDetails.info.open)}}<text style="padding:0 4px">원</text>
						</view>
					</view>
					<view class="flex flex-b item">
						<view class="t2">고가</view>
						<view class="t3">{{$util.formatNumber(productDetails.info.high)}}<text style="padding:0 4px">원</text>
						</view>
					</view>
					<view class="flex flex-b item">
						<view class="t2">거래량</view>
						<view class="t3">
							{{$util.formatNumber(productDetails.info.volume/10000)}}
						</view>
					</view>
					<view class="flex flex-b item">
						<view class="t2">전일종가</view>
						<view class="t3">
							{{$util.formatNumber(productDetails.info.prev_close)}}<text style="padding:0 4px">원</text>
						</view>
					</view>
					<view class="flex flex-b item">
						<view class="t2">저가</view>
						<view class="t3">{{$util.formatNumber(productDetails.info.low)}}<text style="padding:0 4px">원</text>
						</view>
					</view>
					<view class="flex flex-b item">
						<view class="t2">거래대금</view>
						<view class="t3">
							{{$util.formatNumber(parseInt(productDetails.info.volume_valued/10000))}}<text style="padding:0 4px">원</text>
						</view>
					</view>
				</view>
			</template>
		</view>

		<view style="text-align: center;padding: 10px;">
			<Tbas :btns="$util.STOCK_OVERVIEW_TABS" @action="handleChangeTab"></Tbas>
		</view>
		<view v-show="curren==0" class="common_block" style="padding-top: 16px;">
			<view class="stock-chart">
				<view class="chart-time" style="position: relative;">
					<view class="txt" :class="ac_time==0?'active':''" @click="ac_time_click(0)">분</view>
					<view class="txt" :class="ac_time==1?'active':''" @click="ac_time_click(1)">일</view>
					<view class="txt" :class="ac_time==2?'active':''" @click="ac_time_click(2)">주</view>
					<view class="txt" :class="ac_time==3?'active':''" @click="ac_time_click(3)">월</view>
				</view>
				<view class="chart" id="chart-type-k-line" style="width: 100%;height: 500rpx;">
				</view>
			</view>
		</view>
		<template v-if="curren==0">
			<view class="common_btn btn_primary" style="margin: auto;margin-top:30px; width: 90%;" @click="purchase">주문
			</view>
		</template>
		<InfoTwo v-if="curren==1" :code='code' :productDetails='productDetails'></InfoTwo>

		<InfoThree v-if="curren==2" :code='code' :productDetails='productDetails'></InfoThree>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	import Tbas from '@/components/Tbas.vue';
	import InfoTwo from '@/components/info/InfoTwo.vue'
	import InfoThree from '@/components/info/InfoThree.vue'
	import {
		init,
		registerLocale,
		dispose
	} from 'klinecharts'
	// import generatedKLineDataList from '@/utils/generatedKLineDataList.js'

	export default {
		components: {
			CustomHeader,
			Tbas,
			InfoTwo,
			InfoThree
		},
		data() {
			return {
				zuoshou: 0,
				updata: true,
				productDetails: "",
				today: '',
				yesterday: '',
				buy: "",
				sell: "",
				divide: '',
				sky: '',
				circumference: '',
				moon: '',
				onePoint: '',
				halfhour: '',
				timerId: null,
				option: {},
				time_index: 0,
				list: [],
				gid: 0,
				kLineChart: null,
				ac_time: 1,
				curren: 0
			};

		},
		onLoad(option) {
			this.code = option.code
		},
		onShow() {
			this.startTimer()
		},
		onUnload() {
			clearInterval(this.timerId);
		},
		onHide() {
			clearInterval(this.timerId);
		},
		mounted() {
			this.kLineChart = init('chart-type-k-line')
			this.init()
		},
		methods: {
			handleBack() {
				uni.navigateBack({
					delta: 1
				});
			},
			getlogo() {
				return this.$BaseUrl + this.productDetails.logo
			},

			handleChangeTab(val) {
				// clearInterval(this.timer);
				// this.curren = val;
				this.curren_click(val);
			},

			init() {
				this.kLineChart.setStyles({
					"candle": {
						"type": "area",
						"tooltip": {
							"showRule": "none",
						},
						area: {
							lineSize: 2,
							lineColor: this.$util.THEME.PRIMARY,
							value: 'close',
							backgroundColor: [{
								offset: 0,
								color: '#ffbfb9'
							}, {
								offset: 1,
								color: this.$util.THEME.PRIMARY,
							}]
						},
						bar: {
							upColor: '#3779CD',
							downColor: '#F92855',
							noChangeColor: '#888888',
							upBorderColor: '#3779CD',
							downBorderColor: '#F92855',
							noChangeBorderColor: '#888888',
							upWickColor: '#3779CD',
							downWickColor: '#F92855',
							noChangeWickColor: '#888888'
						},
					},
				});
				this.kLineChart.createIndicator('MA', false);
				this.product()
				this.startTimer()
			},
			curren_click(index) {
				this.curren = index;
				this.$forceUpdate()
			},
			ac_time_click(index) {
				this.ac_time = index;
				this.qiehuan()
			},
			async qiehuan() {

				let list = await this.$http.post(this.$http.API_URL.PRODUCT_LISHI, {
					stock_id: this.productDetails.stock_id,
					ac_time: this.ac_time,
					project_type_id: this.productDetails.project_type_id,
					code: this.productDetails.code
				})
				if (this.ac_time >= 1) {

					this.kLineChart.setStyles({
						"candle": {
							"type": "candle_solid",
						},

					});
				} else {

					this.kLineChart.setStyles({
						"candle": {
							"type": "area",
						},

					});
				}
				this.kLineChart.setPriceVolumePrecision(0, 0)
				this.kLineChart.applyNewData(list.data.data)
			},
			time_click(i) {
				this.time_index = i.index
				this.product()
			},
			// 买入
			purchase() {
				uni.navigateTo({
					url: `${this.$util.PAGE_URL.STOCK_BUY}?code=${this.code}`
					// url: '/pages/marketQuotations/purchase?code=' + this.code

				});
			},
			// 产品详情
			async product() {
				let list = await this.$http.get('api/product/info', {
					code: this.code,
					time_index: this.time_index
				})
				this.productDetails = list.data.data[0]
				this.qiehuan()

				// let new_price = this.productDetails.data.TDD_CLSPRC.replace(',', "");
				// let rate_num = this.productDetails.rate_num

				// this.zuoshou = (new_price * 1 - rate_num * 1).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");

			},
			//定时器
			startTimer() {
				const storedTimerId = uni.getStorageSync('timerId');
				if (storedTimerId) {
					clearInterval(storedTimerId);
				}
				this.timerId = setInterval(() => {
					this.product()
				}, 2000);
				uni.setStorageSync('timerId', this.timerId);
				// 在这里立即执行一次请求
			},
			//删除
			async handleClickDelProduct(e) {
				let list = await this.$http.post('api/user/collect_edit', {
					gid: e,
				})
				if (list.data.code == 0) {
					uni.$u.toast(list.data.message);
					this.updata = !this.updata
					this.updata = true
					//按键样式判断
					this.productDetails.is_collected = this.productDetails.is_collected == 1 ? 0 : 1
				} else {
					this.show = false
					uni.$u.toast(list.data.message);
				}
			},

		},
	}
</script>

<style lang="scss">
	.top1 {
		padding: 16px 5px 5px;

		.pd10 {
			padding: 0 5px;
		}

		.t {
			font-size: 19px;
			font-weight: 700;
			color: #333;
		}

		.bt {
			background: #489ce5;
			border-radius: 10px;
			padding: 5px 10px;

			.icon {
				margin-right: 10px;
			}

			view {
				font-size: 17px;
				color: #fefefe;
			}
		}

		.mt30 {
			margin-top: 16px;
		}

		.t1 {
			font-size: 32px;
			font-family: Roboto;
			font-weight: 700;
			color: #333;
			margin-right: 10px;
		}

		.r-bg {
			background: #f7e8e8;
			border-radius: 10px;
			padding: 5px 10px;

			.icon {
				margin-right: 5px;
			}

			span {
				font-family: Roboto;
				font-weight: 700;
				color: #ff3636;
			}
		}

		.b-bg {
			background: #e7f1f9;
			border-radius: 10px;
			padding: 5px 10px;

			span {
				font-family: Roboto;
				font-weight: 700;
				color: #489ce5;
			}
		}

		.list1 {
			background-color: #0332783b;
			border-radius: 8px;
			padding: 10px 5px;
			-webkit-flex-wrap: wrap;
			flex-wrap: wrap;
			margin-top: 10px;

			.item {
				width: 32%;
				line-height: 21px;
			}

			.t2 {
				font-size: 12px;
				color: #999;
			}

			.t3 {
				font-size: 12px;
				color: #333;
				font-family: Roboto;
			}
		}
	}

	.stock-chart {
		background: #fff;

		.chart-time {
			background: #489ce51f;
			// border: 1px solid #999;
			border-radius: 5px;
			display: -webkit-box;
			display: -webkit-flex;
			display: flex;
			-webkit-box-pack: justify;
			-webkit-justify-content: space-between;
			justify-content: space-between;
			-webkit-box-align: center;
			-webkit-align-items: center;
			align-items: center;
			margin: 0 10px 10px;

			.txt {
				-webkit-box-flex: 1;
				-webkit-flex: 1;
				flex: 1;
				text-align: center;
				color: #999;
				border-radius: 5px;
				padding: 10px 0;
			}

			.active.txt {
				color: #033278;
				background-color: #fff;
				// box-shadow: rgba(0, 0, 0, 0.24) 0px 3px 8px;
			}
		}
	}
</style>