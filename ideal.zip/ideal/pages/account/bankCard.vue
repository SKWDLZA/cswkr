<!-- 绑定银行卡 -->
<template>
	<view >
		<view class="header_wrapper">
			<CustomHeader title="개인 계좌 연동" @action="handleBack()"></CustomHeader>
		</view>
		<view style="display: flex;flex-direction: column;justify-content: center;align-items: center;padding-top:3vh;">
			<view style="display: inline-block;width:80%;text-align: left;">성명:</view>
			<view class="common_input_wrapper"
				style="width:80%;height: 30px;line-height: 30px;margin-bottom: 20px;padding-left: 20px;margin-top: 10px;"
				:style="{color:$util.THEME.TEXT}">				
				<template v-if="isRenewal">
					<input v-model="value" type="text" :placeholder="$lang.REAL_NAME"></input>
				</template>
				<template v-else>
					<view style="display: inline-block;font-size: 18px;font-weight: 700;"> {{info.realname}}
					</view>
				</template>
			</view>

			<view style="display: inline-block;width:80%;text-align: left;">은행명:</view>
			<view class="common_input_wrapper"
				style="width:80%;height: 30px;line-height: 30px;margin-bottom: 20px;padding-left: 20px;margin-top: 10px;"
				:style="{color:$util.THEME.TEXT}">				
				<template v-if="isRenewal">
					<input v-model="value1" type="text" :placeholder="$lang.BANK_NAME"></input>
				</template>
				<template v-else>
					<view style="display: inline-block;font-size: 18px;font-weight: 700;"> {{info.bank_name}}
					</view>
				</template>
			</view>

			<view style="display: inline-block;width:80%;text-align: left;">계좌번호:</view>
			<view class="common_input_wrapper"
				style="width:80%;height: 30px;line-height: 30px;margin-bottom: 20px;padding-left: 20px;margin-top: 10px;"
				:style="{color:$util.THEME.TEXT}">
				<template v-if="isRenewal">
					<input v-model="value2" type="text" :placeholder="$lang.BANK_CARD"></input>
				</template>
				<template v-else>
					<view style="display: inline-block;font-size: 18px;font-weight: 700;"> {{info.card_sn}}
					</view>
				</template>
			</view>

			<template v-if="isRenewal">
				<view class="common_btn btn_primary" style="width:60%;margin-top: 20px;" @click="replaceBank()">확인</view>
			</template>
			<template v-else>
				<view class="common_btn btn_primary" style="width:60%;margin-top: 20px;" @click="renewal()">확인</view>
			</template>
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components: {
			CustomHeader,
		},
		data() {
			return {
				info: {},
				isRenewal:false,
				value: '',
				value1: '',
				value2: '',
			};
		},
		onLoad() {
			this.gaint_info()
		},
		methods: {
			handleBack() {
				uni.navigateBack({
					delta: 1
				});
			},
			renewal() {
				this.isRenewal=true;
			},
			// 换绑银行卡
			async replaceBank() {
				let list = await this.$http.post(this.$http.API_URL.USER_BIND_CARD, {
					//value2和value3反了
					//value2应该是bank_name  
					//value3应该是bank_sub_name
					realname: this.value,
					bank_name: this.value1,
					// bank_sub_name: this.value3,
					card_sn: this.value2,
				})
				if (list.data.code == 0) {
					uni.$u.toast('은행 카드 정보가 성공적으로 제출되었습니다.');
					setTimeout(() => {
						uni.switchTab({
							url: this.$util.PAGE_URL.ACCOUNT_CENTER
						});
					}, 1000)
				} else {
					uni.$u.toast(list.data.message);
				}

			},
			//用户信息
			async gaint_info() {
				const result = await this.$http.get('api/user/info', {})
				this.info = result.data.data.bank_card_info
			},
		},
	}
</script>