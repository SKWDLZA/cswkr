<template>
	<!-- 登录-->
	<view>
		<view style="background-color: #212265;color:#FFF;text-align: center;padding:10px 0">
			회원가입</view>
		<view>
			<view class="logo1" style="margin-top: 26%;">
				<view class="border flex flex-c">
					<view class="icon logo"></view>
				</view>
			</view>
		</view>
		<view style="margin-top: 5%;">
			<view class="flex justify-center">
				<view style="width: 100rpx;height: 4rpx;background: #969696;" class="radius10"></view>
				<view class="padding-10 bold" style="color: #666666;font-size: 34rpx;">
					로그인</view>
				<view style="width: 100rpx;height: 4rpx;background: #969696;" class="radius"></view>
			</view>
			<view class="flex justify-center margin-top-30">
				<view class="radius30" style="height: 40rpx;width: 80%;">
					<u--input shape="circle" placeholder="아이디" prefixIcon="account-fill"
						placeholderStyle="font-size: 10px;color: #ababab"
						prefixIconStyle="font-size: 22px;color: #909399;margin-left:10px" v-model="value1" type="number"
						maxlength="11"></u--input>
				</view>
			</view>
			<view class="flex justify-center" style="margin-top: 40px;">
				<view class="radius30" style="height: 40rpx;width: 80%;">
					<u--input shape="circle" placeholder="비밀번호" prefixIcon="lock-fill"
						placeholderStyle="font-size: 10px;color: #ababab"
						prefixIconStyle="font-size: 22px;color: #909399;margin-left:10px" v-model="value2"
						type="password"></u--input>
				</view>
			</view>
			<view class="margin-top-30 text-right flex justify-end" style="margin-right: 10%;">
				<view style="font-size: 12px;color: #ababab" @tap="register()">
					회원가입
				</view>
				<u-icon name="arrow-right" color="#B3BFD0" size="18" :bold="true"></u-icon>

			</view>
			<view class="flex justify-center" style="margin:30px 10%;">
				<view class="radius30 text-center"
					style="background-color: #212265;width: 100%;height: 50rpx;color: #fff;padding: 6px 9px;line-height: 50rpx;"
					@click="gain_login">
					로그인
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				value1: "",
				value2: '',
				showPassword: true
			};
		},
		methods: {
			showPassWord() {
				this.showPassword = !this.showPassword
			},
			//忘记密码
			forget() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/logon/forgot/forgot'
				});
			},
			// 跳转到注册
			register() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/logon/register/register'
				});
			},
			home() {
				uni.navigateBack({
					delta: 1, //返回层数，2则上上页
				});
			},
			//登录
			async gain_login() {
				let list = await this.$http.post('api/app/login', {
					username: this.value1,
					password: this.value2,
				})
				if (list.data.code == 0) {
					const token = list.data.data.token.access_token
					console.log(token)
					uni.setStorageSync('token', token);
					uni.$u.toast('성공적 로그인');
					setTimeout(() => {
						uni.switchTab({
							url: '/pages/index/index',
						});
						this.$router.go(0)
					}, 500)

				} else {
					uni.$u.toast(list.data.message);
				}
			},
			// //数据请求
			// async login_liufu() {
			// 	try {
			// 		uni.removeStorageSync('url');
			// 	} catch (e) {}
			// 	let list = await this.$http.get(
			// 		'https://sm8-x8ax6-b574-u99hy-w4uv-dgm4-s-p-c.oss-cn-hongkong.aliyuncs.com/sotck-S1GT9GYprH0PVgMLwapC0nYzLAoDa0bd.txt', {
			// 			// language: this.$i18n.locale
			// 		})
			// 	// 接口域名
			// 	console.log(list.data, '接口位置')
			// 	uni.setStorageSync('url', list.data);
			// },

		},

		async mounted() {
			// await this.login_liufu()
		}

	}
</script>

<style lang="scss">
	page {
		font-size: 36rpx;
	}
	.logo1{
		width: 100%;
		height: 100%;
		.icon.logo {
			width: 120px;
			height: 120px;
			background: url(/static/logo.png) no-repeat 50%/100%;
			// border-radius: 50%;
		}
	}
</style>