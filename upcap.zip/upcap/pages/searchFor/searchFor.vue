<template>
	<view >
		<CustomHeader :title="$lang.SEARCH" @action="$u.route({type:'navigateBack'});"></CustomHeader>

		<view style="padding: 10px 10px 10px 20px;background-color:transparent;">
			<view class="margin-top-20">
				<u-search shape="square" placeholder="종목코드검색" v-model="keyword" :showAction="false" height="40px"
					searchIconColor="#283480" searchIconSize="30" bgColor="#d6e9f9" @clear="keyword=''" actionText="검색"
					@search="searchButton" @custom="searchButton"></u-search>
			</view>

			<view class="common_block">
				<view class="flex padding-top-10 padding-bottom-10">
					<view style="border-radius: 0 16rpx 16rpx 0;width: 5px;height: 30px;background-color: #283480;">
					</view>
					<view class="margin-left-10">검색기록</view>
				</view>

				<view class="box" style="border-radius: 10px; " v-if="searchList">
					<view class="top flex flex-b padding-10">
						<view class="flex-2  font-size-16">주식/코드</view>
						<view class="flex-1 t-r"></view>
						<view class="flex-1 t-r  font-size-16">등락률</view>
						<view class="t-r font-size-16" style="margin-left: 10px;">최신</view>
					</view>

					<u-gap height="2" bgColor="#bbb" marginTop="10px" marginBottom="10px"></u-gap>

					<view class=" box-item flex flex-b padding-10" v-for="(item,index) in searchList"
						@click="detailed(item.code)">
						<view class="list-name flex-2 font-size-16">
							<view class="list-name-txt ">
								{{item.name}}

								<span
									style="background-color: #283480;color: #fff;padding: 3px;margin-left: 5px;">{{item.number_code}}</span>
							</view>
						</view>
						<view class="flex-1 t-c num-font" :class="item.rate>0?'red':'green'">
							{{item.current_price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}
						</view>
						<view class="per flex-1 t-r color-white" :class="item.rate>0?'bg-red':'bg-green'">
							{{item.rate>0?'+':''}}{{item.rate}}%
						</view>
						<view class="flex justify-end" style="margin-left: 10px;" :class="item.rate>0?'red':'green'">
							<view class="icon yzx " @click="handleClickDelProduct(item.gid)"></view>
						</view>
					</view>

				</view>
				<view style="width: 60%;margin-left: 20%;margin-top: 30%; margin-bottom: 20%;" v-if="!searchList">
					<u-image src="/static/market/no.png" width="100%" mode="widthFix"></u-image>

					<view class="font-size-20 text-center padding-bottom-30">기록 없음</view>
				</view>
			</view>


		</view>

	</view>
</template>
<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components: {
			CustomHeader
		},
		data() {
			return {
				searchList: '',
				pager: {
					page: 1,
					limit: 20
				},
				keyword: "",
				keywords: [],
				gp_select: [{
					name: "국내",
				}, {
					name: "해외",
				}],
				gp_index: 0,
			};
		},
		onReachBottom() {
			this.status = 'loading';
			this.pager.page++;
			this.searchButton()
		},
		onLoad() {
			let keywords = uni.getStorageSync("keywords")
			if (keywords) {
				this.keywords = keywords
			}
			console.log(this.keywords)
		},
		methods: {
			gp_select_click(e) {
				this.storehouse = ""
				this.gp_index = e.index
			},
			dianji(keyword) {
				this.keyword = keyword;
				this.searchButton()
			},
			home() {
				uni.switchTab({
					url: '/pages/index/index'
				});
			},
			detailed(code) {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/productDetails/productDetails' + `?code=${code}`
				});
				// console.log(gid, "携带");
			},
			//搜索
			async searchButton() {
				if (this.keyword == '') {
					uni.$u.toast('검색어는 비워둘 수 없습니다. 다시 검색해 주세요');

				} else {
					uni.showLoading({
						title: "검색...",
						mask: true, // 显示透明蒙层，防止触摸穿透
					});
					let list = await this.$http.post('api/product/list', {
						key: this.keyword,
						page: 1,
						limit: 9999999,
						gp_index: this.gp_index
					})
					this.searchList = list.data.data
					console.log(8888, list.data.data)
					uni.hideLoading();
					if (list.data.data.length > 0) {
						if (this.keywords.indexOf(this.keyword) < 0) {
							this.keywords.push(this.keyword);
							uni.setStorageSync("keywords", this.keywords)
						}
					}
				}
			},
		}
	}
</script>

<style lang="scss">
	view,
	uni-text {
		box-sizing: border-box;
	}
</style>