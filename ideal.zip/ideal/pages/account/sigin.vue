<!-- 登入  注册 -->
<template>
	<view class="signin">
		<image mode="aspectFit" src="/static/app_logo.png" :style="$util.calcImageSize(180)"></image>
		
		<view style=";width: 100%;height: 100%;" class="justify-center padding-top-15">
			<view style="font-size: 64rpx;font-weight: 900;text-align: center;margin-bottom: 20px;">IDEAL</view>
			
			<view class="common_input_wrapper radius30" style="background-color: #f7fbfe;height: 40px;border: 1px solid #cfd4d7;">
				<image mode="aspectFit" src="/static/user.png" :style="$util.calcImageSize(20)">
				</image>
				<input v-model="user" type="number" :placeholder="$lang.USER_NAME" maxlength="11"></input>
			</view>
			<view class="common_input_wrapper radius30" style="background-color: #f7fbfe;height: 40px;border: 1px solid #cfd4d7;">
				<image mode="aspectFit" src="/static/password.png" :style="$util.calcImageSize(20)">
				</image>
				<input v-model="password" type="password" :placeholder="$lang.PASSWORD"></input>
			</view>

			<view v-if="!isSignIn" class="common_input_wrapper radius30"
				style="background-color: #f7fbfe;height: 40px;border: 1px solid #cfd4d7;">
				<image mode="aspectFit" src="/static/password.png" :style="$util.calcImageSize(20)">
				</image>
				<input v-model="password2" type="password" :placeholder="$lang.PASSWORD_CONFIRM"></input>
			</view>

			<view v-if="!isSignIn" class="common_input_wrapper radius30"
				style="background-color: #f7fbfe;height: 40px;border: 1px solid #cfd4d7;">
				<image mode="aspectFit" src="/static/code.png" :style="$util.calcImageSize(20)">
				</image>
				<input v-model="code" type="text" :placeholder="$lang.INVITATION_CODE"></input>
			</view>

			<view style="padding:0 10%;display: flex; align-items: center; justify-content: space-between;">
				<view style="display: inline-block;font-size: 14px;margin-right: 4px;" :style="{color:$util.THEME.TIP}" @click="handleChange()">
					{{isSignIn?$lang.SIGN_UP:$lang.SIGN_IN}}
				</view>
				<!-- <template v-if="isSignIn">
					<view style="display: inline-block;font-size: 14px;margin-right: 4px;" :style="{color:$util.THEME.TIP}" @click="$u.route({url:$util.PAGE_URL.SERVICE});">
						비밀번호 찾기
					</view>
				</template> -->
			</view>

			<view
				style="width:90%;margin-top: 20px;background-color: #333077;color: #fff;margin-left: 5%;height: 50px;line-height: 50px;text-align: center;border-radius: 20px;"
				@click="handleConfirm()">
				{{isSignIn?$lang.SIGN_IN:$lang.SIGN_UP}}
			</view>

			<view class="flex-1" style="margin-left: 10%;margin-top: 20px;" :style="{color:$util.THEME.TIP}"
				@click="$u.route({url:$util.PAGE_URL.SERVICE});">
				아이디/비밀번호 찾기 고객센터 문의
			</view>
		</view>

	</view>
</template>

<script>
	export default {
		data() {
			return {
				user: "",
				password: '',
				password2: '',
				code: '',
				isSignIn: true,
				checked: false,

			};
		},
		onShow() {
			let userinput = uni.getStorageSync('userinput');
			let passinput = uni.getStorageSync('passinput');
			console.log(userinput);

			if (userinput) {
				this.user = userinput
			}
			if (passinput) {
				this.password = passinput
			}
		},
		methods: {
			// // 跳转到找回密码
			// handleFindPwd(){
			// 	uni.navigateTo({
			// 		url :this.$util.PAGE_URL.ACCOUNT_FIND_PASSWORD,
			// 	})
			// },
			handleChange() {
				this.isSignIn = !this.isSignIn;
				// this.user = "";
				// this.password = "";
				// this.password2 = "";
				// this.code = "";
			},
			handleConfirm() {
				if (this.checkForm()) {
					if (this.isSignIn) {
						this.signIn();
					} else {
						this.register();
					}
				}
			},
			home() {
				uni.navigateBack({
					delta: 1, //返回层数，2则上上页
				});
			},
			checkForm() {
				if (this.user == '') {
					uni.$u.toast(this.$lang.USER_NAME);
					return false;
				}
				if (this.password == '') {
					uni.$u.toast(this.$lang.PASSWORD);
					return false;
				}
				if (!this.isSignIn && this.password2 == '') {
					uni.$u.toast(this.$lang.PASSWORD_CONFIRM);
					return false;
				}
				if (!this.isSignIn && this.password2 != this.password) {
					uni.$u.toast(this.$lang.TIP_PWD_NOEQUAL);
					return false;
				}
				if (!this.isSignIn && !this.code) {
					uni.$u.toast(this.$lang.INVITATION_CODE);
					return false;
				}
				return true;
			},

			async signIn() {
				uni.showLoading({
					title: this.$lang.TIP_SIGNIN_ING,
				})
				const result = await this.$http.post(this.$http.API_URL.SIGN_IN, {
					username: this.user,
					password: this.password,
				})
				if (result.data.code == 0) {
					uni.hideLoading();
					const token = result.data.data.token.access_token
					uni.setStorageSync('token', token);
					uni.$u.toast(this.$lang.TIP_SUCCESS_SIGNIN);
					setTimeout(() => {
						uni.switchTab({
							url: this.$util.PAGE_URL.HOME,
						});
						this.$router.go(0)
					}, 500)
				} else {
					uni.hideLoading();
					uni.$u.toast(result.data.message);
				}
			},
			async register() {
				uni.showLoading({
					title: this.$lang.TIP_SIGNUP_ING,
				})
				const result = await this.$http.post(this.$http.API_URL.SIGN_UP, {
					mobile: this.user,
					password: this.password,
					confirmpass: this.password,
					invite: this.code,
					code: 123456,
				})
				if (result.data.code == 0) {
					uni.hideLoading();
					uni.$u.toast(this.$lang.TIP_SUCCESS_REGISTER);
					this.signIn();
				} else {
					uni.hideLoading();
					uni.$u.toast(result.data.message);
				}
			},
		}
	}
</script>