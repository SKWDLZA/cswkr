<template>
	<view class="page">
		<view class="home" style="padding: 30px 10px 10px 20px;">
			<view class="flex">
				<view class="flex-1" style="color: #fff;font-size: 38rpx;">홈</view>
				<view class="flex-4 flex" @click="$u.route({url:'/pages/searchFor/searchFor'});">
					<u--input shape="circle" suffixIconStyle="font-size: 24px;color: #fff;margin-right:10px"
						suffixIcon="/static/sousuo.png" type="number" maxlength="11" border="none" :disabled="true"
						customStyle="background: rgba(255,255,255,0.25);height:60rpx;width:70%;margin-left: auto;"></u--input>
				</view>
				<view @click="$u.route({url:'/pages/email/email'});">
					<!-- <u-icon name="/static/laba.png" style="margin-left: 10px;"></u-icon> -->
				</view>
			</view>

			<view style="border-radius: 23rpx;width: 100%;height: 160px; background-color: #ffffff;"
				class="margin-top-25 padding-20 ">
				<view class="flex">
					<view class="align-center justify-center flex-column text-center flex flex-1"
						@click="link(3,'/pages/position/position')">
						<view
							style="width: 30px;height: 30px;background-color: #fff7f7;border-radius: 15rpx;box-shadow:  0 6rpx 3rpx rgba(255, 127, 127, 0.2); "
							class="align-center justify-center flex-column text-center flex">
							<!-- <u-icon name="/static/home/top1.png"></u-icon> -->
							<image src="/static/home/top1.png" style="width: 30px;height: 30px;"></image>
						</view>
						<!-- 倒卖 -->
						<view class="margin-top-5 font-size-11">
							거래
						</view>
					</view>


					<view class="align-center justify-center flex-column text-center flex flex-1"
						@click="link(3,'/pages/index/components/newShares/newShares?index=3')">
						<!-- <u-icon name="/static/home/top2.png" style="width: 30px;height: 30px;"></u-icon> -->
						<image src="/static/home/top2.png" style="width: 30px;height: 30px;"></image>
						<view class="margin-top-5 font-size-11">
							블록딜
						</view>
					</view>

					<view class="align-center justify-center flex-column text-center flex flex-1"
						@click="link(2,'/pages/my/components/aiBank/aiBank')">
						<view
							style="width: 30px;height: 30px;background-color: #fbfdff;border-radius: 15rpx;box-shadow:  0 6rpx 3rpx rgba(68, 164, 255, 0.2); "
							class="align-center justify-center flex-column text-center flex">
							<!-- <u-icon name="/static/home/top3.png"></u-icon> -->
							<image src="/static/home/top3.png" style="width: 30px;height: 30px;"></image>
						</view>
						<view class="margin-top-5 font-size-11">
							AI 트레이딩
						</view>
					</view>
					<view class="align-center justify-center flex-column text-center flex flex-1"
						@click="link(3,'/pages/index/components/newShares/newSharesIPO?index=0')">
						<view
							style="width: 30px;height: 30px;background-color: #fff7f7;border-radius: 15rpx;box-shadow:  0 6rpx 3rpx rgba(255, 127, 127, 0.25); "
							class="align-center justify-center flex-column text-center flex">
							<!-- <u-icon name="/static/home/top4.png" ></u-icon> -->
							<image src="/static/home/top4.png" style="width: 30px;height: 30px;"></image>
						</view>
						<view class="margin-top-5 font-size-11">
							IPO
						</view>
					</view>
				</view>

				<view class="margin-top-25  flex">
					<view class="align-center justify-center flex-column text-center flex flex-1"
						@click="link(2,'/pages/my/components/certificateBank/silver')">
						<view
							style="width: 30px;height: 30px;background-color: #fff7f7;border-radius: 15rpx;box-shadow:  0 6rpx 3rpx rgba(255, 127, 127, 0.2); "
							class="align-center justify-center flex-column text-center flex">
							<!-- <u-icon name="/static/home/top5.png"></u-icon> -->
							<image src="/static/home/top5.png" style="width: 30px;height: 30px;"></image>
						</view>
						<view class="margin-top-5 font-size-11">
							입금
						</view>
					</view>


					<view class="align-center justify-center flex-column text-center flex flex-1"
						@click="link(2,'/pages/my/components/certificateBank/prove')">
						<view
							style="width: 30px;height: 30px;background-color: #fbfdff;border-radius: 15rpx;box-shadow:  0 6rpx 3rpx rgba(68, 164, 255, 0.2); "
							class="align-center justify-center flex-column text-center flex">
							<!-- <u-icon name="/static/home/top6.png"></u-icon> -->
							<image src="/static/home/top6.png" style="width: 30px;height: 30px;"></image>
						</view>
						<view class="margin-top-5 font-size-11">
							출금
						</view>
					</view>

					<view class="align-center justify-center flex-column text-center flex flex-1"
						@click="link(2,'/pages/marketQuotations/authentication')">
						<view
							style="width: 30px;height: 30px;background-color: #fbfdff;border-radius: 15rpx;box-shadow:  0 6rpx 3rpx rgba(68, 164, 255, 0.2); "
							class="align-center justify-center flex-column text-center flex">
							<!-- <u-icon name="/static/home/top7.png"></u-icon> -->
							<image src="/static/home/top7.png" style="width: 30px;height: 30px;"></image>
						</view>
						<view class="margin-top-5 font-size-11">
							실명인증
						</view>
					</view>
					<view class="align-center justify-center flex-column text-center flex flex-1"
						@click="link(1,'/pages/marketQuotations/marketQuotations')">
						<view
							style="width: 30px;height: 30px;background-color: #fff7f7;border-radius: 15rpx;box-shadow:  0 6rpx 3rpx rgba(255, 127, 127, 0.25); "
							class="align-center justify-center flex-column text-center flex">
							<!-- <u-icon name="/static/home/top8.png" ></u-icon> -->
							<image src="/static/home/top8.png" style="width: 30px;height: 30px;"></image>

						</view>
						<view class="margin-top-5 font-size-11">
							고객센터
						</view>
					</view>
				</view>
			</view>





			<view
				style="border-radius: 23rpx;background-color: #ffffff;box-shadow: rgba(0, 0, 0, 0.15) 1.95px 1.95px 2.6px;"
				class="margin-top-30 padding-top-10">
				<view class="text-center font-size-13 color-white"
					style="border-radius: 0 16rpx 16rpx 0; background-color: #212265;padding:14rpx 10px;width: 90px;">
					관심종목
				</view>

				<view class="padding-10 flex" v-for="(item,index) in business">
					<template v-if="!item.goods.logo || item.goods.logo==''">
						<view style="width: 30px;height: 30px;background-color:#2d2c62;text-align: center;line-height: 30px;color: #FFFFFF;margin-bottom: 4px;border-radius: 100%;">{{item.ko_name.slice(0,1)}}</view>
					</template>
					<template v-else>
						<image mode="aspectFit" :src="$BaseUrl+item.goods.logo" style="width: 30px;height: 30px;border-radius: 100%;"></image>
					</template>	
					
					<!-- <u--image :src="$BaseUrl+item.goods.logo" shape="circle" width="30px" height="30px"></u--image> -->
					<view style="background-color: #80A3E7;border-radius: 3px;padding: 2px 5px;" class="margin-left-20">
						{{item.goods.name}}
					</view>
					<view style="margin-left:auto;">
						<view class="flex justify-center" style="gap: 20px;padding: 2px 5px;">
							<view> {{item.goods.current_price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</view>
							<view style="padding: 2px 5px; " :class="item.goods.rate>0?'red':'green'">
								{{item.goods.rate}}%
							</view>
						</view>

					</view>
				</view>

			</view>

			<view
				style="border-radius: 23rpx;background-color: #ffffff;box-shadow: rgba(0, 0, 0, 0.15) 1.95px 1.95px 2.6px;"
				class="margin-top-30 padding-top-10">
				<view class="text-center font-size-13 color-white"
					style="border-radius: 0 16rpx 16rpx 0; background-color: #cc3355;padding:14rpx 10px;width: 90px;">
					종목
				</view>

				<view class="padding-10 flex" v-for="(item,index) in list"
					@click="$u.route('/pages/marketQuotations/productDetails',{code:item.code});">
					<template v-if="!item.logo || item.logo==''">
						<view style="width: 30px;height: 30px;background-color:#2d2c62;text-align: center;line-height: 30px;color: #FFFFFF;margin-bottom: 4px;;border-radius: 100%;">{{item.ko_name.slice(0,1)}}</view>
					</template>
					<template v-else>
						<image mode="aspectFit" :src="item.logo" style="width: 30px;height: 30px;border-radius: 100%;"></image>
					</template>	
					
					<!-- <u--image :src="item.logo" shape="circle" width="30px" height="30px"></u--image> -->
					<view style="background-color: #e3ebfa;border-radius: 3px;padding: 3px 8px;" class="margin-left-20">
						{{item.ko_name}}
					</view>
					<view style="margin-left:auto;">
						<view class="flex" style="gap: 20px">
							<view :class="item.returns>0?'red bold':'green bold'">{{numberToCurrency(item.close*1)}}
							</view>
							<view style="border-radius: 3px;padding: 3px 8px;color: #fff;font-weight: 700; "
								:class="item.returns>0?'bg-red':'bg-green'">
								{{item.returns>0?'+':""}}{{(1*item.returns).toFixed(2)}}%
							</view>
						</view>

					</view>
				</view>

			</view>
		</view>

		<!-- 每次由登入跳转进入时，显示该弹层，关闭后，不再显示。 -->

		<template v-if="peishou_order&&isShow">
			<view class="mask" @click="handleClose">
				<view style="position: fixed;top: 26vh;right: 12vw;z-index: 1000;" @click="handleClose">
					<image src="/static/close.png" mode="widthFix" style="width: 30px;height: 30px;"></image>
				</view>
				<view style="position: fixed;top:25vh;left: 50%;transform: translateX(-50%);">
					<view class="bg_ad" style="display: flex;flex-wrap: nowrap;flex-direction: column; align-items: center;justify-content: center;border-radius: 20px;">
						<view style="width: 90%;background-color: #fbfdff;border-radius: 6px;text-align: center;padding:10px 10px 20px 10px;margin-top: 90px;">
							<view style="font-size: 20px;padding: 10px 0 2px 0;color:#4451da;">{{peishou_order.goods.name}}</view>
							<view style="font-size: 11px;color:#999;padding:2px 0 10px 0;">{{peishou_order.goods.number_code}}</view>
							<view style="padding: 10px 0;"><text style="font-weight: 700;color:#ff3636;">배치 수량:{{numberToCurrency(peishou_order.success)}}</text></view>
							<view style="padding: 10px 0;"><text style="font-weight: 700;color:#ff3636;">일시금:{{numberToCurrency(peishou_order.total)}}</text></view>
							<view style="padding: 10px 0;line-height: 1;background-color: #4752dbbf;border-radius: 100px;color:#FFF;margin:20px 30px;" @click="tiaozhuan(peishou_order.type)">지금 구매</view>
						</view>
					</view>
				</view>
			</view>
		</template>

	</view>
</template>

<script>
	import {
		TYPES
	} from '../../consts/index.js'
	export default {
		data() {
			return {
				isShow: true, // 是否显示ad层,
				userinfo: [],
				show_money: true,
				page: 1,
				list: [],
				gp_index: 0,
				keyword: "",
				business: "",
				peishou_order:""
			}
		},
		
		computed:{
			adStock(){
				if(this.isShow &&this.list.length>0){
				return this.list[0];	
				}
			}
		},

		methods: {
			tiaozhuan(type){
				if(type=="scramble"){
					uni.navigateTo({
						url:'/pages/index/components/newShares/ration/ration'
					})
				}else{
					uni.navigateTo({
						url:'/pages/index/components/newShares/luckyNumber/luckyNumber'
					})
				}
			},
			async placement() {
				let list = await this.$http.get('api/goodsscramble/userApplyLog1', {})
				this.peishou_order = list.data.data
				console.log(777,list.data.data)
				// console.log(list.data.data[0], '抢筹');
			},
			// AD层关闭
			handleClose() {
				this.isShow = false;
			},

			qiehuan(index) {
				this.gp_index = index
				this.good_list()
			},
			link(type, url) {
				if (type == 1) {
					uni.switchTab({
						url: url
					})
				} else if (type == 3) {
					uni.reLaunch({
						url: url
					})
				} else {
					uni.navigateTo({
						url: url
					})
				}
			},
			// 银转证
			silver(money, bank_card_info, idno) {
				// if (bank_card_info && idno !== null) {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/index/components/customer/customer'
				});
				// } else if (bank_card_info == null) {
				// 	uni.$u.toast('은행 카드에 묶여 있지 않음');
				// 	setTimeout(() => {
				// 		uni.navigateTo({
				// 			//保留当前页面，跳转到应用内的某个页面
				// 			url: '/pages/my/components/bankCard/renewal'
				// 		});
				// 	}, 2000)
				// } else if (idno == null) {
				// 	uni.$u.toast('실명인증 불가');
				// 	setTimeout(() => {
				// 		uni.navigateTo({
				// 			//保留当前页面，跳转到应用内的某个页面
				// 			url: '/pages/index/components/openAccount/openAccount'
				// 		});
				// 	}, 2000)
				// }

			},
			/* 数字金额逢三加， 比如 123,464.23 */
			numberToCurrency(value) {
				if (!value) return '0'
				// 将数值截取，保留两位小数
				value = value.toFixed(2)
				// 获取整数部分
				const intPart = Math.trunc(value)
				// 整数部分处理，增加,
				const intPartFormat = intPart.toString().replace(/(\d)(?=(?:\d{3})+$)/g, '$1,')

				return intPartFormat
			},
			//定时器
			startTimer() {
				const storedTimerId = uni.getStorageSync('timerId');
				if (storedTimerId) {
					clearInterval(storedTimerId);
				}
				this.timerId = setInterval(() => {
					this.good_list()
					this.free()
				}, 3000);
				uni.setStorageSync('timerId', this.timerId);
				// 在这里立即执行一次请求
			},
			async good_list() {

				// this.list=[]
				let list = await this.$http.get('api/goods/list', {
					page: this.page,
					gp_index: this.gp_index
				})
				// if(this.page==1){
				this.list = list.data.data
				// }else{
				// 	this.list = this.list.concat(list.data.data)
				// }

			},
			//用户信息
			async gaint_info() {
				let list = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				})
				this.userinfo = list.data.data
			},
			is_token() {
				let token = uni.getStorageSync('token') || '';
				if (!token) {
					try {
						uni.clearStorageSync();
					} catch (e) {
						// error
					}
					uni.showLoading({
						title: '먼저 로그인을 해주세요',
						duration: 1000,
					})
					setTimeout(() => {
						uni.navigateTo({
							url: '/pages/logon/logon/logon'
						});
					}, 1000)
				} else {

				}
			},
			async free() {
				let list = await this.$http.get('api/user/collect_list', {})
				this.business = list.data.data.list
			},


		},
		onUnload() {
			clearInterval(this.timerId);
		},
		onHide() {
			clearInterval(this.timerId);
		},
		onLoad() {

		},
		async onShow() {
			this.page = 1;
			this.is_token()
			this.good_list()
			this.gaint_info()
			this.free()
			this.startTimer()
			this.placement()
		},

		onReachBottom() {
			this.page = this.page + 1;
			this.good_list()
		}

	}
</script>

<style lang="scss">
	view,
	uni-text {
		box-sizing: border-box;
	}

	.page {
		min-height: 100vh;
		background-color: #F3F4F8;
	}

	.home {
		background-image: url(/static/chuanggai/home-top.png);
		/* 背景图片覆盖整个容器，可能会裁剪 */
		background-size: cover;
		/* 让背景图片始终位于容器的中心 */
		background-position: center;
		/* 不重复背景图片 */
		background-repeat: no-repeat;
		height: 600rpx;
		margin-left: -10px;
	}

	.mask {
		background-color: rgba(0, 0, 0, 0.35);
		position: fixed;
		top: 0;
		left: 0;
		width: 100vw;
		height: 100vh;
		z-index: 999;
	}
	
	.bg_ad {
		background-image: url(/static/bg_ad.png);
		background-size: cover;
		background-position: center;
		background-repeat: no-repeat;
		height: 50vh;
		width: 80vw;
	}
</style>