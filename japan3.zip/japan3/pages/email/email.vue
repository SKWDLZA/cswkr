<template>
	<view >
		<CustomHeader title="알림" @action="$u.route({type:'navigateBack'})"></CustomHeader>
		<view class="common_block">
			<view
				style="width: 100%;display:flex;flex-direction: column;justify-items: center;align-items: center;padding: 23vh 0;">
				<u-image src="/static/email.png" width="411px" mode="aspectFit"></u-image>
				<view class="text-center" style="color: #6D6D6D;font-size: 14px;padding-top:30px">メッセージなし</view>
			</view>
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components:{CustomHeader},
		data() {
			return {
				//
				tablist: [{
					name: '全体'
				}, {
					name: '信号通知'
				}, {
					name: 'コミュニティ'
				}, {
					name: '一般'
				}],
				current: 0
			}
		},
		onShow() {},
		onLoad(op) {
			if (op.type) {
				this.current = op.type
			}
		},
		onUnload() {
			clearInterval(this.timerId);
		},
		onHide() {
			clearInterval(this.timerId);
		},

		methods: {
			change(index) {
				console.log(index)
				this.current = index;
			},
			home() {
				uni.switchTab({
					url: '/pages/index/index'
				});
			},
		},
	}
</script>
