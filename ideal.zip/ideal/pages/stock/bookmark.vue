<template>
	<view>
		<Header></Header>
		<view class="flex margin-20" style="margin-top: 80px;">
			<image src="/static/anniu.png" mode="widthFix" style="width: 20px;margin-right: 10px;"></image>
			<view>관심종목추가</view>
		</view>
		<view class="common_block"
			style="margin-top: 20px;padding: 10px;box-shadow: rgba(99, 99, 99, 0.2) 0px 2px 8px 0px;">

			<view style="min-height: 60vh;">
				<block v-for="(item,index) in list" :key="index">
					<view @click="productDetails(item.goods.code,item.id)" class="line"
						style="display: flex;align-items: center;margin:6px 10px;padding-bottom: 6px;">
						<template v-if="!item.goods.logo || item.goods.logo==''">
							<view :style="$util.calcImageSize(30)"
								style="background-color:#2d2c62;text-align: center;line-height: 30px;color: #FFFFFF;margin-bottom: 4px;border-radius: 100%;">
								{{item.goods.name.slice(0,1)}}</view>
						</template>
						<template v-else>
							<image mode="aspectFit" :src="$BaseUrl+item.goods.logo" :style="$util.calcImageSize(30)"
								style="border-radius: 100%;"></image>
						</template>

						<view style="margin-left: 10px;">
							<view style="flex:40%;" :style="{color:$util.THEME.TEXT}">
								{{item.goods.name}}
							</view>
							<view style="flex:15%;font-weight: 900;padding-right: 16px;"
								:style="$util.calcStyleRiseFall(item.goods.rate>0)">{{item.goods.code}}</view>
						</view>


						<view style="flex:25%;text-align: right; padding-right: 16px;"
							:style="$util.calcStyleRiseFall(item.goods.rate>0)">
							{{$util.formatNumber(item.goods.current_price)}}
						</view>
						<view style="flex:15%;text-align: right; padding-right: 16px;"
							:style="$util.calcStyleRiseFall(item.goods.rate>0)">
							{{item.goods.rate>0?'+':''}}{{item.goods.rate}}%
						</view>
						<view style="flex:5%;">
							<image mode="aspectFit" src="/static/star.png" :style="$util.calcImageSize(24)"
								@click.stop="handleClickDelProduct(item.goods.gid)"></image>
						</view>
					</view>
				</block>
				<EmptyData v-if="list.length<=0"></EmptyData>
			</view>
		</view>
	</view>
</template>

<script>
	import Header from '@/components/Header.vue';
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		components: {
			Header,
			EmptyData,
		},
		data() {
			return {
				list: [],
				timer: null,
			}
		},
		onShow() {
			this.getList()
			this.startTimer()
		},
		onHide() {
			clearInterval(this.timer);
		},
		methods: {
			productDetails(code, id) {
				uni.navigateTo({
					url: `${this.$util.PAGE_URL.STOCK_OVERVIEW}?code=${code}&id=${id}`
				});
			},
			//定时器
			startTimer() {
				this.timer = setInterval(() => {
					this.getList();
				}, 5000);
			},

			async getList() {
				if (this.list.length <= 0) {
					uni.showLoading({
						title: this.$lang.LOADING,
					})
				}
				const result = await this.$http.get(this.$http.API_URL.COLLECT_LIST, {});
				if (this.list.length <= 0 || result.data.code == 0) {
					uni.hideLoading();
				}
				this.list = result.data.data.list;
			},

			// 点击删除
			async handleClickDelProduct(gid) {
				const result = await this.$http.post(this.$http.API_URL.COLLECT_EDIT, {
					gid: gid,
				})
				if (result.data.code == 0) {
					uni.$u.toast(result.data.message);
					this.getList()
				} else {
					uni.$u.toast(result.data.message);
				}
			},
		},
	}
</script>