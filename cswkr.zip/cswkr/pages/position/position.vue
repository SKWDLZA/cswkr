<template>
	<view class="page">
		<view class="flex" style="background-color: #212265;padding: 10px;">
			<view class="flex-2" style="color: #fff;font-size: 38rpx;">투자내역</view>
			<view class="flex-2 flex" @click="$u.route({url:'/pages/searchFor/searchFor'});">
				<u--input shape="circle" suffixIconStyle="font-size: 24px;color: #fff;margin-right:10px"
					suffixIcon="/static/sousuo.png" type="number" maxlength="11" border="none" :disabled="true"
					style="pointer-events: none"
					customStyle="background: rgba(255,255,255,0.25);height:60rpx;margin-left: auto;pointer-events: none"></u--input>
			</view>
			<view @click="$u.route({url:'/pages/email/email'});">
				<!-- <u-icon name="/static/laba.png" style="margin-left: 10px;"></u-icon> -->
			</view>

		</view>

		<view
			style="border-radius: 10px;background: #fff;margin: 10px;box-shadow: rgba(0, 0, 0, 0.15) 1.95px 1.95px 2.6px;">
			<view class="flex padding-top-10 padding-bottom-10">
				<view style="border-radius: 0 16rpx 16rpx 0;width: 5px;height: 30px;background-color: #212265;"></view>
				<view class="margin-left-10 bold font-size-16">205-01-{{userInformation.uid}}</view>
				<view class="margin-left-5 hui font-size-10 ">[CMA]{{userInformation.real_name}}</view>
				<view class="left-auto margin-right-10 flex gap5" @click="gp_show=true">

					{{gp_select[0][gp_index]}}
					<u-icon name="arrow-down" :bold="true"></u-icon>
				</view>
			</view>
			<view class="flex flex-b padding-10 padding-bottom-20 gap10">
				<view class="text-center padding-10" style="background-color: #c1ddf6;width: 100%;border-radius: 6px;">
					예수금
					{{userInformation.money.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}
				</view>
				<view class="text-center padding-10 color-white"
					style="background-color: #212265;width: 100%;border-radius: 6px;" @click="duihuan">출금신청</view>
			</view>
		</view>

		<view
			style="border-radius: 10px;background: #fff;margin: 10px;padding:10px;box-shadow: rgba(0, 0, 0, 0.15) 1.95px 1.95px 2.6px;">
			<view class="flex flex-b " style="box-shadow: 0px 5px 5px -5px rgba(0, 0, 0, 0.5);">
				<view class="text-center width100" :class="Inv==0?'with-bottom-line':''" @click="qiehuan(0)">
					종목 보유 현황
				</view>
				<view class="text-center width100" :class="Inv==1?'with-bottom-line':''" @click="qiehuan(1)">
					매매 내역
				</view>
			</view>
			<view style="background-color: #e5e9ef;" class="margin-top-10 padding-5 radius10 flex flex-b">
				<view class="radius10 background-white padding-10 flex-1 text-center">
					투자성과
				</view>
				<view class="padding-10 flex flex-1 justify-end" @click="shuaxin">
					<u-icon name="/static/market/shuaxin.png" style="margin-right: 5px;"></u-icon>
					새로고침
				</view>
			</view>
			<view class="flex flex-b margin-top-15 gap5">
				<view class="flex flex-b flex-1">
					<view style="background-color: #cae2f7;color: #636363;width: 75px;height: 50px;display: flex;align-items: center;justify-content: center;" class="text-center padding-10">
						매입금액
					</view>
					<view class="text-right">
						{{userInformation.frozen.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}
					</view>
				</view>
				<view class="flex flex-b flex-1">
					<view style="background-color: #cae2f7;color: #636363;width: 75px;height: 50px;display: flex;align-items: center;justify-content: center;" class="text-center padding-10">
						평가수익금
					</view>
					<view class="text-right" :class="userInformation.holdYingli>0?'red':'green'">
						{{userInformation.holdYingli.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}
					</view>
				</view>
			</view>
			<view class="flex flex-b margin-top-5 gap5">
				<view class="flex flex-b flex-1">
					<view style="background-color: #cae2f7;color: #636363;width: 75px;height: 50px;display: flex;align-items: center;justify-content: center;" class="text-center padding-10">
						평가금액
					</view>
					<view class="text-right">
						{{userInformation.guzhi.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}
					</view>
				</view>
				<view class="flex flex-b flex-1">
					<view style="background-color: #cae2f7;color: #636363;width: 75px;height: 50px;display: flex;align-items: center;justify-content: center;" class="text-center padding-10">
						평가수익률
					</view>
					<view class="text-right" :class="userInformation.holdYingli>0?'red':'green'">
						{{userInformation.huibao}}%
					</view>
				</view>
			</view>
			<view class="flex flex-b margin-top-5 gap5" style="align-items: stretch;">
				<view class="flex flex-b flex-1">
					<view style="background-color: #cae2f7;color: #636363;width: 75px;height: 50px;display: flex;align-items: center;justify-content: center;" class="text-center padding-10">
						총자산
					</view>
					<view class="text-right">
						{{userInformation.totalZichan.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}
					</view>
				</view>
				<view class="flex flex-b flex-1">
					<view style="background-color: #cae2f7;color: #636363;width: 75px;height: 100%;display: flex;align-items: center;justify-content: center;" class="text-center padding-10">
						실현손익
					</view>
					<view class="text-right" :class="userInformation.totalYingli>0?'red':'green'">
						{{userInformation.totalYingli.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}
					</view>
				</view>
			</view>
			<u-gap height="5" bgColor="#C1DDF6" style="margin:14px -10px -10px; 10px"></u-gap>

			<view class="flex flex-b margin-top-20 gap5" style="align-items:stretch;">
				<view class="flex-1 text-center hui2 padding-5 radius10" style="background-color: #c2dbf4;align-items: stretch;">
					<view style="background-color: #fff;height: 100%;" class="padding-5 radius10 ">
						<view class="font-size-12" style="flex-grow: 1;height: 100%;display: flex;align-items: center;justify-content: center;">
							종목명
						</view>
						<!-- <view class="margin-top-10 font-size-12">
							구분
						</view> -->
					</view>
				</view>
				<view class="flex-1 text-center hui2 padding-5 radius10" style="background-color: #c2dbf4;">
					<view style="background-color: #fff;" class="padding-5 radius10">
						<view class="font-size-12">
							평가수익금
						</view>
						<view class="margin-top-10 font-size-12">
							평가수익률
						</view>
					</view>
				</view>
				<view class="flex-1 text-center hui2 padding-5 radius10" style="background-color: #c2dbf4;">
					<view style="background-color: #fff;" class="padding-5 radius10">
						<view class="font-size-12">
							보유수량
						</view>
						<view class="margin-top-10 font-size-12">
							평가금액
						</view>
					</view>
				</view>
				<view class="flex-1 text-center hui2 padding-5 radius10 " style="background-color: #c2dbf4;">
					<view style="background-color: #fff;" class="padding-5 radius10">
						<view class="font-size-12">
							평단가
						</view>
						<view class="margin-top-10 font-size-12">
							현재가
						</view>
					</view>
				</view>
			</view>
			<view class="margin-top-10 gap5">
				<view class="flex flex-b margin-top-5" v-for="(item,index) in storehouse" :key="index"
					@tap="sell(item)">
					<view class="padding-5" :class="index%2==0?'bgyellow':'bglan'" style="width: 24%">
						<view class="">
							{{item.goods_info.name}}
						</view>
						<!-- <view  class="margin-top-10" style="color: #899C6C	;">
							현금
						</view> -->
					</view>
					<view class="padding-5 flex flex-b" :class="index%2==0?'bgyellow':'bglan'" style="width: 75%">
						<view :class="item.order_buy.float_yingkui>0?'red':'green'" class="flex-1" v-if="Inv==0">
							<view>
								{{item.order_buy.yingkui.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}
							</view>
							<view class="margin-top-10 ">
								{{(item.order_buy.yingkui/item.order_buy.user_pay/item.order_buy.double*100).toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}%
							</view>
						</view>
						<view :class="item.order_sell.yingkui>0?'red':'green'" class="flex-1" v-if="Inv==1">
							<view>
								{{item.order_sell.yingkui.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}
							</view>
							<view class="margin-top-10 ">
								{{(item.order_sell.yingkui/item.order_buy.user_pay/item.order_buy.double*100).toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}%
							</view>
						</view>

						<view class="flex-1">
							<view class="text-right">
								{{item.order_buy.num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}
							</view>
							<view class="margin-top-10 text-right">
								{{(item.goods_info.current_price*1*item.order_buy.num).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}
							</view>
						</view>

						<view class="flex-1">
							<view class="text-right">
								{{(item.order_buy.price).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}
							</view>
							<view class="margin-top-10 text-right red" v-if="Inv==0">
								{{(item.goods_info.current_price).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}
							</view>
							<view class="margin-top-10 text-right red" v-if="Inv==1">
								{{(item.order_sell.price).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}
							</view>
						</view>
					</view>
				</view>

			</view>
		</view>

		<u-picker :show="gp_show" :columns="gp_select" cancelText="취소" confirmText="확인" :closeOnClickOverlay="true"
			@close="gp_show=false" @cancel="gp_show=false" @confirm="gp_changes"></u-picker>



		<view class="overlay" v-if="item_show" @click="item_show=false"></view>
		<view
			style="position: fixed;width: 90%;margin-left: 5%;border-radius: 20px;background-color: #212265;top: 20%;z-index: 9999;"
			v-if="item_show">
			<view class="color-white  padding-10 flex ">
				<view class="text-center justify-center width100 font-size-16">세부</view>

				<u-icon name="/static/market/close.png" size="24" @click="item_show=false"></u-icon>
			</view>
			<view class="flex flex-b padding-10" style="background-color: #fff;">
				<view class="flex flex-b flex-1">
					<view class="flex-1 bold">종목</view>
					<view class="flex-1">{{info.goods_info.name}}</view>
				</view>

			</view>
			<view class="flex flex-b padding-10" style="background-color: #fff;">
				<view class="flex flex-b flex-1">
					<view class="flex-1 bold">매수 시간</view>
					<view class="flex-1">{{info.order_buy.created_at}}</view>
				</view>

			</view>
			<view class="flex flex-b padding-10" style="background-color: #fff;" v-if="Inv==1">
				<view class="flex flex-b flex-1">
					<view class="flex-1 bold">매도시간</view>
					<view class="flex-1">{{info.order_sell.created_at}}</view>
				</view>

			</view>
			<view class="flex flex-b padding-10" style="background-color: #fff;">
				<view class="flex flex-b flex-1">
					<view class="flex-1 bold">유동손익</view>
					<view class="flex-1" v-if="Inv==0">
						{{info.order_buy.float_yingkui.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</view>
					<view class="flex-1" v-if="Inv==1">
						{{info.order_sell.float_yingkui.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</view>
				</view>
				<view class="flex flex-b flex-1">
					<view class="flex-1 bold">레버리지</view>
					<view class="flex-1">X{{info.order_buy.double}}</view>
				</view>
			</view>
			<view class="flex flex-b padding-10" style="background-color: #fff;">
				<view class="flex flex-b flex-1">
					<view class="flex-1 bold">총손익</view>
					<view class="flex-1" v-if="Inv==0">
						{{info.order_buy.yingkui.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</view>
					<view class="flex-1" v-if="Inv==1">
						{{info.order_sell.yingkui.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</view>
				</view>
				<view class="flex flex-b flex-1">
					<view class="flex-1 bold">매입가</view>
					<view class="flex-1">{{info.order_buy.price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}
					</view>
				</view>
			</view>
			<view class="flex flex-b padding-10" style="background-color: #fff;">
				<view class="flex flex-b flex-1">
					<view class="flex-1 bold">수량</view>
					<view class="flex-1">{{info.order_buy.num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</view>
				</view>
				<view class="flex flex-b flex-1">
					<view class="flex-1 bold">수수료</view>
					<view class="flex-1">{{info.order_buy.buy_fee.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}
						<span
							v-if="Inv==1">/{{info.order_sell.sell_fee.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</span>
					</view>
				</view>
			</view>
			<view class="flex flex-b padding-10" style="background-color: #fff;">
				<view class="flex flex-b flex-1">
					<view class="flex-1 bold">총 매입가</view>
					<view class="flex-1">{{info.order_buy.amount.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}
					</view>
				</view>
				<view class="flex flex-b flex-1">
					<view class="flex-1 bold">암호</view>
					<view class="flex-1">{{info.goods_info.number_code}}</view>
				</view>
			</view>
			<view class="text-center padding-20" style="background-color: #fff;border-radius: 0 0 20px 20px;">
				<view style="width: 100%;background-color: #3779CD;"
					class="padding-10 radius10 color-white font-size-16" v-if="Inv==0"
					@tap="productDetails(info.goods_info.number_code)">매수</view>

				<view style="width: 100%;background-color: #e82d28;"
					class="padding-10 radius10 color-white font-size-16 margin-top-10" v-if="Inv==0"
					@tap="position(info.id)">매도</view>
			</view>
		</view>
		<!-- 弹窗 -->
		<u-modal :show="show" :title="title" @cancel="cancel" @confirm="confirm(confirmation)"
			:showCancelButton='showCancelButton' :content='content' cancel-text="취소" confirm-text="확인">
		</u-modal>
	</view>
</template>

<script>
	export default {

		data() {
			return {
				gp_select: [
					["국내", "해외"]
				],
				gp_index: 0,
				gp_show: false,

				// //是否更新
				// updateFlag: false,
				// //每次版本更新都要修改
				// version: '2.1',
				// popupshow: true,
				downloadUrl: '',
				updateDesc: "",
				update: '',
				// closeOnClickOverlay: false,
				Inv: 0,
				items: ['종목 보유 현황', '매매 내역',
					// '보유수량', '매매내역'
				],
				show: false,
				title: '매도 주문',
				content: '매도 하시겠습니까?',
				showCancelButton: true,
				storehouse: '',
				storehouses: '',
				subscribe: '',
				luckyNumber: '',
				userInformation: '',
				timerId: null,
				info: [],
				item_show: false
			}
		},
		// watch: {
		// 	Inv: 'position'
		// },
		//下拉刷新
		onPullDownRefresh() {
			uni.showLoading({
				title: '로드 중',
			});
			//关闭加载提示
			setTimeout(() => {
				uni.hideLoading();
			}, 1000);
			this.shuaxin()
			uni.stopPullDownRefresh()
		},

		methods: {
			sell(item) {
				this.info = item
				this.item_show = true;
			},
			gp_changes(index) {
				console.log(index)
				this.gp_index = index.indexs[0]
				this.gp_show = false

				this.storehouse = ""

				this.shuaxin()
			},
			qiehuan(index) {
				this.Inv = index
				this.shuaxin()
			},
			shuaxin() {
				this.storehouse = ""
				uni.showLoading({
					mask: true
				})
				if (this.Inv == 1) {
					this.flat()
				} else {
					this.hold();
				}
			},
			// 平仓
			position(id) {
				this.item_show = false
				this.show = true;
				this.confirmation = id


			},
			//点击取消
			cancel() {
				this.show = false;
			},
			// 点击确认
			confirm(confirmation) {
				// this.show = false;
				// console.log(confirmation, '点击确定');
				this.closingFunction(confirmation)
				this.show = false;
			},
			//产品세부
			productDetails(code) {
				uni.navigateTo({
					url: '/pages/marketQuotations/productDetails' +
						`?code=${code}`
				});
			},

			//点击下标
			subscript() {
				this.Inv == items.index
				// console.log(this.Inv, '下标');
			},
			//搜索
			searchFor() {
				uni.navigateTo({
					url: '/pages/searchFor/searchFor'
				});
			},
			// 银转证
			silver() {
				if (this.userInformation.bank_card_info && this.userInformation.idno !== null) {
					uni.navigateTo({
						//保留当前页面，跳转到应用内的某个页面
						url: '/pages/my/components/commonFunctions/capitalDetails?index=1'
					});
				} else if (this.userInformation.bank_card_info == null) {
					uni.$u.toast('은행 카드에 묶여 있지 않음');
					setTimeout(() => {
						uni.navigateTo({
							//保留当前页面，跳转到应用内的某个页面
							url: '/pages/my/components/bankCard/renewal'
						});
					}, 2000)
				} else if (this.userInformation.idno == null) {
					uni.$u.toast('실명인증 불가');
					setTimeout(() => {
						uni.navigateTo({
							//保留当前页面，跳转到应用内的某个页面
							url: '/pages/index/components/openAccount/openAccount'
						});
					}, 2000)
				}

			},
			//用户信息
			async gaint_info() {
				let list = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				})
				this.userInformation = list.data.data
			},
			// 新股持仓
			async holdings(e) {
				let list = await this.$http.post('api/user/sg-order', {
					gp_index: this.gp_index
				})
				this.luckyNumber = list.data.data

			},

			// 구독기록
			async shengou(e) {
				let list = await this.$http.post('api/goods-shengou/user-all-apply-log', {
					gp_index: this.gp_index
				})
				this.subscribe = list.data.data
				console.log(this.subscribe, '1111111111')
				// console.log(list.data.data)
			},



			// 持仓
			async hold() {
				let list = await this.$http.get('api/user/order', {
					// language: this.$i18n.locale
					status: 1,
					gp_index: this.gp_index
				})
				this.storehouse = list.data.data
				uni.hideLoading()
				// console.log(list.data.data, '持仓');

			},
			//持仓
			async flat() {
				let list = await this.$http.post('api/user/order', {
					// language: this.$i18n.locale
					status: 2,
					gp_index: this.gp_index
				})
				// this.storehouses = list.data.data
				this.storehouse = list.data.data
				uni.hideLoading()
				// console.log(list.data.data, '持仓');
				// setTimeout(() => {
				// 	this.marketQuotations()
				// }, 10000)
			},
			// 平仓功能
			async closingFunction(confirmation) {
				uni.showLoading({
					title: "포지션을 마감 중입니다. 잠시 기다려 주세요....",
					mask: true, // 显示透明蒙层，防止触摸穿透
				});
				let list = await this.$http.post('api/user/sell', {
					id: confirmation,
					// price: item.price
				})
				// console.log(item.id, '平仓功能');
				if (list.data.code == 0) {
					this.shuaxin()
					uni.$u.toast(list.data.message);
					// this.$router.go(0)
					uni.hideLoading();

				} else {
					uni.$u.toast(list.data.message);
					uni.hideLoading();
				}

			},
			//版本更新
			is_token() {
				let token = uni.getStorageSync('token') || '';
			},
			async versionUpdate() {
				let list = await this.$http.get('api/version/detail', {})
				this.update = list.data.data
				let version = list.data.data.version
				let old_version = uni.getStorageSync('version') || 1.0
				// console.log(old_version, '当前版本111111111111111');
				if (old_version < version) {
					this.updateFlag = true
					this.$refs.update.upgrade()
					uni.setStorageSync('version', version)
				}
				// console.log(list.data.data, '版本更新');
			},
			//定时器
			startTimer() {
				const storedTimerId = uni.getStorageSync('timerId');
				if (storedTimerId) {
					clearInterval(storedTimerId);
				}
				this.timerId = setInterval(() => {
					console.log('위치요청');
					this.shuaxin()
					this.gaint_info()
				}, 8000);
				uni.setStorageSync('timerId', this.timerId);
				// 在这里立即执行一次请求

			},

			duihuan() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					// url: '/pages/my/components/duihuan/index'
					url: "/pages/my/components/certificateBank/prove"
				});
			}
		},

		onShow() {
			this.is_token()
			this.gaint_info()
			// this.flat()
			this.shuaxin()
			// this.startTimer()
		},

		onUnload() {
			console.log('포지션 종료됨1');
			clearInterval(this.timerId);
		},
		onHide() {
			console.log('포지션 종료됨2');
			clearInterval(this.timerId);
		},

	}
</script>

<style lang="scss">
	uni-view,
	uni-text {
		box-sizing: border-box;
	}

	page {
		background-color: #f3f4f8;
	}

	.with-bottom-line {
		color: #1d7ed2;
	}

	.with-bottom-line::after {
		content: "";
		/* 必须设置，表示插入的内容为空 */
		display: block;
		/* 使得::after生成的元素成为块级元素 */
		border-bottom: 2px solid #1d7ed2;
		/* 添加底部横线 */
		width: 60%;
		/* 使横线宽度与父元素相同 */
		margin-top: 10px;
		/* 可选：添加一些顶部外边距 */
		text-align: center;
		margin-left: 20%;
	}

	.bglan {
		background-color: #EEF4FF;
	}

	.bgyellow {
		background-color: #F8F8F8;
	}

	/* 遮罩层 */
	.overlay {

		position: fixed;
		/* Stay in place */
		top: 0;
		left: 0;
		width: 100%;
		/* Full width */
		height: 100%;
		/* Full height */
		z-index: 999;
		/* Sit on top */
		background-color: rgba(0, 0, 0, 0.5);
		/* Black background with opacity */
		cursor: pointer;
		/* Add a pointer on hover */
	}
</style>