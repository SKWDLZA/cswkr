<!-- 学院 -->
<template>
	<view>
		<CustomHeader title="IPO 세부사항" @action="handleBack()"></CustomHeader>

		<view
			style="padding: 10px;margin:20px 10px;background-color: #fff;border-radius: 10px;box-shadow: rgba(0, 0, 0, 0.15) 1.95px 1.95px 2.6px;">

			<h4>{{detailed.name}}</h4>

			<view class="area" v-if="detailed.locate=='깊은'">
				<view class="deep">{{detailed.locate}}</view>
				<view class="deep-number">{{detailed.code}}</view>
			</view>
			<view class="area" v-if="detailed.locate=='북쪽'">
				<view class="north">{{detailed.locate}}</view>
				<view class="north-number">{{detailed.code}}</view>
			</view>
			<view class="area" v-if="detailed.locate=='상하이'">
				<view class="shanghai">{{detailed.locate}}</view>
				<view class="shanghai-number">{{detailed.code}}</view>
			</view>

			<view style="border-bottom: 1rpx dashed #ccc;padding-bottom: 20rpx;">
				<view class="issue">
					<view class="">
						<text>발행 가격</text> <text
							style="color: #f85252;">{{$util.formatNumber(price.price)}}</text>
					</view>
					<view class="">
						<text>주가수익비율</text> <text
							style="color: #f85252;">{{$util.formatNumber(price.shiying)}}</text>
					</view>
					<view class="">
						<text>총 발행량</text> <text
							style="color: #f85252;">{{$util.formatNumber(price.fa_amount)}}</text>
					</view>

				</view>

				<view class="">
					<u-steps current="0" activeColor="#f85050">
						<u-steps-item title="구독 날짜" :desc="title1.shengou_date"></u-steps-item>
						<u-steps-item title="발표일" :desc="title2.gb_date"></u-steps-item>
						<u-steps-item title="구독 날짜" :desc="title3.rj_date"></u-steps-item>
						<u-steps-item title="상장예정"
							:desc="title4.online_date ? title4.online_date : '예고 없는'"></u-steps-item>
					</u-steps>
				</view>

			</view>

			<view class="general">
				<h4>이슈 개요</h4>
				<view class="display">
					<view class="front">기금 모금</view>
					<view>{{price.fa_muji_zijin}}</view>
				</view>
				<!-- 	<view class="display">
				<view class="front">中签率</view>
				<view>{{price.success}}</view>
			</view> -->
				<view class="display">
					<view class="front">당첨일 발표</view>
					<view>{{price.gb_date}}</view>
				</view>
				<view class="display">
					<view class="front">기금 약속의 날</view>
					<view>{{price.rj_date}}</view>
				</view>
				<view class="display">
					<view class="front">상장일</view>
					<view v-if="price.online_date!=null">{{price.online_date}}</view>
					<view v-if="price.online_date==null">예고 없는</view>
				</view>
			</view>
			<view v-if="detailed.name!=null" class="purchases" @click="position(price.id)" style="background-color:  #4b5fcc;		margin: 30rpx 0;
		border-radius: 10rpx;
		padding: 20rpx 0;
		text-align: center;
		color: #fff;
		font-weight: 600;
		font-size: 32rpx;
		margin: 30rpx;">
				신청</view>
			<!-- position(price.id) -->

			<!-- 弹窗 -->
			<u-modal :show="show" :title="title" @cancel="cancel" @confirm="confirm(confirmation)"
				:showCancelButton='showCancelButton' :content='content' cancel-text="취소" confirm-text="확인">
			</u-modal>

			<u-modal :show="show_mima" :title="title" @confirm="position(confirmation)">
				<u--input placeholder="비밀번호를 입력 해주세요" type="password" border="surround" v-model="password"></u--input>
			</u-modal>
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components: {
			CustomHeader,
		},
		data() {
			return {
				password: "",
				show_mima: false,
				value: "",
				detailed: "",
				price: '',
				title1: '',
				title2: '',
				title3: '',
				title4: '',
				show: false,
				title: '힌트',
				content: '구독을 확인하려면 클릭하세요.',
				showCancelButton: true,
				confirmation: "",
			};
		},
		methods: {
			shengou_mima(id) {
				this.show_mima = true;
				this.confirmation = id

			},
			//申购
			async position(id) {
				this.purchase(id)
				this.show = false;
			},
			//点击取消
			cancel() {
				this.show = false;
			},
			// 点击确认
			confirm(confirmation) {
				// this.show = false;
				// console.log(confirmation, '点击确定');
				this.purchase(confirmation)
				this.show = false;
			},
			//跳转
			handleBack() {
				uni.navigateBack({
					delta: 1, //返回层数，2则上上页
				});
			},
			// 点击申购
			async purchase(confirmation) {
				let list = await this.$http.post('api/goods-shengou/doOrder', {
					num: this.value,
					id: confirmation,
					// price: this.price
				})
				if (list.data.code == 0) {
					uni.showLoading({
						title: "구독이 진행 중입니다. 잠시 기다려 주세요....",
						mask: true, // 显示透明蒙层，防止触摸穿透
					});
					setTimeout(() => {
						uni.navigateTo({
							url: '/pages/applyPurchaseLog'
						});
						uni.hideLoading();
					}, 1000)
				} else {
					uni.$u.toast(list.data.message);
				}
			},
			//
			async information() {
				let list = await this.$http.get('api/goods-shengou/detail', {
					id: this.id
				})
				// console.log(list.data.data);
				this.detailed = list.data.data.goods
				this.price = list.data.data
				this.title1 = list.data.data
				this.title2 = list.data.data
				this.title3 = list.data.data
				this.title4 = list.data.data
				// console.log(this.detailed, '세부');
			},

		},
		//传值过来接收
		onLoad(option) {
			this.id = option.id
			// this.price = option.fa_price
		},
		// 进入页面就开始渲染
		mounted() {
			// uni.showLoading({
			// 	title: '加载中'
			// });
			this.information()
		},

	}
</script>

<style lang="scss">
	/deep/.u-input {
		background: #f5f5f5;
	}

	/deep/.u-modal__content__text {
		text-align: center;
	}

	//公共css 开始
	.display {
		display: flex;
		justify-content: space-between;
		align-items: center;
	}

	//깊은북쪽상하이
	.area {
		display: flex;
		justify-content: flex-start;
		align-items: center;
	}

	//깊은
	.deep {
		width: 30rpx;
		height: 30rpx;
		background: #f85252;
		border-radius: 0.4rpx;
		text-align: center;
		line-height: 30rpx;
		color: #fff;
		font-size: 24rpx;
		display: inline-block;
	}

	.deep-number {
		display: inline-block;
		padding: 0 0.04rem;
		background: rgba(59, 79, 222, .1);
		border-radius: 10rpx;
		color: #f85252;
		font-size: 24rpx;
		vertical-align: middle;
	}

	//북쪽
	.north {
		width: 30rpx;
		height: 30rpx;
		background: #ea6248;
		border-radius: 0.4rpx;
		text-align: center;
		line-height: 30rpx;
		color: #fff;
		font-size: 24rpx;
		display: inline-block;
	}

	.north-number {
		display: inline-block;
		padding: 0 0.04rem;
		border-radius: 10rpx;
		font-size: 24rpx;
		vertical-align: middle;
		color: #ea6248;
		background: rgba(234, 98, 72, .1);
	}

	//상하이
	.shanghai {
		width: 30rpx;
		height: 30rpx;
		background: #aa3bde;
		border-radius: 0.4rpx;
		text-align: center;
		line-height: 30rpx;
		color: #fff;
		font-size: 24rpx;
		display: inline-block;
	}

	.shanghai-number {
		display: inline-block;
		padding: 0 0.04rem;
		border-radius: 10rpx;
		font-size: 24rpx;
		vertical-align: middle;
		color: #aa3bde;
		background: rgba(170, 59, 222, .1);
	}

	//公共css 结束
	/deep/.u-text {
		flex-direction: column !important;
	}

	.college-bg {
		padding: 60rpx 30rpx 30px;
		height: 80rpx;
		background-color: #212265;
		display: flex;
		justify-content: space-between;
		align-items: center;
		text-align: center;

		image {
			width: 20rpx;
			height: 40rpx;
		}

		.college-text {

			color: #fff;
			font-weight: 800;
			font-size: 36rpx;
		}

	}

	.company-name {
		margin-top: -60rpx;
		background: #fff;
		border-radius: 20rpx 20rpx 0 0;
		padding: 30rpx;
		border-bottom: 1rpx dashed #ccc;
	}

	.issue {
		display: flex;
		flex-wrap: wrap;
		justify-content: space-between;
		align-items: center;
		margin: 30rpx;
		font-size: 24rpx;

		view {
			width: 42%;
			display: flex;
			justify-content: space-between;
			align-items: center;

		}

		text {
			margin: 10rpx 0;
		}
	}

	.general {
		padding: 30rpx;
		font-size: 26rpx;

		h4 {
			font-size: 32rpx;
		}

		view {
			margin: 6rpx 0;
		}

		.front {
			color: #999;
		}
	}

	.purchase {
		padding: 30rpx;
		font-size: 26rpx;
		border-radius: 30rpx 30rpx 0 0;
		background: #f4f4f4;


		h4 {
			font-size: 32rpx;
		}

		.apply {
			display: flex;
			justify-content: space-between;
			align-items: center;

			text {
				color: #f85050;
				margin-left: 20rpx;
			}
		}

		input {
			background: #fff;
			display: block;
			margin: 30rpx 0;
			padding: 20rpx;
			border-radius: 10rpx;
			font-size: 28rpx;
			// color: #C0C4CC;

		}

		.purchases {
			background-color: #212265;
			margin: 30rpx 0;
			border-radius: 10rpx;
			padding: 20rpx 0;
			text-align: center;
			color: #fff;
			font-weight: 600;
			font-size: 32rpx;
		}
	}
</style>