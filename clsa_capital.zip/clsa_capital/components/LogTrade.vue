<template>
	<view>
		<EmptyData v-if="list.length<=0"></EmptyData>
		<block v-for="(item,index) in list" :key="index">
			<view class="line common_block" style="margin:0 10px 20px 10px;padding:10px;">
				
				<view style="display: flex;align-items: center;">
					<view style="flex:30%;" :style="{color:$util.THEME.TIP}">금액</view>
					<view style="flex:70%;font-size: 18px;font-weight: 700;" :style="{color:$util.THEME.PRIMARY}">
						{{$util.formatNumber(item.money)}}
					</view>
				</view>
				
				<view style="display: flex;align-items: center;">
					<view style="flex:30%;" :style="{color:$util.THEME.TIP}">잔액</view>
					<view style="flex:70%;" >
						{{$util.formatNumber(item.after)}}
					</view>
				</view>

				<view style="display: flex;align-items: center;">
					<view style="flex:30%;" :style="{color:$util.THEME.TIP}">거래전 잔액:</view>
					<view style="flex:70%;" :style="{color:$util.THEME.TEXT}">
						{{$util.formatNumber(item.before)}}
					</view>
				</view>
				<view style="display: flex;align-items: center;">
					<view style="flex:30%;" :style="{color:$util.THEME.TIP}">입금：</view>
					<view style="flex:70%;" :style="{color:$util.THEME.TEXT}">
					{{$util.formatNumber(item.desc)}}원
					</view>
				</view>
				<view style="display: flex;align-items: center;">
					<view style="flex:30%;" :style="{color:$util.THEME.TIP}">날짜 시간:</view>
					<view style="flex:70%;" :style="{color:$util.THEME.TIP}">
						{{item.created_at}}
					</view>
				</view>
				<view style="display: flex;align-items: center;">
					<view :style="{color:$util.THEME.TIP}">{{item.desc}}</view>
				</view>
			</view>
		</block>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: "LogTrade",
		components: {
			EmptyData,
		},
		data() {
			return {
				list: [],
			};
		},
		mounted() {
			this.getList()
		},
		methods: {
			async getList() {
				uni.showLoading({
					title: this.$lang.LOADING,
				})
				const result = await this.$http.get(this.$http.API_URL.USER_FINANCE, {})
				if (result.data.code == 0) {
					this.list = result.data.data;
					uni.hideLoading()
				} else {
					uni.$u.toast(result.data.message);
					uni.hideLoading()
				}
			},
		}
	}
</script>

<style>

</style>