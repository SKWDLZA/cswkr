<template>
	<view>
		<view style="position: fixed;top: 10px;left: 10px;z-index: 9999;" @click="$u.route({type:'navigateBack'});">
			<u-icon name="arrow-left" size="26" color="#db004c" :bold="true"></u-icon>
		</view>
		<web-view :src="url"></web-view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				url: ""
			};
		},
		onLoad(opt) {
			this.url=decodeURIComponent(opt.url)
		},
		methods: {},


	}
</script>

<style lang="scss">
	.page {
	    min-height: 100vh;
	}
	.lg-bg {
	    width: 100%;
	    height: 100%;
	    background: url(/static/lg-bg.png) no-repeat top/100%;
	}
	.lg {
	    padding: 55px 0;
	    text-align: center;
		.logo uni-image {
		    width: 100%;
		    height: 100%;
		}
	}
	.icon.logo {
	    width: 99px;
	    height: 99px;
	    border-radius: 50%;
	    overflow: hidden;
	}
	.form {
	    background: #fff;
	    padding: 0 16px;
	    font-size: 14px;
		.item .ipt {
		    height: 48px;
		    background: #f6f6f6;
		    border-radius: 24px;
		    padding: 0 11px;
		    margin-bottom: 16px;
			uni-input {
			    background: transparent;
			    padding-left: 11px;
			}
		}
		.btns {
		    padding-top: 11px;
		    padding-bottom: 11px;
			.login-btn {
			    height: 48px;
			    background: #eb333b;
			    border-radius: 24px;
			    font-size: 17px;
			    font-weight: 700;
			    color: #fff;
			}
		}
	}
	.lg-btn{
	    width: 50%;
	    height: 44px;
	    line-height: 44px;
	    background: #fff;
	    border-radius: 11px;
	    margin: 11px auto;
		uni-view {
		    font-size: 17px;
		    font-weight: 700;
		    color: #eb333b;
		}
		.icon {
		    margin-left: 5px;
		}
	}
	.kefu {
	    border-top: 1px solid #dedede;
	    width: 50%;
	    margin: 11px auto;
	    padding-top: 22px;
		.img {
		    width: 49px;
		    height: 49px;
		    background: #f6f6f6;
		    border-radius: 50%;
		}
	}
	
</style>