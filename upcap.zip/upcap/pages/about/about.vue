<!-- 关于我们 -->
<template>
	<view>
		<CustomHeader :title="about.title" @action="handleBack()"></CustomHeader>

		<view
			style="padding: 10px;
		font-size: 28rpx;border-radius: 10px;background: #fff;margin: 10px;box-shadow: rgba(0, 0, 0, 0.15) 1.95px 1.95px 2.6px;">
			<view style="color: #181945;line-height: 1.5;" v-html="about.content"></view>
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components: {
			CustomHeader
		},
		data() {
			return {
				about: ''
			};
		},
		mounted() {
			this.about_us()
		},
		methods: {
			handleBack() {
				uni.switchTab({
					url: '/pages/user/user'
				});
			},
			//关于我们
			async about_us() {
				let list = await this.$http.get('api/article/about-us', {});
				this.about = list.data.data
			},
		},
	}
</script>