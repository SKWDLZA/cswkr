<template>
	<view>
		<!-- 头部-->
		<view class="college-bg">
			<view class="account">
				<image src="../../../../../static/zuojiantou.png" mode="" @tap="home()"></image>
				<!-- <u-icon name="arrow-left" color="#fff" size="20" @tap="home()" class="icon"></u-icon> -->
				<view class="college-text">상위 10개 거래 주식</view>
				<image @tap="refresh()" class="renovate" src="../../../../../static/shuaxin.png" mode=""></image>
			</view>

			<view class="suo" @tap="searchFor()">
				<image src="../../../../../static/sousuo.png" mode=""></image>
			</view>
		</view>
		<!-- 选项卡 -->
		<view class="lookOver">
			<block v-for="(item,index) in items" :key="index">
				<view :class="['tab-content',content== index?'content-selection':'']" @click="content=index">
					{{item}}
				</view>
			</block>
		</view>

		<view class="stockCode">
			<view class="" style="text-align: left;">재고</view>
			<view class="">종가</view>
			<view class="">변경 사항</view>
			<view class="">순위</view>
		</view>

		<view class="lookContent">
			<!-- 选项卡一 -->
			<view class="one" v-show="content == 0">

				<view class="a-row" v-for="(item,index) in shangHai" :key='index'>
					<view class="share">
						<h5>{{item.secu_abbr}}</h5>
						<view class="area" v-if="item.locate=='깊은'">
							<view class="deep">{{item.locate}}</view>
							<view class="deep-number">{{item.secu_code}}</view>
						</view>
						<view class="area" v-if="item.locate=='북쪽'">
							<view class="north">{{item.locate}}</view>
							<view class="north-number">{{item.secu_code}}</view>
						</view>
						<view class="area" v-if="item.locate=='상하이'">
							<view class="shanghai">{{item.locate}}</view>
							<view class="shanghai-number">{{item.secu_code}}</view>
						</view>
					</view>
					<view class="figure">{{item.close_price}}</view>
					<view class="figure">{{item.px_change_rate}}</view>
					<view class="figure">{{item.rank}}</view>
				</view>

			</view>


			<!-- 选项卡二 -->
			<view class="two" v-show="content == 1">
				<view class="a-row" v-for="(item,index) in deep" :key='index'>
					<view class="share">
						<h5>{{item.secu_abbr}}</h5>
						<view class="area" v-if="item.locate=='깊은'">
							<view class="deep">{{item.locate}}</view>
							<view class="deep-number">{{item.secu_code}}</view>
						</view>
						<view class="area" v-if="item.locate=='북쪽'">
							<view class="north">{{item.locate}}</view>
							<view class="north-number">{{item.secu_code}}</view>
						</view>
						<view class="area" v-if="item.locate=='상하이'">
							<view class="shanghai">{{item.locate}}</view>
							<view class="shanghai-number">{{item.secu_code}}</view>
						</view>
					</view>
					<view class="figure">{{item.close_price}}</view>
					<view class="figure">{{item.px_change_rate}}</view>
					<view class="figure">{{item.rank}}</view>
				</view>


			</view>
		</view>



	</view>
</template>

<script>
	export default {
		data() {
			return {
				content: 0,
				items: [
					'상하이 증권 거래소 순위', '심천 증권거래소 순위'
				],
				shangHai: '',
				deep: ''
			};
		},
		methods: {
			changeTab(Inv) {
				that.navIdx = Inv;
			},
			home() {
				uni.switchTab({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/index/index'
				});
			},
			//搜索
			searchFor() {
				uni.navigateTo({
					url: '/pages/searchFor/searchFor'
				});
			},
			//刷新功能
			refresh() {
				uni.redirectTo({
					url: '/pages/index/components/secondRow/tradingShares/tradingShares'
				});
			},
			//상하이市
			async topTenshang() {
				let list = await this.$http.get('api/stock-api/BaseTop10Active', {
					exchange_kind: 1
				})
				this.shangHai = list.data.data
				// console.log(this.shangHai, '1111111111');

			},
			//깊은市
			async topTenshen() {
				let list = await this.$http.get('api/stock-api/BaseTop10Active', {
					exchange_kind: 3
				})
				this.deep = list.data.data
				// console.log(this.deep, '222222222');
			},

		},
		mounted() {
			this.topTenshang()
			this.topTenshen()
		},
	}
</script>

<style lang="scss">
	.college-bg {
		padding: 60rpx 30rpx 20rpx;
		height: 280rpx;
		background-color: #4f61f5;

		image {
			width: 20rpx;
			height: 40rpx;
		}

		.renovate {
			width: 40rpx;
		}

		.account {
			display: flex;
			justify-content: space-between;
			align-items: center;
		}

		.college-text {

			color: #fff;
			font-weight: 800;
			font-size: 36rpx;
		}

		.suo {
			background: hsla(0, 0%, 100%, .1);
			border-radius: 40rpx;
			padding: 10rpx 40rpx;
			margin: 40rpx 0 0;

			image {
				width: 40rpx;
				height: 40rpx;
				margin-top: 10rpx;
			}
		}
	}

	.lookOver {
		margin-top: -80rpx;
		border-radius: 30rpx 30rpx 0 0;
		background: #fff;
		display: flex;
		padding: 0rpx 0 20rpx;




		.tab-content {
			font-size: 32rpx;
			flex: 1;
			text-align: center;
			color: #666666;
			height: 100rpx;
			line-height: 100rpx;
			position: relative;
		}

		.content-selection {
			font-size: 32rpx;
			font-family: PingFang SC;
			font-weight: bold;
			color: #f85252;
		}

		.content-selection:after {
			content: '';
			position: absolute;
			bottom: -2rpx;
			top: auto;
			left: 42%;
			height: 6rpx;
			width: 44rpx;
			background-color: #f85252;
		}

	}

	.stockCode {
		border-top: 2rpx solid #e0e0e0;
		border-bottom: 2rpx solid #e0e0e0;
		display: flex;
		justify-content: space-between;
		padding: 20rpx 30rpx;
		align-items: center;
		// text-align: center;
		color: #999;
		font-size: 26rpx;

		view {
			width: 22%;
			text-align: end;
		}
	}

	.lookContent {
		margin: 20rpx 0rpx;

		.one {
			.a-row {
				border-bottom: 2rpx solid #e0e0e0;
				padding: 10rpx 50rpx 10rpx 30rpx;
				display: flex;
				justify-content: space-between;
				align-items: center;

				.share {
					text-align: left;

					h5 {
						margin: 10rpx 0;
					}
				}

				// view {
				// 	width: 22%;
				// 	text-align: end;
				// }

				.figure {
					font-size: 26rpx;
					color: #1a1a1a;
					width: 33%;
					text-align: right;
				}
			}
		}

		.two {
			.a-row {
				border-bottom: 2rpx solid #e0e0e0;
				padding: 10rpx 50rpx 10rpx 30rpx;
				display: flex;
				justify-content: space-between;
				align-items: center;

				.share {
					text-align: left;
				}

				h5 {
					margin: 10rpx 0;
				}

				// view {
				// 	width: 22%;
				// 	text-align: end;
				// }

				.figure {
					font-size: 26rpx;
					color: #1a1a1a;
					width: 33%;
					text-align: right;
				}
			}
		}
	}
</style>
