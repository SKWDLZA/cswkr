<!-- 주주들은 지분을 줄인다记录 -->
<template>
	<view style="background-color: #F3F4F8;height: 100vh;">
		<view class="college-bg" style="background-color: #FFFFFF;">
			<image src="/static/zuojiantou.png" mode="" @tap="home()"></image>
			<view class="college-text" style="color:#121212;">기관 거래 우선가</view>
			<view class=""></view>
		</view>
		<!-- <u-tabs lineColor="#fff" :list="chooseList" @change="select" :activeStyle="{color: '#2E67F6',fontWeight: 'bold',}"
			:inactiveStyle="{color: '#666'}"></u-tabs> -->

			<view class="nav-box" style="border:none;">
				<view class="nav-item" @click="select(0)" :style="{color:status==0?'#2E67F6':'#666666'}">종목 보유 현황
					<span style="display: block; width: 30px;height: 2px;"
						:style="{backgroundColor:status==0?'#2E67F6':''}"></span>
				</view>
				<!-- <view style="width: 1px;height: 20px;background-color: #E8EAF3;"></view> -->
				<view class="nav-item" @click="select(1)" :style="{color:status==1?'#2E67F6':'#666666'}">매매 내역
					<span style="display: block; width: 30px;height: 2px;"
						:style="{backgroundColor:status==1?'#2E67F6':''}"></span>
				</view>
				<!-- <view style="width: 1px;height: 20px;background-color: #E8EAF3;"></view>
				<view class="nav-item" @click="select(2)" :style="{color:status==2?'#2E67F6':'#666666'}">매매 내역
					<span style="display: block; width: 30px;height: 2px;"
						:style="{backgroundColor:status==2?'#2E67F6':''}"></span>
				</view> -->
			</view>
			
		<view class="" v-for="(item,index) in list" :key="index">
			<view style="margin: 30rpx; word-wrap:break-word;border-radius: 10px;box-shadow: rgba(0, 0, 0, 0.15) 0 0 1px;margin:20px;padding:10px;background-color: #FFFFFF;line-height: 1.6;">
				<view class="display">
					<view class="">
						<view class="did-not">
							{{item.goods_info.name}}
							<text>매수완료</text>
						</view>

					</view>
					<view class="did-not">
						매수가격 <text>{{item.price}}</text>
					</view>
				</view>
				<u-divider></u-divider>
				<view class="display quantity">
					<view class="display">
						<view class="">당첨수량</view>
						<view class="red-mark">{{item.order_buy.num}}</view>
					</view>
					<view class="display">
						<view class="">매수금액</view>
						<view class="red-mark">{{item.order_buy.amount}}</view>
					</view>
				</view>
				<view>
					<view class="display">
						<view class="">레버리지</view>
						<view class="" style="text-align: right;">X{{item.order_buy.double}}</view>
					</view>
				</view>
				<view>
					<view class="display">
						<view class="">상태</view>
						<view v-if="item.status == 1" style="text-align: right;color: blue;">위치</view>
						<view v-if="item.status == 2" style="text-align: right;color: darkred;">포지션닫기</view>
					</view>
				</view>
				<view class="display">
					<view class="">매수시간</view>
					<view class="" style="text-align: right;">{{item.created_at}}</view>
				</view>

			</view>
			<view style="height: 4rpx;width: 100%;background: #f5f5f5;"></view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				list: [],
				status: 0,
			};
		},
		onLoad(option) {
			this.shengou()
		},
		methods: {
			home() {
				uni.navigateBack({
					delta: 1, //返回层数，2则上上页
				});
			},
			select(val) {
				console.log(val)
				this.status = val;
				this.list = [];
				this.shengou();
			},
			async shengou(e) {
				let list = await this.$http.post('api/goods-bigbill/user-order-list',{status:this.status})
				this.list = list.data.data

				console.log(list.data.data)
			},

		},
		
	}
</script>

<style lang="scss">
	.nav-box {
		margin-bottom: 16px;
		height: 51px;
		border-bottom: 1px solid #e5e8f6;
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
		-webkit-box-align: center;
		-webkit-align-items: center;
		align-items: center;
		-webkit-box-pack: center;
		-webkit-justify-content: center;
		justify-content: center;
	
	
		.nav-item {
			height: 51px;
			width: 50%;
			display: -webkit-box;
			display: -webkit-flex;
			display: flex;
			-webkit-box-orient: vertical;
			-webkit-box-direction: normal;
			-webkit-flex-direction: column;
			flex-direction: column;
			-webkit-box-align: center;
			-webkit-align-items: center;
			align-items: center;
			-webkit-box-pack: end;
			-webkit-justify-content: flex-end;
			justify-content: flex-end;
			font-size: 17px;
			color: #333;
	
			span {
				width: 100%;
				height: 3px;
				background: transparent;
				margin-top: 10px;
				display: block;
			}
		}
	
		.active {
			font-size: 17px;
			font-weight: 700;
			color: #2E67F6;
	
			span {
				background: #2E67F6;
			}
		}
	
	}
	//公共css 开始
	.display {
		display: flex;
		justify-content: space-between;
		align-items: center;
	}

	//깊은북쪽상하이
	.area {
		display: flex;
		justify-content: flex-start;
		align-items: center;
	}

	//깊은
	.deep {
		width: 30rpx;
		height: 30rpx;
		background: #f85252;
		border-radius: 0.4rpx;
		text-align: center;
		line-height: 30rpx;
		color: #fff;
		font-size: 24rpx;
		display: inline-block;
	}

	.deep-number {
		display: inline-block;
		padding: 0 0.04rem;
		background: rgba(59, 79, 222, .1);
		border-radius: 10rpx;
		color: #f85252;
		font-size: 24rpx;
		vertical-align: middle;
	}

	//북쪽
	.north {
		width: 30rpx;
		height: 30rpx;
		background: #ea6248;
		border-radius: 0.4rpx;
		text-align: center;
		line-height: 30rpx;
		color: #fff;
		font-size: 24rpx;
		display: inline-block;
	}

	.north-number {
		display: inline-block;
		padding: 0 0.04rem;
		border-radius: 10rpx;
		font-size: 24rpx;
		vertical-align: middle;
		color: #ea6248;
		background: rgba(234, 98, 72, .1);
	}

	//상하이
	.shanghai {
		width: 30rpx;
		height: 30rpx;
		background: #aa3bde;
		border-radius: 0.4rpx;
		text-align: center;
		line-height: 30rpx;
		color: #fff;
		font-size: 24rpx;
		display: inline-block;
	}

	.shanghai-number {
		display: inline-block;
		padding: 0 0.04rem;
		border-radius: 10rpx;
		font-size: 24rpx;
		vertical-align: middle;
		color: #aa3bde;
		background: rgba(170, 59, 222, .1);
	}

	//公共css 结束

	.college-bg {
		padding: 20rpx;
		height: 80rpx;
		background-color: #014b8d;
		display: flex;
		justify-content: space-between;
		align-items: center;
		text-align: center;

		image {
			width: 20rpx;
			height: 40rpx;
		}

		.college-text {

			color: #fff;
			font-weight: 800;
			font-size: 36rpx;
		}

	}

	.did-not {
		margin-bottom: 10rpx;

		text {
			color: #ea3544;
			font-size: 28rpx;
			margin-left: 10rpx;
		}
	}

	.quantity {
		font-size: 24rpx;

		.display {
			width: 48%;
			margin: 10rpx 0;
		}

		.red-mark {
			color: #f85252;
		}
	}
</style>