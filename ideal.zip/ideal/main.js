import App from './App'
import LANGUAGE from '@/common/lang/kr.js';
// import LANGUAGE from '@/common/lang/zh.js';
import UTIL from './common/util.js';
// #ifndef VUE3
import Vue from 'vue'
import VueI18n from 'vue-i18n'

import uView from "uview-ui";
Vue.use(uView);

import 'utils/icon.css';

Vue.use(VueI18n)

Vue.config.productionTip = false

import BaseUrl from '@/common/api.js'
Vue.prototype.$BaseUrl = BaseUrl.BaseUrl

// 设置语言环境为中文
const i18n = new VueI18n({
	locale: 'zh-Hans', // 默认语言为中文
})

App.mpType = 'app'
const app = new Vue({
	i18n, // 将i18n实例注入到Vue实例中
	...App
})
app.$mount()
// #endif

// 引入封装的请求
import request from '@/common/api.js';
Vue.prototype.$http = request;

import md5 from 'js-md5';
Vue.prototype.$md5 = md5;


Vue.prototype.$requests = "https://www.baidu.com/"
Vue.prototype.$lang = LANGUAGE;
Vue.prototype.$util = UTIL;

// #ifdef VUE3
import {
	createSSRApp
} from 'vue'
export function createApp() {
	const app = createSSRApp(App)
	return {
		app
	}
}
// #endif

// 白名单
const whiteList = [UTIL.PAGE_URL.ACCOUNT_SIGNIN, UTIL.PAGE_URL.ACCOUNT_FIND_PASSWORD, UTIL.PAGE_URL.SERVICE];
// uniapp 跳转行为
const list = ["navigateTo", "reLaunch", "switchTab"]
// 目标url是否需要权限
function hasPermission(url) {
	// 在白名单中或有token，直接跳转
	if (whiteList.indexOf(url) !== -1 || uni.getStorageSync("token")) {
		return true;
	}
	return false;
}

list.forEach((item) => {
	// 路由拦截
	uni.addInterceptor(item, {
		// 页面跳转前进行拦截, invoke根据返回值进行判断是否继续执行跳转
		invoke(e) {
			if (!hasPermission(e.url)) {
				// 将用户的目标路径保存下来 这样可以实现 用户登录之后，直接跳转到目标页面
				// uni.setStorageSync("URL", e.url)
				uni.navigateTo({
					url: UTIL.PAGE_URL.ACCOUNT_SIGNIN,
				});
				return false;
			}
			return true;
		}
	});
})