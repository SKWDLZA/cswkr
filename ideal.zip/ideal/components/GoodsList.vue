<template>
	<view style="padding:0 10px 6px 10px;">
		<EmptyData v-if="list && list.length<=0"></EmptyData>
		<block v-for="(item,index) in list" :key="index">
			<view @click="handleDetail(item.code)" class="line"
				style="padding: 6px 0;margin:0 10px;display: flex;align-items: center;">
				<view style="display: inline-block;flex:10%;">
					<template v-if="!item.logo || item.logo==''">
						<view :style="$util.calcImageSize(30)" style="background-color:#2d2c62;text-align: center;line-height: 30px;color: #FFFFFF;margin-bottom: 4px;border-radius: 100%;">{{item.ko_name.slice(0,1)}}</view>
					</template>
					<template v-else>
						<image mode="aspectFit" :src="item.logo" :style="$util.calcImageSize(30)" style="border-radius: 100%;"></image>
					</template>	
				</view>
				<view style="display: inline-block;flex:30%;padding-left: 6px;" :style="{color:$util.THEME.TEXT}">
					<view>{{item.ko_name}}</view>
					<view style="color:#626262;">{{item.code}}</view>
				</view>
				<view style="display: inline-block;flex:30%;text-align: right;">
					<view style="padding:4px;font-weight: 700;font-size: 16px;" :style="$util.calcStyleRiseFall(item.returns>0)">
						{{$util.formatNumber(item.volume_returns*1)}}
					</view>
					<!-- <view style="padding:4px;font-weight: 700;" :style="$util.calcStyleRiseFall(item.returns>0)">
						{{$util.formatNumber(item.volume_valued_returns)}}
					</view> -->
				</view>
				<view style="display: inline-block;flex:20%;text-align: right;font-weight: 700;">
					<text style="display: inline-block;text-align: right;padding:4px;"
						:style="$util.calcStyleRiseFall(item.returns>0)">{{$util.formatNumber(item.close*1)}}
					</text>
					<view style="display: inline-block;padding:4px;"
						:style="$util.calcStyleRiseFall(item.returns>0,true)">
						{{item.returns>0?'+':""}}{{(1*item.returns).toFixed(2)}}%
					</view>
				</view>
			</view>
		</block>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: "GoodsList",
		components: {
			EmptyData,
		},
		data() {
			return {
				list: [],
			};
		},
		mounted() {
			this.getList();
		},
		methods: {
			handleDetail(code) {
				uni.navigateTo({
					url: `${this.$util.PAGE_URL.STOCK_OVERVIEW}?code=${code}`,
				})
			},
			async getList() {
				// if (this.list.length <= 0) {
				// 	uni.showLoading({
				// 		title: this.$lang.LOADING,
				// 	})
				// }
				const result = await this.$http.get(this.$http.API_URL.GOODS_LIST, {
					page: 1,
					gp_index: 0
				})
				if (result.data.code == 0) {
					this.list = result.data.data;
				} else {
					uni.$u.toast(result.data.message);
				}
			},
		}
	}
</script>