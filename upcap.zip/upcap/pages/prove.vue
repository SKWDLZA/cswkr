<!-- 实时传输 -->
<template>
	<view >
		<CustomHeader title="인증서에서 은행으로 이체" @action="handleBack()"></CustomHeader>

		<view
			style="padding: 10px;margin:20px 10px;background-color: #fff;border-radius: 10px;box-shadow: rgba(0, 0, 0, 0.15) 1.95px 1.95px 2.6px;">

			<view class="text-center font-size-20">
				인출 가능한 자금
			</view>
			<view class="text-center bold margin-top-10 font-size-24">
				<!-- {{tixian_money()}}원 -->
				<!-- {{$util.formatNumber(userInformation.money - userInformation.freezeMoney)}}원 -->
				{{$util.formatNumber(userInformation.money)}}원
			</view>
			<!-- <view class="text-center">
				자금 동결 {{userInformation.freezeMoney}}
			</view> -->
			<view style="color: #181945;width: 50%;margin-left: 25%;"
				class="radius10 color-white text-center margin-top-10">
				현재이체가능한잔액
			</view>

			<view class="margin-top-20 hui2">
				<view>출금금액</view>
				<view class="margin-top-10">
					<u--input placeholder="출금 금액 입력" border="surround" v-model="value1" shape="circle"
						customStyle="background-color:#f5f5f5" placeholderStyle="color:#8c8c8c">
						<template slot="suffix">
							<!-- 暂时不改 -->
							<view @click="whole(tixian_money1())">전액</view>
							
							<!-- <view @click="whole(userInformation.money)">전액</view> -->
						</template>
					</u--input>
				</view>
			</view>

			<view class="margin-top-20 hui2">
				<view>증권 비밀번호</view>
				<view class="margin-top-10">
					<u--input placeholder="비밀번호 6자리 입력" border="surround" v-model="value2" shape="circle"
						customStyle="background-color:#f5f5f5" placeholderStyle="color:#8c8c8c"></u--input>
				</view>
			</view>
			<view class="margin-top-30 text-center radius10 padding-10 color-white" style="background-color: #4b5fcc;"
				@click="to_withdraw()">
				출금확인
			</view>

			<view class="guize">
				<view>1. 매도 대금은 2거래일을 기다려야만 인출할 수 있어요.</view>
				<view>2. 출금을 위해서는 실명인증 및 본인 계좌 확인 후 출금 진행이 됩니다.</view>
				<view>3. 출금 거래 가능 시간 : 평일 오전 09시 ~ 오후 15시30분 (*주말, 대체공휴일 출금 불가)</view>
				<view>4. 각 현금 인출의 최소 금액은 10,000단위 입니다.</view>
				<view style="color:#ff3636"> 5.출금 신청 후, 당일 입금을 원칙으로 하며, 2시간 이내 입금이 완료 됩니다. </view>
			</view>
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components: {
			CustomHeader,
		},
		data() {
			return {
				value1: '',
				value2: '',
				value3: "",
				userInformation: ''
			};
		},
		methods: {
			tixian_money(){
				let money=this.userInformation.money - this.userInformation.freezeMoney;
				return money<0?0:this.$util.formatNumber(money)
			},
			tixian_money1(){
				let money=this.userInformation.money - this.userInformation.freezeMoney;
				return money<0?0:money
			},
			handleBack() {
				uni.navigateBack({
					delta: 1, //返回层数，2则上上页
				});
			},
			async to_withdraw() {
				uni.showLoading({
					title: "출금중이니 기다려주세요....",
					mask: true, // 显示透明蒙层，防止触摸穿透
				});
				let list = await this.$http.post('api/app/withdraw', {
					type: 1,
					total: this.value1,
					pay_pass: this.value2,
					remakes: this.value3,
				})
				// console.log(list.data.code, 'code');
				if (list.data.code == 0) {

					uni.$u.toast(list.data.message);
					setTimeout(() => {
						uni.switchTab({
							url: '/pages/user/user'
						});
						uni.hideLoading();
					}, 500)
				} else {
					uni.$u.toast(list.data.message);
				}
			},
			home() {
				uni.switchTab({
					url: '/pages/user/user'
				});
			},
			whole(money) {
				this.value1 = money
				// console.log(this.value1, '123');
			},
			//用户信息
			async gaint_info() {
				let list = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				})
				this.userInformation = list.data.data
			},


		},
		onShow() {
			this.gaint_info()
		},
		onLoad(option) {

		}
	}
</script>

<style lang="scss">
	page {
		background-color: #F3F4F8;
	}

	.home {
		background-image: url(/static/chuanggai/home-top.png);
		/* 背景图片覆盖整个容器，可能会裁剪 */
		background-size: cover;
		/* 让背景图片始终位于容器的中心 */
		background-position: center;
		/* 不重复背景图片 */
		background-repeat: no-repeat;
		height: 600rpx;
		margin-left: -10px;

	}

	.guize {
		margin-top: 10px;

		view {
			padding-top: 2px;
			font-size: 12px;

			text {
				color: #ff3636;
			}
		}
	}
</style>