<!-- 股市新闻 -->
<template>
	<view style="padding:0 10px;">
		<view v-for="(item,index) in list" :key="index" @click="open(item.link)"
			style="display: flex;align-items: center;">
			<view style="flex:20%;">
				<image mode="aspectFit" :src="item.image" :style="$util.calcImageSize(80)"></image>
			</view>
			<view style="padding-left: 10px;flex:80%;">
				<view :style="{color:$util.THEME.TEXT}">{{item.title}}</view>
				<view :style="{color:$util.THEME.LABEL}" style="text-align: right;padding-right: 16px;">
					{{$util.formatDate(item.dt)}}</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		name: "StockMarketNews",
		props: ['params'],
		data() {
			return {
				list: []
			};
		},
		created() {
			this.getList()
		},
		methods: {
			open(url) {
				window.open(url)
			},
			async getList() {
				const result = await this.$http.post(this.$http.API_URL.PRODUCT_NEWS, {
					code: this.params.code,
					stock_id: this.params.id
				})
				this.list = result.data.data[0];
			},
		},
	}
</script>