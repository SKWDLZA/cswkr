<!-- 绑定银行卡 -->
<template>
	<view >
		<CustomHeader :title="$t('index.yhkbb')" @action="handleBack()"></CustomHeader>

		<view class="common_block">
			<view class="bank-name">
				<view class="">{{$t('index.name')}}:</view> <text> {{cardManagement.realname}}</text>
			</view>
			<view class="bank-name">
				<view class="">{{$t('index.yhm')}}: </view><text> {{cardManagement.bank_name}}</text>
			</view>
			<view class="bank-name">
				<view class="">{{$t('index.kahao')}}: </view> <text> {{cardManagement.card_sn}}</text>
			</view>

			<view @tap='handleChangeCard()' style="background-color:#4b5fcc;
		margin: 50rpx 30rpx;
		border-radius: 10rpx;
		padding: 20rpx 0;
		text-align: center;
		color: #fff;
		font-size: 28rpx;">
				{{$t('index.djcxbd')}}
			</view>
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components: {
			CustomHeader
		},
		data() {
			return {
				cardManagement: {},
			};
		},
		onLoad() {
			this.gaint_info()
		},
		methods: {
			handleBack() {
				uni.switchTab({
					url: '/pages/user/user'
				});
			},
			handleChangeCard() {
				uni.navigateTo({
					url: '/pages/changeCard/changeCard'
				});
			},
			//用户信息
			async gaint_info() {
				let list = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				})
				this.cardManagement = list.data.data.bank_card_info
			},
		},

	}
</script>

<style lang="scss">
	.bank-name {
		padding: 30rpx 20rpx;
		background-color: #f5f5f5;
		display: flex;
		font-size: 28rpx;
		margin-top: 10px;
		border: 2rpx solid #f4f4f4;
		border-radius: 10px;

		view {
			width: 30%;
		}

		text {
			margin-left: 60rpx;
			font-weight: 400;
			font-size: 28rpx;
		}
	}
</style>