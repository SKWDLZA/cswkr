<template>
	<!-- vip -->
	<view>
		<view class="white-background">

			<!-- 	<view class="take-notes">
				<view class="" style="text-align: center;margin: 60rpx 0; font-size: 28rpx;padding-bottom: 60rpx;">
					如需此项服务请联系您的客户经理
				</view>
			</view> -->



			<view class="take-notes">
				<view class="name">고객명</view>
				<view class="up-down">
					<view class="price">우대 가격</view>
					<view class="downRange">변경 사항</view>
				</view>
				<view class="" style="width: 20%;"></view>
			</view>
		</view>
		<view class="science" v-for="(item,index) in funding" :key="index">
			<view class="display" style="margin: 20rpx 0;">
				<view class="">
					<view class="corporation">{{item.goods.name}}</view>
					<view class="area" v-if="item.goods.locate=='깊은'">
						<view class="deep">{{item.goods.locate}}</view>
						<view class="deep-number">{{item.goods.code}}</view>
					</view>
					<view class="area" v-if="item.goods.locate=='북쪽'">
						<view class="north">{{item.goods.locate}}</view>
						<view class="north-number">{{item.goods.code}}</view>
					</view>
					<view class="area" v-if="item.goods.locate=='상하이'">
						<view class="shanghai">{{item.goods.locate}}</view>
						<view class="shanghai-number">{{item.goods.code}}</view>
					</view>
				</view>
				<view class="price">
					{{item.goods.current_price}}
				</view>
				<view class="price">
					{{item.goods.rate}}%

				</view>
				<view class="detailed" @tap="goBuy(item)">
					구입하다
				</view>
			</view>
		</view>



	</view>
</template>

<script>
	export default {
		data() {
			return {
				funding: ''
			}
		},
		methods: {
			//去到购买
			goBuy(item) {
				uni.navigateTo({
					url: '/pages/index/components/newShares/placeOrder/placeOrder' +
						`?item=${encodeURIComponent(JSON.stringify(item))}`

				});
				// console.log(item, '=========抛出去');
			},
			//列表
			async scramble(item) {
				let list = await this.$http.get('api/goods/goodsvipscramble', {
					page: 1,
					limit: 500,
				})
				this.funding = list.data.data
			},
		},
		mounted() {
			this.scramble()
		},
	}
</script>

<style lang="scss">
	.white-background {
		background: #fff;
		margin-top: -50rpx;
		border-radius: 20rpx 20rpx 0 0;

		.take-notes {
			display: flex;
			justify-content: center;
			align-items: center;
			padding: 30rpx 30rpx 30rpx;
			border-bottom: 1rpx solid #e0e0e0;
			font-size: 28rpx;

			.up-down {
				width: 40%;
				display: flex;
				justify-content: space-between;
				align-items: center;
			}

			.name {
				width: 30%;
			}

			.price {
				width: 100%;
			}

			.downRange {
				width: 100%;
			}

		}

	}

	.science {
		margin: 30rpx;
		padding-bottom: 30rpx;
		border-bottom: 0.037037rem solid #e0e0e0;

		.corporation {
			font-size: 30rpx;
			font-weight: 600;
			color: #333;

		}

		.price {
			color: #f85252;
			font-size: 26rpx;
		}

		.detailed {
			background-image: linear-gradient(to right, #1a73e8, #01B4D5);
			color: #fff;
			border-radius: 40rpx;
			padding: 6rpx 40rpx;
			font-size: 26rpx
		}

		.find {
			width: 45%;

			view:nth-child(2) {
				color: #f85252;
			}
		}

		.ration {
			width: 45%;

			view:nth-child(2) {
				color: #f85252;
			}
		}
	}
</style>