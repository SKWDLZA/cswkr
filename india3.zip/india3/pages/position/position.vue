<template>
	<view class="page">
		<view class="header flex flex-b" @click="$u.route({type:'navigateBack'});">
			<!-- <img class="header-left icon jiantou"> -->
			<view class="header-center flex-1">Details</view>
			<view class="header-right"></view><!---->
		</view>
		<view class="dabokl">
			<view class="available-balance">
				<view class="">
					<view class="available">Orderable amount</view>
					<view class="balance"> ₹ {{userInformation.money .toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</view>
				</view>
				<view class="change"
					@click="silver(userInformation.money,userInformation.bank_card_info,userInformation.idno)">Deposit</view>
			</view>

			<view class="funding-situation">
				<view class="situation">
					<view class="">Total investment</view>
					<view class=""> ₹ {{userInformation.frozen.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</view>
				</view>
				<view class="xian"></view>
				<view class="situation">
					<view class="">Total P&l</view>
					<view :class="userInformation.holdYingli < 0 ? 'red' : (userInformation.holdYingli > 0 ? 'green' : 'quantity')"> ₹ {{userInformation.holdYingli.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</view>
				</view>
				<!-- 				<view class="xian"></view>
				<view class="situation">
					<view class="">冻结资金</view>
					<view class="">{{userInformation.frozen}}</view>
				</view> -->
			</view>

			<view class="sert">
				<view class="inv-h-w">
					<block v-for="(item,index) in items" :key="index">
						<view :class="['inv-h',Inv== index?'inv-h-se':'']" @click="qiehuan(index)">{{item}}</view>
					</block>
				</view>
				<u-divider></u-divider>
				<view v-show="Inv == 0" class="up-and-down-range">
					<view class="" style="border-bottom: 1px solid #e9e9e9;padding: 30rpx 0 ;"
						v-for="(item,index) in storehouse" :key="index">
						<view class="display" style="margin:0 30rpx ;">
							<view class="share-certificate" @tap="productDetails(item.goods_info)">
								<h6>{{item.goods_info.name}}</h6>
								
							</view>

							<view class="position" @click="position(item.id)">
								Sell all quantity
							</view>
							<!-- 	<view class="position" @click="closingFunction(item)">
								平仓
							</view> -->
						</view>

						<view class="" @tap="productDetails(item.goods_info)">
							<view class="display" style="margin: 30rpx 30rpx 20rpx;font-size: 26rpx;">
								<view :class="item.order_buy.float_yingkui>0?'green':'up-date'">LTP:<text>{{item.goods_info.current_price}}</text></view>
								<!-- <view class="buy-up" v-if="item.direct=1">买涨↑</view> -->
								<view class="time">Time:{{item.order_buy.created_at}}</view>
							</view>
							<view class="shadow">
								<!-- :class="item.order_buy.float_yingkui>0?'green':'up-date'"> -->
								<view class="display">
									<view class="">Current value:</view>
									<view :class="item.order_buy.float_yingkui>0?'green':'quantity'">{{item.order_buy.float_yingkui.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</view>
								</view>
								<view class="display">
									<view class="">P&L:</view>
									<view :class="item.order_buy.float_yingkui>0?'green':'quantity'">{{(item.order_buy.yingkui/item.order_buy.price*100/item.order_buy.num).toFixed(2)}}%</view>
								</view>
							</view>
							<view class="shadows">
								<view class="display">
									<view class="">Price:</view>
									<view :class="item.order_buy.float_yingkui>0?'green':'quantity'">{{item.order_buy.price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</view>
								</view>
								<view class="display">
									<view class="">Net Qty:</view>
									<view :class="item.order_buy.float_yingkui>0?'green':'quantity'">{{item.order_buy.num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</view>
								</view>
							</view>
							<view class="shadows">
								<view class="display">
									<view class="">Fee:</view>
									<view :class="item.order_buy.float_yingkui>0?'green':'quantity'">{{item.order_buy.buy_fee.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</view>
								</view>
								<view class="display">
									<view class="">Buy value:</view>
									<view :class="item.order_buy.float_yingkui>0?'green':'quantity'">{{item.order_buy.amount.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</view>
								</view>
							</view>
						</view>
					</view>

					<view class="finished-text">
						No more
					</view>
				</view>
			</view>
			<!-- 弹窗 -->
			<u-modal :show="show" :title="title" @cancel="cancel" @confirm="confirm(confirmation)"
				:showCancelButton='showCancelButton' :content='content' cancel-text="cancel" confirm-text="check">
			</u-modal>


			<view class="transaction" v-show="Inv == 1">
				<view class="" v-if="updata" style="border-bottom: 1px solid #e9e9e9;padding: 30rpx 0 ;"
					v-for="(item,index) in storehouses" :key="index" @tap="productDetails(item.goods_info)">
					<view class="display" style="margin:0 30rpx ;">
						<view class="share-certificate">
							<h6>{{item.goods_info.name}}</h6>
							
						</view>
					</view>

					<view class="display" style="margin: 30rpx 30rpx 20rpx;font-size: 26rpx;">
						<view class="up-date">Date：{{item.order_sell.created_at}} </view>
						<!-- <view class="buy-up">买涨↑</view> -->
						<!-- <view class="time"></view> -->
					</view>
					<view class="shadow">
						<view class="display">
							<view class="">Total selling price:</view>
							<view :class="item.order_sell.float_yingkui>0?'green':'quantity'" style="margin-left: 25px;">{{item.order_sell.amount.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</view>
						</view>
						<view class="display">
							<view class="">P&L:</view>
							<view :class="item.order_sell.float_yingkui>0?'green':'quantity'">{{item.order_sell.yingkui.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</view>
						</view>
					</view>
					<view class="shadows">
						<view class="display">
							<view class="">Selling price:</view>
							<view :class="item.order_sell.float_yingkui>0?'green':'quantity'">{{item.order_sell.price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</view>
						</view>
						<view class="display">
							<view class="">Quantity:</view>
							<view :class="item.order_sell.float_yingkui>0?'green':'quantity'">{{item.order_sell.num.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</view>
						</view>
					</view>
					<view class="shadows">
						<!-- <view class="display">
							<view class="">마감 수수료:</view>
							<view class="quantity">{{item.order_sell.sell_fee.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</view>
						</view> -->
						<view class="display">
							<view class="">Fee:</view>
							<view :class="item.order_sell.float_yingkui>0?'green':'quantity'">{{item.order_buy.buy_fee .toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</view>
						</view>
					</view>
					<!-- <view class="shadows">
						<view class="display">
							<view class="">세금:</view>
							<view class="quantity">{{item.order_sell.yinghua_fee.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</view>
						</view>
						<view class="display">
							<view class="">구매 수수료:</view>
							<view class="quantity">{{item.order_buy.buy_fee.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</view>
						</view>
					</view> -->

				</view>
				<view class="finished-text">
					There is no list
				</view>
			</view>


			<view class="transaction" v-show="Inv == 2">
				<view class="" style="border-bottom: 1px solid #e9e9e9;padding: 30rpx 0 ;"
					v-for="(item,index) in luckyNumber" :key="index">
					<view class="display" style="margin:0 30rpx ;">
						<view class="share-certificate" @tap="productDetails(item.goods_info)">
							<h6>{{item.goods_info.name}}</h6>
							
						</view>

						<view class="position" @click="position(item.id)">
							Position closed
						</view>
						<!-- 	<view class="position" @click="closingFunction(item)">
						平仓
					</view> -->
					</view>

					<view class="" @tap="productDetails(item.goods_info)">
						<view class="display" style="margin: 30rpx 30rpx 20rpx;font-size: 26rpx;">
							<view class="up-date">LTP:<text>{{item.goods_info.current_price}}</text></view>
							<!-- <view class="buy-up" v-if="item.direct=1">买涨↑</view> -->
							<view class="time">Time:{{item.order_buy.created_at}}</view>
						</view>
						<view class="shadow">
							<view class="display">
								<view class="">Current value:</view>
								<view class="quantity">{{item.order_buy.float_yingkui}}</view>
							</view>
							<view class="display">
								<view class="">Total profit and loss:</view>
								<view class="quantity">{{item.order_buy.yingkui}}</view>
							</view>
						</view>
						<view class="shadows">
							<view class="display">
								<view class="">Price:</view>
								<view class="quantity">{{item.order_buy.price .toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</view>
							</view>
							<view class="display">
								<view class="">Net Qty:</view>
								<view class="quantity">{{item.order_buy.num.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</view>
							</view>
						</view>
						<view class="shadows">
							<view class="display">
								<view class="">Fee:</view>
								<view class="quantity">{{item.order_buy.buy_fee .toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</view>
							</view>
							<view class="display">
								<view class="">Buy value:</view>
								<view class="quantity">{{item.order_buy.amount .toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</view>
							</view>
						</view>
					</view>
				</view>

				<view class="finished-text">
					There is no list
				</view>
			</view>
			<view class="transaction" v-show="Inv == 3">

				<view class="" v-if="updata" style="border-bottom: 1px solid #e9e9e9;padding: 30rpx 0 ;"
					v-for="(item,index) in subscribe" :key="index" @tap="productDetails(item.goods_info)">
					<view class="display" style="margin:0 30rpx ;">
						<view class="share-certificate">
							<h6>{{item.goods.name}}</h6>
						</view>
					</view>

					<view class="display" style="margin: 30rpx 30rpx 20rpx;font-size: 26rpx;">
						<view class="up-date">Price：{{item.price}} </view>
						<!-- <view class="buy-up">买涨↑</view> -->
						<!-- <view class="time"></view> -->
					</view>
					<view class="shadow">
						<view class="display">
							<view class="">Subscribe:</view>
							<view class="quantity">{{item.apply_amount}}</view>
						</view>
						<view class="display">
							<view class="">Amount:</view>
							<view class="quantity">{{item.apply_num_amount}}</view>
						</view>
					</view>
					<view class="shadows">
						<view class="shadows-dis">
							<view class="">Time:</view>
							<view class="quantity">{{item.created_at}}</view>
						</view>
						<view class="shadows-dis">
							<view class="">Order No.:</view>
							<view class="quantity">{{item.order_sn}}</view>
						</view>
					</view>

				</view>
				<view class="finished-text">
					There is no list
				</view>
			</view>
		</view>
		<!--更新-弹窗 -->
		<!-- <lerugeupdate ref="update" :downloadUrl="update.url" :updateDesc="update.title" :force="true" /> -->
	</view>
</template>

<script>
	// import lerugeupdate from "@/components/leruge-update.vue"
	export default {
		components: {
			// lerugeupdate
		},
		data() {
			return {
				// //是否更新
				// updateFlag: false,
				// //每次版本更新都要修改
				// version: '2.1',
				// popupshow: true,
				downloadUrl: '',
				updateDesc: "",
				update: '',
				// closeOnClickOverlay: false,
				Inv: 0,
				items: ['Holding', 'Closed', 'Subscribe'],
				show: false,
				title: 'Caution',
				content: 'Do you really want to sell all quantity?',
				showCancelButton: true,
				storehouse: '',
				storehouses: '',
				subscribe: '',
				luckyNumber: '',
				userInformation: '',
				updata: true,
				timerId: null,
				page:1

			}
		},
		// watch: {
		// 	Inv: 'position'
		// },
		//下拉刷新
		onPullDownRefresh() {
			this.page=1
			uni.showLoading({
				title: 'Loading',
			});
			//关闭加载提示
			setTimeout(() => {
				uni.hideLoading();
			}, 1000);
			this.shuaxin()
			uni.stopPullDownRefresh()
		},
		onReachBottom() {
			this.page=this.page+1;
			this.shuaxin()
		},

		methods: {
			qiehuan(index){
				this.Inv=index;
				this.page=1;
				this.shuaxin()
			},
			shuaxin(){
				uni.showLoading({
					title: 'Loading',
				});
				console.log(111,this.Inv);
				if(this.Inv==0){
					this.hold()
				}else if(this.Inv==1){
					this.flat()
				}else{
					this.holdings()
				}
			},
			// 平仓
			position(id) {
				this.show = true;
				this.confirmation = id


			},
			//点击取消
			cancel() {
				this.show = false;
			},
			// 点击确认
			confirm(confirmation) {
				// this.show = false;
				// console.log(confirmation, '点击确定');
				this.closingFunction(confirmation)
				this.show = false;
			},
			//产品세부
			productDetails(info) {
				var type=info.project_type_id
				
				if(!info.project_type_id){
					type=1
				}
				
				if(type==1){
					var gid=info.code
				}else{
					var gid=info.code
				}
				
				uni.navigateTo({
					url: '/pages/marketQuotations/productDetails' +
						`?code=${gid}&type=${type}`
				});
			},

			//点击下标
			subscript() {
				this.Inv == items.index
				this.page=1
				// console.log(this.Inv, '下标');
			},
			//搜索
			searchFor() {
				uni.navigateTo({
					url: '/pages/searchFor/searchFor'
				});
			},
			// 银转证
			silver(money, bank_card_info, idno) {
				if (bank_card_info && idno !== null) {
					uni.navigateTo({
						//保留当前页面，跳转到应用内的某个页面
						url: '/pages/my/components/certificateBank/silver' + `?money=${money}`
					});
				} else if (bank_card_info == null) {
					uni.$u.toast('Not tied to a bank card');
					setTimeout(() => {
						uni.navigateTo({
							//保留当前页面，跳转到应用内的某个页面
							url: '/pages/my/components/bankCard/renewal'
						});
					}, 2000)
				} else if (idno == null) {
					uni.$u.toast('Real name authentication not possible');
					setTimeout(() => {
						uni.navigateTo({
							//保留当前页面，跳转到应用内的某个页面
							url: '/pages/index/components/openAccount/openAccount'
						});
					}, 2000)
				}

			},
			//用户信息
			async gaint_info() {
				let list = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				})
				this.userInformation = list.data.data
			},
			// 新股持仓
			async holdings() {
				uni.hideLoading()
				let list = await this.$http.get('api/user/sg-order', {
				})
				this.luckyNumber = list.data.data

			},

			// 구독기록
			async shengou(e) {
				let list = await this.$http.get('api/goods-shengou/user-all-apply-log', {

				})
				this.subscribe = list.data.data
				console.log(this.subscribe, '1111111111')
				// console.log(list.data.data)
			},



			// 持仓
			async hold() {
				let list = await this.$http.get('api/user/order', {
					// language: this.$i18n.locale
					status: 1,
					page:this.page
				})
				console.log(list.data.data.data);
				console.log(this.page);
				uni.hideLoading()
				if(this.page==1){
					this.storehouse = list.data.data.data
				}else{
					this.storehouse.push(...list.data.data.data)
				}
				// console.log(list.data.data, '持仓');

			},
			//平仓
			async flat() {
				
				let list = await this.$http.get('api/user/order', {
					// language: this.,$i18n.locale
					status: 2,
					page:this.page
				})
				uni.hideLoading()
				if(this.page==1){
					this.storehouses = list.data.data.data
				}else{
					this.storehouses.push(...list.data.data.data)
				}
				// console.log(list.data.data, '持仓');
				// setTimeout(() => {
				// 	this.marketQuotations()
				// }, 10000)
			},
			// 平仓功能
			async closingFunction(confirmation) {
				uni.showLoading({
					title: "The position is being closed. Please wait a moment....",
					mask: true, // 显示透明蒙层，防止触摸穿透
				});
				let list = await this.$http.post('api/user/sell', {
					id: confirmation,
					// price: item.price
				})
				// console.log(item.id, '平仓功能');
				if (list.data.code == 0) {
					this.page=1
					this.shuaxin()
					uni.$u.toast(list.data.message);
					// this.$router.go(0)
					uni.hideLoading();

				} else {
					uni.$u.toast(list.data.message);
					uni.hideLoading();
				}

			},
			//版本更新
			is_token() {
				let token = uni.getStorageSync('token') || '';
			},
			async versionUpdate() {
				let list = await this.$http.get('api/version/detail', {})
				this.update = list.data.data
				let version = list.data.data.version
				let old_version = uni.getStorageSync('version') || 1.0
				// console.log(old_version, '当前版本111111111111111');
				if (old_version < version) {
					this.updateFlag = true
					this.$refs.update.upgrade()
					uni.setStorageSync('version', version)
				}
				// console.log(list.data.data, '版本更新');
			},
			//定时器
			startTimer() {
				const storedTimerId = uni.getStorageSync('timerId');
				if (storedTimerId) {
					clearInterval(storedTimerId);
				}
				this.timerId = setInterval(() => {
					console.log('Location request');
					this.shuaxin()
				}, 8000);
				uni.setStorageSync('timerId', this.timerId);
				// 在这里立即执行一次请求
				
			},
		},
		
		onShow() {
			this.is_token()
			this.gaint_info()
			this.shuaxin()
			// this.startTimer()
		},
		onLoad() {
		},
		onUnload() {
			console.log('Position closed1');
			clearInterval(this.timerId);
		},
		onHide() {
			console.log('Position closed2');
			clearInterval(this.timerId);
		},

	}
</script>

<style lang="scss">
	.page {
	    padding: 53px 0 26px;
	}
	.page {
	    background: #fff;
	    min-height: 100vh;
	}
	uni-view, uni-text {
	    box-sizing: border-box;
	}
	.header{
	    height: 53px;
	    background: linear-gradient(148deg,#ffeed4,#aaaaff);
	    padding: 0 16px;
	    width: 100vw;
	    position: fixed;
	    top: 0;
	    left: 0;
	    z-index: 999;
		.header-left {
		    width: 12px;
		    height: 20px;
		}
		.header-center {
		    font-size: 17px;
		    font-weight: 700;
		    color: #333;
		    text-align: center;
		}
		.header-right {
		    width: 9px;
		    height: 17px;
		}
	}
	/deep/.u-modal__content__text {
		text-align: center;
	}
	//깊은
	.deep {
		width: 30rpx;
		height: 30rpx;
		background: #f35454;
		border-radius: 0.4rpx;
		text-align: center;
		line-height: 30rpx;
		color: #fff;
		font-size: 24rpx;
		display: inline-block;
	}
	.deep-number {
		display: inline-block;
		padding: 0 0.04rem;
		background: rgba(59, 79, 222, .1);
		border-radius: 10rpx;
		color: #f35454;
		font-size: 24rpx;
		vertical-align: middle;
	}
	.toubu {
		width: 100%;
		// height: 120rpx;
		background-image: linear-gradient(to right, #f35454, #f35454);
		display: flex;
		justify-content: space-between;
		color: #fff;
		padding: 80rpx 0 80rpx 0;
		display: flex;
		justify-content: flex-end;

		.search {
			padding-right: 30rpx;

			image {
				width: 40rpx;
				height: 40rpx;
			}
		}
	}

	.dabokl {
		background: #fff;
		width: 100%;
		border-radius: 30rpx 30rpx 0 0;
		padding-top: 30rpx;

		.available-balance {
			display: flex;
			align-items: center;
			justify-content: space-between;
			padding: 30rpx;
			border-bottom: 10rpx solid #f4f4f4;
			font-size: 30rpx;

			.balance {
				font-weight: 600;
			}


			.change {
				background: #aaaaff;
				color: #FFFFFF;
				padding: 10rpx 50rpx;
				font-size: 24rpx;
				border-radius: 20rpx;
			}
		}
		.green{
			color: green;
		}
		.red{
			color: #f25354;
		}

		.funding-situation {
			display: flex;
			align-items: center;
			justify-content: space-around;
			text-align: center;
			padding: 30rpx;
			border-bottom: 10rpx solid #f4f4f4;
			font-size: 30rpx;

			.xian {
				height: 100rpx;
				width: 2rpx;
				background: #9e9e9e;
			}


		}

		.green{
			color: green;
		}
		.red{
			color: #f25354;
		}
		.inv-h-w {
			background-color: #FFFFFF;
			height: 80rpx;
			display: flex;
			margin-top: 50rpx;
		}

		.inv-h {
			font-size: 28rpx;
			flex: 1;
			text-align: center;
			color: #666666;

			position: relative;
		}

		.inv-h-se {
			font-size: 30rpx;
			font-family: PingFang SC;
			font-weight: bold;
			color: #f35454;
		}

		.inv-h-se:after {
			content: '';
			position: absolute;
			bottom: 20rpx;
			// top: auto;
			left: 42%;
			height: 6rpx;
			width: 44rpx;
			background-color: #f35454;
		}

		//我的持仓
		.up-and-down-range {

			// padding: 0 30rpx;
			.share-certificate {
				h6 {
					font-size: 30rpx;
					margin: 10rpx 0;
				}
			}

			.position {
				background-image: linear-gradient(to right, #aaaaff, #aaaaff);
				color: #fff;
				padding: 10rpx 30rpx;
				border-radius: 30rpx;
				font-size: 28rpx;
			}

			.up-date {
				width: 30%;

				text {
					color: #ff0a0a;
					font-weight: 600;
				}
			}

			.buy-up {
				color: red;
				width: 30%;
			}

			.time {
				color: #666;
				// width: 60%;
				text-align: right;
			}

			.shadow {
				background: #fff;
				display: flex;
				justify-content: space-between;
				align-items: center;
				padding: 20rpx 30rpx;

				font-size: 26rpx;

				.display {
					width: 40%;

					.quantity {
						color: #ff0a0a;
					}
				}
			}

			.shadows {

				display: flex;
				justify-content: space-between;
				align-items: center;
				padding: 6rpx 30rpx;
				font-size: 26rpx;

				.display {
					width: 40%;

					.quantity {
						color: #ff0a0a;
						text-align: right;
						width: 50%;
					}
				}
			}

		}

		// 没有更多
		.finished-text {
			color: #969799;
			font-size: 28rpx;
			margin: 30rpx auto;
			text-align: center;
			padding: 30rpx 0;
		}

		// 我的交易
		.transaction {

			// padding: 0 30rpx;
			// padding: 0 30rpx;
			.share-certificate {
				h6 {
					font-size: 30rpx;
					margin: 10rpx 0;
				}
			}

			.position {
				background-image: linear-gradient(to right, #1a73e8, #f35454);
				color: #fff;
				padding: 10rpx 30rpx;
				border-radius: 30rpx;
				font-size: 28rpx;
			}

			.up-date {
				text {
					color: #ff0a0a;
					font-weight: 600;
				}
			}

			.buy-up {
				color: red;
			}

			.time {
				color: #666;
			}

			.shadow {
				background: #fff;
				display: flex;
				justify-content: space-between;
				align-items: center;
				padding: 20rpx 30rpx;
				font-size: 26rpx;

				.display {
					width: 40%;

					.quantity {
						color: #ff0a0a;
					}
				}
			}

			.shadows {

				display: flex;
				justify-content: space-between;
				align-items: center;
				padding: 6rpx 30rpx;
				font-size: 26rpx;

				.shadows-dis {
					width: 40%;

					.quantity {
						margin: 10rpx 0;
						color: #ff0a0a;
					}
				}

				.display {
					width: 40%;

					.quantity {
						color: #ff0a0a;
					}
				}
			}


			// 没有更多
			.finished-text {
				color: #969799;
				font-size: 28rpx;
				margin: 30rpx auto;
				text-align: center;
				padding: 30rpx 0;
			}
		}

	}
</style>