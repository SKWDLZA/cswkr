<template>
	<view class="page">
		<view class="home" style="padding: 30px 10px 10px 20px;"> 
			<view class="flex gap10">
				<u-icon name="/static/zuojiantou.png" class="padding-left-10" @click="$u.route({type:'navigateBack'})" imgMode="widthFix" style="width: 20px;"></u-icon>
				
				<u-search shape="round" placeholder="종목코드검색" v-model="keyword" :showAction="false" height="30px" searchIconColor="#4f61f5" searchIconSize="20" bgColor="#F2F4F5" @clear="keyword=''" actionText="검색" @search="searchButton" searchIcon="/static/new/sousuo.png" @custom="searchButton" style="margin-right: 10px;"></u-search>
			</view>
			<view class="margin-top-20">
			</view>
			
			<view style="background: #fff;margin-top: 10px;" class="margin-left-10">
				<view v-if="!searchList" >
					<view class="flex flex-b">
						<view class="bold">기록</view>
						<image src="/static/new/clear.png" mode="widthFix" style="width: 20px;margin-right: 10px;" @click="clear"></image>
					</view>
					<view  class="flex gap10 margin-top-10 flex-wrap">
						<view v-for="(item,index) in keywords" style="background-color: #F6F9FF;padding: 10px 15px;border-radius: 20px;color: #333333;" @click="keyword=item;searchButton()">
							{{item}}
						</view>
					</view>
					
				</view>
				
				<view class="box" style="border-radius: 10px; " v-if="searchList">
					
					
					<view class=" box-item flex flex-b padding-10" v-for="(item,index) in searchList"
						@click="$u.route('/pages/marketQuotations/productDetails',{code:item.number_code});">
						
						<template v-if="!item.logo || item.logo==''">
							<view
								style="width: 40px;height: 40px;background-color:#2d2c62;text-align: center;line-height: 40px;color: #FFFFFF;margin-bottom: 4px;;border-radius:10px;">
								{{item.name.slice(0,1)}}
							</view>
						</template>
						<template v-else>
							<image mode="widthFix" :src="$BaseUrl+item.logo" style="width: 40px;height: 40px;border-radius: 10px">
							</image>
						</template>
						
						<view style="border-radius: 3px;padding: 3px 8px;" class="margin-left-10">
							<view class="font-size-15">
								{{item.name}}
							</view>
							<view style="color: #999999;">
								{{item.number_code}}
							</view>
						</view>
						<view style="margin-left:auto;">
							<view class="text-center" style="gap: 20px">
								<view :class="item.rate>0?'red bold':'green bold'">
									<image :src="item.rate>0?'/static/new/up.png':'/static/new/down.png'" mode="widthFix"
										style="width: 15px;"></image>
									{{item.rate>0?'+':""}}{{(1*item.rate).toFixed(2)}}%
						
								</view>
								<view style="border-radius: 3px;padding: 3px 8px;color: #000;font-size: 18px;">
									{{numberToCurrency(item.current_price*1)}}
								</view>
							</view>
						
						</view>
						
					</view>
				
				</view>
				<view style="width: 60%;margin-left: 20%;margin-top: 30%; margin-bottom: 20%;" v-if="!searchList">
					<u-image src="/static/market/no.png" width="100%" mode="widthFix"></u-image>
					
					<view class="font-size-14 text-center padding-bottom-30">기록 없음</view>
				</view>
			</view>
			
			
		</view>	
		
	</view>
</template>
<script>
	export default {
		data() {
			return {
				searchList: '',
				pager: {
					page: 1,
					limit: 20
				},
				keyword: "",
				keywords:[],
				gp_select: [{
					name: "국내",
				}, {
					name: "해외",
				}
				],
				gp_index:0,
			};
		},
		onReachBottom() {
			this.status = 'loading';
			this.pager.page++;
			this.searchButton()
		},
		onLoad() {
			let keywords=uni.getStorageSync("keywords")
			if(keywords){
				this.keywords=keywords
			}
			console.log(this.keywords)
		},
		methods: {
			numberToCurrency(value) {
				if (!value) return '0'
				// 将数值截取，保留两位小数
				value = value.toFixed(2)
				// 获取整数部分
				const intPart = Math.trunc(value)
				// 整数部分处理，增加,
				const intPartFormat = intPart.toString().replace(/(\d)(?=(?:\d{3})+$)/g, '$1,')
			
				return intPartFormat
			},
			clear(){
				this.keywords=""
				uni.setStorageSync("keywords","")
			},
			gp_select_click(e){
				this.storehouse=""
				this.gp_index=e.index
			},
			dianji(keyword){
				this.keyword=keyword;
				this.searchButton()
			},
			home() {
				uni.switchTab({
					url: '/pages/index/index'
				});
			},
			detailed(gid) {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/marketQuotations/productDetails' + `?gid=${gid}`
				});
				// console.log(gid, "携带");
			},
			//搜索
			async searchButton() {
				if (this.keyword == '') {
					this.searchList=""
					uni.$u.toast('검색어는 비워둘 수 없습니다. 다시 검색해 주세요');

				} else {
					uni.showLoading({
						title: "검색...",
						mask: true, // 显示透明蒙层，防止触摸穿透
					});
					let list = await this.$http.post('api/product/list', {
						key: this.keyword,
						page: 1,
						limit: 9999999,
						gp_index:this.gp_index
					})
					this.searchList = list.data.data
					console.log(8888,list.data.data)
					uni.hideLoading();
					if(list.data.data.length>0){
						if(this.keywords.indexOf(this.keyword)<0){
							this.keywords.push(this.keyword);
							uni.setStorageSync("keywords",this.keywords)
						}
					}
					
					
			
					
					
				}

			},
		
		}
	}
</script>

<style lang="scss">
	view,
	uni-text {
		box-sizing: border-box;
	}
	.page{
		min-height: 100vh;
		background-color: #fff;
	}
	.home{
		background-image: url(/static/chuanggai/home-top.png);
		/* 背景图片覆盖整个容器，可能会裁剪 */  
		background-size: cover;  
	  /* 让背景图片始终位于容器的中心 */  
		background-position: center;  
	  /* 不重复背景图片 */  
		background-repeat: no-repeat;  
		height: 600rpx;
		margin-left: -10px;
	}
</style>