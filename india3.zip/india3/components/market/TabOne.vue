<template>
	<view>
		
		<view>
			<view style="box-shadow: rgba(149, 157, 165, 0.2) 0px 8px 24px;width: 94%;margin-left: 3%;border-radius: 5px;padding:20px 10px;justify-content: space-between;" class="display">
				<view class="flex-1">
					<view style="font-weight: 700;" :style="top1.rate>0?'color:green':'color:red'">
						{{top1.close.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}
					</view>
					<view style="font-size: 12px;">
						Sensex
					</view>
				</view>
				<view class="flex-1" >
					<view style="font-size: 12px;">
						High:{{top1.high.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}
					</view>
					<view style="font-size: 12px;">
						Low:{{(top1.low.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","))}}
					</view>
				</view>
				<view class="flex-1" style="text-align: right;">
					<view>
						{{(top1.price_chg)}}
					</view>
					<view :style="top1.rate>0?'color:green':'color:red'">
						{{(top1.rate)}}%
					</view>
				</view>
			</view>
			
			<view style="box-shadow: rgba(149, 157, 165, 0.2) 0px 8px 24px;width: 94%;margin-left: 3%;border-radius: 5px;padding:20px 10px;justify-content: space-between;" class="display">
				<view class="flex-1">
					<view style="font-weight: 700;" :style="top11.rate>0?'color:green':'color:red'">
						{{top11.close.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}
					</view>
					<view style="font-size: 12px;">
						Nifty
					</view>
				</view>
				<view class="flex-1" >
					<view style="font-size: 12px;">
						High:{{top11.high.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}
					</view>
					<view style="font-size: 12px;">
						Low:{{(top11.low.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","))}}
					</view>
				</view>
				<view class="flex-1" style="text-align: right;">
					<view>
						{{(top11.price_chg)}}
					</view>
					<view :style="top1.rate>0?'color:green':'color:red'">
						{{(top11.rate)}}%
					</view>
				</view>
			</view>
			
			<view style="box-shadow: rgba(149, 157, 165, 0.2) 0px 8px 24px;width: 94%;margin-left: 3%;border-radius: 5px;padding:20px 10px;justify-content: space-between;" class="display">
				<view class="flex-1">
					<view style="font-weight: 700;" :style="top12.rate>0?'color:green':'color:red'">
						{{top12.close.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}
					</view>
					<view style="font-size: 12px;">
						Nifty Bank
					</view>
				</view>
				<view class="flex-1" >
					<view style="font-size: 12px;">
						High:{{top12.high.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}
					</view>
					<view style="font-size: 12px;">
						Low:{{(top12.low.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","))}}
					</view>
				</view>
				<view class="flex-1" style="text-align: right;">
					<view>
						{{(top12.price_chg)}}
					</view>
					<view :style="top1.rate>0?'color:green':'color:red'">
						{{(top12.rate)}}%
					</view>
				</view>
			</view>
		</view>
		<!-- <u-tabs :list="tablist" lineColor="#f59230"  activeStyle="color:#f59230;font-size:18px;font-weight: 700;"  inactiveStyle="font-size:18px;font-weight: 700;" @change="qiehuan" :current="current1"></u-tabs>
		<view class="line-box">
			<view class="nums flex flex-b">
				<view class="nums-item">
					<view class="t num-font" :class="top1.rate>0?'die':''">{{top1.close.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</view>
					<view class="t1 " :class="top1.rate>0?'die':''">{{(top1.rate)}}%</view>
				</view>
				<view class="nums-item">
					<view class="t1" :class="top1.rate>0?'die':''"></view>
					<view class="t1 " :class="top1.rate>0?'die':''">Low:{{(top1.low.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","))}}</view>
				</view>
			</view>
		</view> -->
		<!-- <view class="charts-box">
		    <qiun-data-charts 
		      type="area"
		      :opts="opts"
		      :chartData="chartData"
		      :tooltipShow="true"
		      :tapLegend="false"
		    />
		  </view> -->
		<view>
			<view class="list">
				<view class="tt">
					<view class="flex flex-b">
						<view class="t">Top Gainers</view>
						<view class="t1">Update {{today}}</view>
					</view>
					<view class="cot">
						<view class="flex tab">
							<view class="tab-item" :class="current2==0?'active':''" @click='qiehuan2(0)'>NSE</view>
							<view class="tab-item" :class="current2==1?'active':''" @click='qiehuan2(1)'>BSE</view>
						</view>
					</view>
				</view>
				<view class="lists">
					<view class="item flex flex-b" v-for="(item,index) in top2"  @click="$u.route('/pages/marketQuotations/productDetails',{code:item.co_code,type:current2*1+1});">
						<view class="flex flex-3">
							<view class="t">{{index+1}}</view>
							
							<view style="margin-left: 20px;">
								<view class="name">{{item.co_name}}</view>
								<span style="font-weight: 700;font-size: 13px;"
									:style="item.per_chg*1>0?'color:#0e8103':'color:#ef4d4b'">{{item.current_price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}
								</span>
								<span style="font-weight: 700;font-size: 13px;margin-left: 10px;"
									:style="item.per_chg*1>0?'color:#0e8103':'color:#ef4d4b'">
									{{(item.per_chg*1).toFixed(2)}}%</span>
							</view>
						</view>
						<view class="flex-1 flex flex-e" @click="handleClickDelProduct(item.gid)">
							<!-- <u-icon name="photo" ></u-icon> -->
							<u-image src="/static/icon/sc.png" width="18" height="18" v-if="!item.sc"></u-image>
							<u-image src="/static/icon/qxsc.png" width="18" height="18" v-if="item.sc"></u-image>
						</view>
					</view>
				</view>
				<!-- <view class="flex flex-c more" @click="$u.route({type:'reLaunch',url:'/pages/marketQuotations/marketQuotations?type=1'});">View more featured items<view class="icon jtr">
					</view>
				</view> -->
			</view>
		</view>
		<view>
			<view class="list">
				<view class="tt">
					<view class="flex flex-b">
						<view class="t">Top Losers</view>
						<view class="t1">Update {{today}}</view>
					</view>
					<view class="cot">
						<view class="flex tab">
							<view class="tab-item" :class="current33==0?'active':''" @click='qiehuan3(0)'>NSE</view>
							<view class="tab-item" :class="current33==1?'active':''" @click='qiehuan3(1)'>BSE</view>
						</view>
					</view>
				</view>
				<view class="lists">
					<view class="item flex flex-b" v-for="(item,index) in top3"  @click="$u.route('/pages/marketQuotations/productDetails',{code:item.co_code,type:current2*1+1});">
						<view class="flex flex-3">
							<view class="t">{{index+1}}</view>
							
							<view style="margin-left: 20px;">
								<view class="name">{{item.co_name}}</view>
								<span style="font-weight: 700;font-size: 13px;"
									:style="item.per_chg*1>0?'color:#0e8103':'color:#ef4d4b'">{{item.current_price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}
								</span>
								<span style="font-weight: 700;font-size: 13px;margin-left: 10px;"
									:style="item.per_chg*1>0?'color:#0e8103':'color:#ef4d4b'">
									{{(item.per_chg*1).toFixed(2)}}%</span>
							</view>
						</view>
						<view class="flex-1 flex flex-e" @click="handleClickDelProduct(item.gid)">
							<!-- <u-icon name="photo" ></u-icon> -->
							<u-image src="/static/icon/sc.png" width="18" height="18" v-if="!item.sc"></u-image>
							<u-image src="/static/icon/qxsc.png" width="18" height="18" v-if="item.sc"></u-image>
						</view>
					</view>
				</view>
				<!-- <view class="flex flex-c more" @click="$u.route({type:'reLaunch',url:'/pages/marketQuotations/marketQuotations?type=1'});">View more featured items<view class="icon jtr">
					</view>
				</view> -->
			</view>
		</view>
		
	</view>
</template>

<script>
	import {
		area
	} from '../../consts/area.js'
	
	import { init,registerLocale,dispose    } from 'klinecharts'
	
	import uCharts from '@/common/u-charts.js';
	var uChartsInstance = {};
	export default {
		name:'TabOne',
		components: {
			area
		},
		props: {},
		data() {
			
			return {
				tablist: [{
					name: 'Sensex'
				}, {
					name: 'Nifty'
				}, {
					name: 'Nifty Bank'
				}],
				current: 0,
				top1: [],	
				top11: [],
				top12: [],
				kline: [],
				kLineChart: [],
				current1: 0,
				current2: 0,
				current3: 0,
				current33: 0,
				article: [],
				top2: [],
				top3: [],
				bottom: [],
				chartData: {},
				opts:"",
				today:""
			}
		},
		
		methods: {
			
			open(url){
				window.open(url)
			},
			//删除
			async handleClickDelProduct(e) {
				let list = await this.$http.post('api/user/collect_edit', {
					gid: e,
				})
				if (list.data.code == 0) {
					uni.$u.toast(list.data.message);
					this.top_two()
					this.top_three()
				} else {
					this.show = false
					uni.$u.toast(list.data.message);
				}
			},
			qiehuan33(current) {
				this.current33 = current;
				this.top_three()
			},
			qiehuan3(current) {
				this.current33 = current;
				this.top_three()
			},
			qiehuan2(current) {
				this.current2 = current;
				this.top_two()
			},
			qiehuan(current1) {
				console.log(2222,current1);

				this.current1 = current1.index;
				this.top_one()
			},
			async top_one() {
				
				let list = await this.$http.post('api/goods/top1', {
					current1: this.current1

				})

				this.top1 = list.data.data.top1
	
				console.log(list.data.data);

				let res = {
					categories: list.data.data.time,
					series: [
					  {
						name: "",
						data: list.data.data.kline
					  }
					]
				  };
				this.chartData = JSON.parse(JSON.stringify(res));
				
				this.$forceUpdate()
			},
			async top_one1() {
				
				let list = await this.$http.post('api/goods/top1', {
					current1: 1
			
				})
			
				this.top11 = list.data.data.top1
				
				console.log(list.data.data);
			
				// let res = {
				// 	categories: list.data.data.time,
				// 	series: [
				// 	  {
				// 		name: "",
				// 		data: list.data.data.kline
				// 	  }
				// 	]
				//   };
				// this.chartData = JSON.parse(JSON.stringify(res));
				
				this.$forceUpdate()
			},
			async top_one2() {
				
				let list = await this.$http.post('api/goods/top1', {
					current1: 2
			
				})
			
				this.top12 = list.data.data.top1
				
				console.log(list.data.data);
			
				// let res = {
				// 	categories: list.data.data.time,
				// 	series: [
				// 	  {
				// 		name: "",
				// 		data: list.data.data.kline
				// 	  }
				// 	]
				//   };
				// this.chartData = JSON.parse(JSON.stringify(res));
				
				this.$forceUpdate()
			},
			async top_two() {
				// uni.showLoading({

				// })
				let list = await this.$http.post('api/goods/top2', {
					current: this.current2
				})
				this.top2 = list.data.data
				uni.hideLoading()
			},
			async top_three() {
				// uni.showLoading({

				// })
				let list = await this.$http.post('api/goods/top3', {
					current: this.current33
				})
				this.top3 = list.data.data
				// uni.hideLoading()
			},
			
			//定时器
			startTimer() {
				const storedTimerId = uni.getStorageSync('timerId');
				if (storedTimerId) {
					clearInterval(storedTimerId);
				}
				this.timerId = setInterval(() => {
					this.top_one()
					this.top_two()
					this.top_three()
					// this.dataUpdate()
				}, 5000);
				uni.setStorageSync('timerId', this.timerId);


			},
		},

		mounted() {
			this.opts=area
			this.top_one()
			this.top_one1()
			this.top_one2()
			
			this.top_two()
			
			var date = new Date(),
				year = date.getFullYear(), //年
				month = date.getMonth() + 1, //月
				day = date.getDate(); //日
			this.today=day+"-"+month+"-"+year
			this.top_three()
			// this.startTimer()
			
			
		},
		
		onUnload() {
			clearInterval(this.timerId);
		},
		onHide() {
			clearInterval(this.timerId);
		},
	}
</script>

<style lang="scss">
	.page {
		min-height: 100vh;
		background-color: #fff;
		padding: 60px 0 70px;
	}

	view,
	text {
		box-sizing: border-box;
	}
	.charts-box{
		width: 100%;
		height: 200px;
	}
	

	.header {
		padding: 0 15px;
		width: 100vw;
		height: 50px;
		line-height: 50px;
		background: #014b8d;
		position: fixed;
		top: 0;
		left: 0;
		z-index: 999;

		.title {
			font-size: 16px;
			font-weight: 700;
			color: #fff;
		}
	}



	.flex.flex-b {
		-webkit-box-pack: justify;
		-webkit-justify-content: space-between;
		justify-content: space-between;
	}

	.flex {
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
		-webkit-box-align: center;
		-webkit-align-items: center;
		align-items: center;
	}

	.line-box {
		padding: 0 5px;

		.top {
			padding: 16px 10px;

			.t {
				font-size: 19px;
				font-weight: 700;
				color: #333;
			}

			.t1 {
				font-size: 12px;
				color: #999;
			}
		}
	}

	.pdd {
		padding: 0 5px;
	}

	.nav-boxs {
		height: 32px;
		line-height: 32px;

		.nav-items {
			font-size: 17px;
			font-weight: 700;
			color: #999;
			background: #f1f2f4;
			border-radius: 5px;
			padding: 0 10px;
			margin-right: 10px;
		}

		.active {
			color: #014b8d;
			background: #e0e3eb;
		}

	}

	.line-box .nums {
		background: #f0f3fa;
		border-radius: 10px;
		padding: 5px;
		text-align: center;
		margin: 16px 0;

		.nums-item {
			width: 48%;
			background: #fff;
			border-radius: 8px;
			padding: 16px 0;

			.name {
				color: #0e8103;
			
			}

			.icon {
				margin: 5px auto;
			}

			.t {
				font-size: 14px;
				font-family: Roboto;
				font-weight: 700;
				color: #ff3636;
			}

			.t.die {
				color: #0e8103;
			}

			.t1 {
				font-size: 14px;
				font-family: Roboto;
				font-weight: 400;
				color: #ff3636;
			}

			.t1.die {
				color: #0e8103;
			}

		}
	}

	.line-box .last {
		padding: 10px;

		view {
			font-size: 12px;
			color: #333;
		}

		span {
			font-size: 12px;
			color: red;
			margin-left: 5px;
		}
	}

	.list {
		padding: 16px 0;
		// border-top: 5px solid #f5f5f5;
		border-bottom: 5px solid #f5f5f5;
		margin-top: 10px;

		.tt {
			font-size: 19px;
			font-weight: 700;
			color: #333;
			padding: 0 10px 16px;

		}

		.pdd {
			padding: 0 10px 16px;
			border-bottom: 1px solid #ccc;

			.item {
				width: 49%;

				uni-image {
					width: 100%;
					height: 117px;
					border-radius: 5px;
					margin-bottom: 10px;
				}
			}

		}

		.items {
			padding: 16px 10px;
			border-bottom: 1px solid #ccc;
		}

		.tt {
			font-size: 19px;
			font-weight: 700;
			color: #333;
			padding: 0 10px 16px;

			.t {
				font-size: 19px;
				font-weight: 700;
				color: #333;
			}

			.t1 {
				font-size: 12px;
				color: #999;
			}

			.cot .tab {
				padding: 16px 0 0;

				.tab-item {
					background: #f1f2f4;
					border-radius: 5px;
					color: #999;
					height: 32px;
					line-height: 32px;
					text-align: center;
					min-width: 20%;
					margin-right: 10px;
				}

				.tab-item.active {
					background: #e7f1f9;
					color: #014b8d;
				}
			}
		}
	}

	.show {
		overflow: hidden;
		text-overflow: ellipsis;
		display: -webkit-box;
		-webkit-box-orient: vertical;
		-webkit-line-clamp: 2;
		font-weight: 500;
	}

	.more {
		padding: 16px 0;
		color: #333;

		.icon {
			margin-left: 5px;
		}
	}

	.flex.flex-c {
		-webkit-box-pack: center;
		-webkit-justify-content: center;
		justify-content: center;
	}

	.lists {
		padding: 16px 10px 10px;

		.item {
			margin-bottom: 16px;
		}

		.t {
			font-size: 19px;
			font-weight: 700;
			color: #333;
			margin-right: 10px;
		}

		.name {
			font-size: 14px;
			font-weight: 600;
			color: #333;
			margin-bottom: 5px;
		}

		.code {
			background: #f0f3fa;
			border-radius: 5px;
			padding: 5px 10px;
			font-size: 12px;
			font-family: Roboto;
			font-weight: 400;
			color: #333;
		}

		.nums {
			background: #f7e8e8;
			border-radius: 10px;
			padding: 5px 10px;
			-webkit-box-flex: 1;
			-webkit-flex: 1;
			flex: 1;

			.t1 {
				font-size: 14px;
				font-family: Roboto;
				font-weight: 400;
				color: #ff3636;
			}
		}
	}

	.tb {
		height: 32px;
		background: #f1f2f4;
		border-radius: 5px;
		padding: 0 5px;
		margin-top: 16px;

		.it {
			-webkit-box-flex: 1;
			-webkit-flex: 1;
			flex: 1;
			text-align: center;
			height: 26px;
			border-radius: 3px;
			color: #014b8d;
			line-height: 26px;
		}

		.it.active {
			background: #fff;
		}
	}

	.top1 {
		border-bottom: 1px solid #ccc;
		padding: 16px 10px;

		.t {
			font-size: 19px;
			font-weight: 700;
			color: #333;
		}

		.t1 {
			margin-top: 16px;
		}
	}

	.list {
		padding: 16px 10px;

		.item {

			margin-bottom: 16px;

			.red {
				font-weight: 600;
				color: #ff3636;
			}

			.red.die {
				color: #014b8d;
			}
		}
	}

	.ct {
		width: 149px;

		.bg {
			background: #e7f1f9;
			border-radius: 5px;
			overflow: hidden;

			.b-bg {
				height: 21px;
				background: #014b8d;
			}

			.r-bg {
				height: 21px;
				background: red;
			}
		}
	}
</style>