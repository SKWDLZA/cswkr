<!-- 新股配售 -->
<template>
	<view>
		<CustomHeader :title="title" @action="handleBack()"></CustomHeader>
		<view class="common_block" style="padding: 6px;">
			<TradeHeader :title="title" icon="block_trade" @action="handlePayHistory()"></TradeHeader>
			<view style="background-color: #FFF;margin-top: 10px;">
				<view v-for="(item,index) in funding" :key="index"
					style="border-bottom: 0.037037rem solid #e0e0e0;margin:10px;padding-bottom: 10px;">
					<view class="display" style="margin: 20rpx 0;">
						<view class="">
							<view class="corporation">{{item.goods.name}}</view>
							

						</view>
						<!-- 申购 -->
						<view class="purchase" @tap="purchase(item.id,item.peishou_price)">
							リクエスト
						</view>
					</view>

					<view class="display">
						<view class="display find">
							<view class="">
								発行価格</view>
							<view class="">{{item.price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}/공유하다</view>
						</view>
						<view class="display ration">
							<view class="">
								バッチ価格</view>
							<view class="">{{item.peishou_price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}
							</view>
						</view>
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	import TradeHeader from '@/components/TradeHeader.vue';
	import TradeList from '@/components/TradeList.vue';
	export default {
		components: {
			CustomHeader,
			TradeHeader,
			TradeList
		},
		data() {
			return {
				options: {},
				funding: [],
			}
		},
		onLoad(opts) {
			this.options = opts;
		},
		mounted() {
			this.scramble()
		},

		computed: {
			title() {
				return this.options.tag;
			}
		},
		methods: {
			handleBack() {
				uni.switchTab({
					url: '/pages/index/index'
				});
			},
			handlePayHistory(){
				return false;
			},
			// 기록 보관
			ration() {
				uni.navigateTo({
					url: '/pages/index/components/newShares/ration/ration'
				});
			},
			// 우승기록
			luckyNumber() {
				uni.navigateTo({
					url: '/pages/index/components/newShares/ration/luckyNumber'
				});
			},
			//抢筹
			purchase(id, peishou_price) {
				uni.navigateTo({
					url: '/pages/index/components/newShares/offlinePlacement/offlinePlacement' +
						`?id=${id}&peishou_price=${peishou_price}`
				});
				// console.log(gid, '抛出去');
			},

			//列表
			async scramble() {
				let list = await this.$http.post('api/goods-scramble/calendar', {})
				this.funding = list.data.data
				// console.log(this.funding, '99999999');
			},
		},
	}
</script>

<style lang="scss">
	.corporation {
		font-size: 30rpx;
		font-weight: 600;
		color: #333;

	}

	.purchase {
		background-color: rgb(72, 156, 229);
		color: #fff;
		border-radius: 40rpx;
		padding: 6rpx 40rpx;
		font-size: 26rpx
	}

	.find {
		width: 50%;
		font-size: 28rpx;

		view:nth-child(2) {
			color: #f85252;
		}
	}

	.ration {
		width: 42%;
		font-size: 28rpx;

		view:nth-child(2) {
			color: #f85252;
		}
	}
</style>