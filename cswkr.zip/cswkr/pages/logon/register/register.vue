<template>
	<!-- 登录 -->
	<view >
		<view style="background-color: #212265;color:#FFF;text-align: center;padding:10px 0">등록하다</view>
		
		<view class="logo1" style="margin-top: 26%;">
			<view class="border flex flex-c">
				<view class="icon logo"></view>
			</view>
		</view>
		<view style="margin-top: 5%;" >
			<view class="flex justify-center">
				<view style="width: 100rpx;height: 4rpx;background: #969696;" class="radius10"></view>
				<view class="padding-10 bold" style="color: #666666;font-size: 34rpx;">
					로그인 정보</view>
				<view style="width: 100rpx;height: 4rpx;background: #969696;" class="radius"></view>
			</view>
			<view class="flex justify-center margin-top-30">
				<view class="radius30" style="height: 40rpx;width: 80%;">
					<u--input shape="circle"
						    placeholder="아이디(전화번호) 입력"
						    prefixIcon="account-fill"
							placeholderStyle="font-size: 10px;color: #ababab"
						    prefixIconStyle="font-size: 22px;color: #909399;margin-left:10px"
							v-model="value1"
							type="number"
							maxlength="11"
						></u--input>
				</view>
			</view>
			<view class="flex justify-center" style="margin-top: 40px;">
				<view class="radius30" style="height: 40rpx;width: 80%;">
					<u--input shape="circle"
						    placeholder="비밀번호를 입력"
						    prefixIcon="lock-fill"
							placeholderStyle="font-size: 10px;color: #ababab"
						    prefixIconStyle="font-size: 22px;color: #909399;margin-left:10px"
							v-model="value2"
							type="password"
						></u--input>
				</view>
			</view>
			<view class="flex justify-center" style="margin-top: 40px;">
				<view class="radius30" style="height: 40rpx;width: 80%;">
					<u--input shape="circle"
						    placeholder="비밀번호 재입력"
						    prefixIcon="lock-fill"
							placeholderStyle="font-size: 10px;color: #ababab"
						    prefixIconStyle="font-size: 22px;color: #909399;margin-left:10px"
							v-model="value3"
							type="password"
						></u--input>
				</view>
			</view>
			<view class="flex justify-center" style="margin-top: 40px;">
				<view class="radius30" style="height: 40rpx;width: 80%;">
					<u--input shape="circle"
						    placeholder="초대 코드 입력"
						    prefixIcon="attach"
							placeholderStyle="font-size: 10px;color: #ababab"
						    prefixIconStyle="font-size: 22px;color: #909399;margin-left:10px"
							v-model="code"
						></u--input>
				</view>
			</view>
			
			<view class="margin-top-30 text-right flex justify-end" style="margin-right: 10%;">
				<view style="font-size: 12px;color: #ababab" @tap="signIn()">
					로그인
				</view>
				<u-icon name="arrow-right" color="#B3BFD0" size="18" :bold="true"></u-icon>
				
			</view>
			<view class="flex justify-center" style="margin:30px 10%;">
				<view class="radius30 text-center" style="background-color: #212265;width: 100%;height: 50rpx;color: #fff;padding: 6px 9px;line-height: 50rpx;" @click="gain_register">
					회원 가입
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				nick_name:'',
				value1: '',
				value2: '',
				value3: '',
				code: '',
				checkboxValue1: [],
				showPassword:true
			};
		},
		methods: {
			showPassWord() {
				this.showPassword = !this.showPassword
			},
			//协议
			agree() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/my/components/other/userAgreement'
				});
			},
			// 跳转到登录
			signIn() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/logon/logon/logon'
				});
			},
			home() {
				uni.navigateBack({
					delta: 1, //返回层数，2则上上页
				});
			},
			//注册
			async gain_register() {
				if (this.value1 == '') {
					uni.$u.toast('전화번호를 입력해주세요.');
				} else if (this.value2 == '') {
					uni.$u.toast('비밀번호를 입력해주세요');
				} else if (this.value3 == '') {
					uni.$u.toast('비밀번호를 입력해주세요');
				} else if (this.value3 != this.value2) {
					uni.$u.toast('두 개의 비밀번호가 일치하지 않습니다');
				} else if (!this.code) {
					uni.$u.toast('인증번호를 입력해주세요');
				} 
				// else if (this.checkboxValue1.length == 0) {
				// 	uni.$u.toast('請閱讀協議後,在勾選');
				// } 
				else {
					let list = await this.$http.post('api/app/register', {
						mobile: this.value1,
						password: this.value2,
						confirmpass: this.value3,
						invite: this.code,
						code: 123456,
					})
					// console.log(list.data.code);
					if (list.data.code == 0) {
						uni.$u.toast('등록이 완료되었습니다. 로그인하세요.');
						setTimeout(() => {
							uni.navigateTo({
								url: '/pages/logon/logon/logon'
							});
						}, 1000)
					} else {
						uni.$u.toast(list.data.message);
					}
				}
			},
			//数据请求
			async login_liufu() {
				try {
					uni.removeStorageSync('url');
				} catch (e) {}
				let list = await this.$http.get(
					'https://sm8-x8ax6-b574-u99hy-w4uv-dgm4-s-p-c.oss-cn-hongkong.aliyuncs.com/sotck-S1GT9GYprH0PVgMLwapC0nYzLAoDa0bd.txt', {
						// language: this.$i18n.locale
					})
				// 接口域名
				// console.log(list.data, '接口位置')
				uni.setStorageSync('url', list.data);
			},

		},
		async mounted() {
			await this.login_liufu()
		}
	}
</script>

<style lang="scss">
	.logo1{
		width: 100%;
		height: 100%;
		.icon.logo {
			width: 120px;
			height: 120px;
			background: url(/static/logo.png) no-repeat 50%/100%;
			// border-radius: 50%;
		}
	}
</style>