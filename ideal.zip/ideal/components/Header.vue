<template>
	<header class="common_header">

		<view class="primary_header_left" @click="$u.route({url:$util.PAGE_URL.SEARCH});">
			<image src="/static/search.png" :style="$util.calcImageSize(16)"></image>
		</view>
		<view class="primary_header_right">
			<view class="flex flex-b">

				<!-- <image mode="aspectFit" src="/static/service.png" :style="$util.calcImageSize(20)"
					@click="$u.route({url:$util.PAGE_URL.SERVICE});"  class="justify-center flex-1 view1"></image> -->
				<image mode="aspectFit" src="/static/service.png" :style="$util.calcImageSize(20)" @click="kefu"
					class="justify-center flex-1 view1"></image>
				<view style="border-left: 1px solid #fff;
  height: 30px;"></view>
				<image mode="aspectFit" src="/static/sign_out.png" :style="$util.calcImageSize(20)"
					@click="handleSignOut()" class="justify-center flex-1"></image>
			</view>

		</view>
	</header>
</template>

<script>
	export default {
		name: "Header",
		data() {
			return {};
		},
		methods: {
			async kefu() {
				let list = await this.$http.get(this.$http.API_URL.APP_CONFIG, {})
				let url = list.data.data[8].value

				// window.open(this.list, '_blank');
					if (window.android) {
						window.android.callAndroid("open," + url)
						return;
					}
					if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers
						.nativeExt) {
						window.webkit.messageHandlers.nativeExt.postMessage({
							msg: 'open,' + url
						})
						return;
					}

					var u = navigator.userAgent;
					var isiOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/); //ios终端
					if (isiOS) {
						window.location.href = url;
						return;
					}
					window.open(url)
				
			},
			handleSignOut() {
				this.$http.post(this.$http.API_URL.SIGN_OUT, );
				try {
					let version = uni.getStorageSync('version')
					uni.removeStorageSync('token');
					uni.setStorageSync('version', version)
				} catch (e) {
					// error
				}
				uni.$u.toast('성공적으로 종료');
				setTimeout(() => {
					uni.navigateTo({
						url: this.$util.PAGE_URL.ACCOUNT_SIGNIN
					});
					// 登录成功之后强制刷新页面
					this.$router.go(0)
				}, 500)
			}
		}
	}
</script>