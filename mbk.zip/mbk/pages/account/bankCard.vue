<!-- 绑定银行卡 -->
<template>
	<view>
		<view class="header_wrapper_10">
			<CustomHeader title="은행 계좌 연동" @action="handleBack()"></CustomHeader>
		</view>
		<view style="display: flex;flex-direction: column;justify-content: center;align-items: center;padding-top:3vh;" >
			<view v-if="isRenewal" style="width: 90%;">
				
				<view>
					<text class="u-demo-block__title ">성명:</text>
					<u--input border="surround" v-model="value" type="text" :placeholder="$lang.REAL_NAME" class="margin-top-10" :clearable='true'></u--input>
				</view>
				
				<view class="margin-top-20">
					<text class="u-demo-block__title">은행명:</text>
					<u--input border="surround" v-model="value1" type="text" :placeholder="$lang.BANK_NAME" class="margin-top-10" :clearable='true'></u--input>
				</view>
				
				<view class="margin-top-20">
					<text class="u-demo-block__title">계좌번호:</text>
					<u--input border="surround" v-model="value2" type="text" :placeholder="$lang.BANK_CARD" class="margin-top-10" :clearable='true'></u--input>
				</view>
			
			</view>
			<view v-else style="box-shadow: rgba(0, 0, 0, 0.24) 0px 3px 8px;width: 80%;padding: 10px;">
				<view class="flex flex-b" style="width: 100%;margin-top: 10px;">
					<view>성명:</view>
					<view>{{value}}</view>
				</view>
				<view class="flex flex-b" style="width: 100%;margin-top: 10px;">
					<view>은행명:</view>
					<view>{{value1}}</view>
				</view>
				<view class="flex flex-b" style="width: 100%;margin-top: 10px;">
					<view>계좌번호:</view>
					<view>{{value2}}</view>
				</view>
			</view>
			

			<template v-if="isRenewal">
				<view class="common_btn btn_primary" style="width:90%;margin-top: 20px;height: 40px;line-height: 40px;" @click="replaceBank()">확인</view>
				<view class="common_btn btn_secondary" style="width:90%;margin-top: 20px;height: 40px;line-height: 40px;" @click="handleCancel()">{{$lang.CANCEL}}</view>
			</template>
			<template v-else>
				<view class="common_btn btn_primary" style="width:90%;margin-top: 20px;height: 40px;line-height: 40px;" @click="renewal()">출금계좌 등록</view>	
			</template>
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components: {
			CustomHeader,
		},
		data() {
			return {
				info: {},
				isRenewal:false,
				value: '',
				value1: '',
				value2: '',
			};
		},
		onLoad() {
			this.gaint_info()
		},
		methods: {
			handleBack() {
				uni.navigateBack({
					delta: 1
				});
			},
			renewal() {
				this.isRenewal=true;
			},
			handleCancel(){
				this.isRenewal=false;
				this.replaceBank();
			},
			// 换绑银行卡
			async replaceBank() {
				console.log(this.$http.API_URL.USER_BIND_CARD)
				let list = await this.$http.post(this.$http.API_URL.USER_BIND_CARD, {
					//value2和value3反了
					//value2应该是bank_name  
					//value3应该是bank_sub_name
					realname: this.value,
					bank_name: this.value1,
					// bank_sub_name: this.value3,
					card_sn: this.value2,
				})
				if (list.data.code == 0) {
					uni.$u.toast('은행 카드 정보가 성공적으로 제출되었습니다.');
					setTimeout(() => {
						uni.switchTab({
							url: this.$util.PAGE_URL.ACCOUNT_CENTER
						});
					}, 1000)
				} else {
					uni.$u.toast(list.data.message);
				}

			},
			//用户信息
			async gaint_info() {
				const result = await this.$http.get('api/user/info', {})
				this.info = result.data.data.bank_card_info
				
				this.value=result.data.data.bank_card_info.realname
				this.value1=result.data.data.bank_card_info.bank_name
				this.value2=result.data.data.bank_card_info.card_sn
			},
		},
	}
</script>