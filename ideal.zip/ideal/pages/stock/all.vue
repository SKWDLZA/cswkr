<template>
	<view :style="{height:`${ $util.calcPageHeight()}px`}">
		<CustomHeader :title="$lang.STOCK_OVERVIEW" @action="handleBack()"></CustomHeader>
		<Tbas :btns="$util.SORT_MODE" @action="handleChangeTab"></Tbas>
		<!-- 		<template v-if="current==2">
			<view>关注</view>
		</template>
		<template v-else>
			<view>最新、最热、涨率、跌率</view>
		</template> -->
		<view class="common_block" style="margin-top: 10px;">
			<view style="display: flex;align-items: center;padding:6px 10px;" :style="{color:$util.THEME.LABEL}">
				<view style="flex:18%;">{{$lang.CODE}}/{{$lang.STOCK}}</view>
				<view style="flex:32%;"></view>
				<view style="flex:25%;text-align: right; padding-right: 16px;">{{$lang.RISE_FALL_AMOUNT}}</view>
				<view style="flex:20%;text-align: right; padding-right: 16px;">{{$lang.RISE_FALL_RATE}}</view>
			</view>
			<view style="overflow-y: scroll;height: 82vh;">
				<EmptyData v-if="list.length<=0"></EmptyData>
				<block v-for="(item,index) in list" :key="index">
					<view @click="handleDetail(item.code)" style="display: flex;align-items: center;padding:6px 10px;">
						<view style="flex:15%;font-weight: 900;padding-right: 16px;"
							:style="$util.calcStyleRiseFall(item.returns>0)">{{item.code}}</view>
						<view style="flex:40%;" :style="$util.calcStyleRiseFall(item.returns>0)">
							{{item.ko_name}}
						</view>
						<view style="flex:25%;text-align: right; padding-right: 16px;"
							:style="$util.calcStyleRiseFall(item.returns>0)">
							{{$util.formatNumber(item.close*1)}}
						</view>
						<view style="flex:20%;text-align: right; padding-right: 16px;"
							:style="$util.calcStyleRiseFall(item.returns>0)">
							{{item.returns>0?'+':""}}{{(1*item.returns).toFixed(2)}}%
						</view>
					</view>
				</block>
			</view>
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	import Tbas from '@/components/Tbas.vue';
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		components: {
			CustomHeader,
			Tbas,EmptyData,
		},
		data() {
			return {
				current: 0,
				list: [],
				timer: null,
			}
		},
		onLoad(option) {
			console.log(option);
			this.current = Number(option.index) || 0;
		},
		onShow() {
			this.getList()
			this.startTimer()
		},
		onHide() {
			clearInterval(this.timer);
		},
		methods: {
			handleBack() {
				uni.navigateBack({
					delta: 1
				});
			},
			handleChangeTab(val) {
				clearInterval(this.timer);
				this.current = val;
				this.getList();
				this.startTimer();
			},
			handleDetail(code) {
				uni.navigateTo({
					url: `${this.$util.PAGE_URL.STOCK_OVERVIEW}?code=${code}`
				});
			},
			//定时器
			startTimer() {
				this.timer = setInterval(() => {
					this.getList();
				}, 5000);
			},

			async getList() {
				if (this.list && this.list.length <= 0) {
					uni.showLoading({
						title: this.$lang.LOADING,
					})
				}
				const result = await this.$http.get(this.$http.API_URL.GOODS_LIST, {});
				if (result.data.code == 0) {
					uni.hideLoading();
				}
				if (this.current == 1) {
					this.list = result.data.data.sort((a, b) => a.stock_id - b.stock_id);
				} else if (this.current == 2) {
					this.list = result.data.data.sort((a, b) => b.returns - a.returns);
				} else if (this.current == 3) {
					this.list = result.data.data.sort((a, b) => a.returns - b.returns);
				} else {
					this.list = result.data.data;
				}
			},
		},
	}
</script>