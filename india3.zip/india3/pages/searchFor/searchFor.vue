<template>
	<view class="page">
		<view>
			<view class="header flex flex-b" style="background: linear-gradient(148deg,#ffeed4,#aaaaff);">
				<view class="icon jiantou" @click="$u.route({type:'navigateBack'});"></view>
				<view class="header-center flex-1">Search</view>
				<view class="header-right"></view><!---->
			</view>
		</view>
		<view class="search-box">
			<u-search placeholder="Stock code search" v-model="keyword" :clearabled="true" @clear="keyword=''" actionText="Search" @search="searchButton" @custom="searchButton"></u-search>
		</view>
		<view class="keyword-block" v-if="keywords">
			<view class="keyword-list-header">Search History</view>
			<view class="keyword" >
				<view v-for="(item,index) in keywords" @click="dianji(item)">{{item}}</view>
			</view>
		</view>
		<view class="box" v-if="searchList.length>0">
			<view class="top flex flex-b">
				<view class="flex-2">Stock</view>
				<view class="flex-1 t-r">Fluctuating rate</view>
				<view class="flex-1 t-r">Recency</view>
			</view>
			<view class=" box-item flex flex-b" v-for="(item,index) in searchList"  @click="$u.route('/pages/marketQuotations/productDetails',{code:item.number_code,type:item.project_type_id});">
				<view class="list-name flex-2">
					<view class="list-name-txt ">{{item.name}}<span>{{item.project_type_id==1?'NSE':'BSE'}}</span></view>
				</view>
				<view class="per flex flex-b flex-1 t-r" :class="item.rate*1>0?'bg-green':'bg-red'">
					<view class="icon" :class="item.rate*1>0?'up':'down'"></view>{{item.rate}}%
				</view>
				<view class="flex-1 t-r flex flex-b " :class="item.rate*1>0?'green':'red'"> 
					<view class="flex-1 t-a num-font">{{item.current_price}}</view>
					<!-- <view class="icon  wzx"></view> -->
				</view>
			</view>
		</view>
		<view v-if="!searchList||searchList.length==0">
			<view class="nodata">
				<view  class="no-img"></view>
				<view  class="txt">No Data</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				searchList: '',
				pager: {
					page: 1,
					limit: 20
				},
				keyword: "",
				keywords:[]
			};
		},
		onReachBottom() {
			this.status = 'loading';
			this.pager.page++;
			this.searchButton()
		},
		onLoad() {
			let keywords=uni.getStorageSync("keywords")
			if(keywords){
				this.keywords=keywords
			}
			console.log(this.keywords)
		},
		methods: {
			dianji(keyword){
				this.keyword=keyword;
				this.searchButton()
			},
			home() {
				uni.switchTab({
					url: '/pages/index/index'
				});
			},
			detailed(gid) {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/marketQuotations/productDetails' + `?gid=${gid}`
				});
				// console.log(gid, "携带");
			},
			async searchButton1() {
				if(this.keyword.length<4){
					// uni.$u.toast('Keywords must not be less than 3');
					return
				}
				if (this.keyword == '') {
					uni.$u.toast('Search term cannot be empty. Please search again');
					return
				} else {
					
					let list = await this.$http.post('api/product/list', {
						key: this.keyword,
						page: 1,
						limit: 9999999,
					})
					this.searchList = list.data.data
				
				}
			
			},
			//搜索
			async searchButton() {
				if(this.keyword.length<3){
					uni.$u.toast('Keywords must not be less than 3');
					return
				}
				if (this.keyword == '') {
					uni.$u.toast('Search term cannot be empty. Please search again');
					return
				} else {
					uni.showLoading({
						title: "Search...",
						mask: true, // 显示透明蒙层，防止触摸穿透
					});
					let list = await this.$http.post('api/product/list', {
						key: this.keyword,
						page: 1,
						limit: 9999999,
					})
					this.searchList = list.data.data
					console.log(8888,list.data.data)
					uni.hideLoading();
					if(list.data.data.length>0){
						if(this.keywords.indexOf(this.keyword)<0){
							this.keywords.push(this.keyword);
							uni.setStorageSync("keywords",this.keywords)
						}
					}
					
				}

			},
		
		}
	}
</script>

<style lang="scss">
	.page {
		padding: 50px 0 0;
	}

	.page {
		background: #fff;
		min-height: 100vh;
	}

	view,
	uni-text {
		box-sizing: border-box;
	}
	/deep/.u-search__action--active{
		width: 50px;
	}
	.header {
	    height: 55px;
	    background: #fff;
	    box-shadow: 0px 1px 4px 0px rgba(0,0,0,.1);
	    padding: 0 16px;
	    width: 100vw;
	    position: fixed;
	    top: 0;
	    left: 0;
	    z-index: 999;
	
		
		.header-left {
			width: 9px;
			height: 16px;
		}

		.header-center {
			font-size: 16px;
			font-weight: 700;
			color: #333;
			text-align: center;
		}

		.header-right {
			width: 9px;
			height: 16px;
		}
	}

	.search-box {
		height: 38px;
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
		-webkit-box-align: center;
		-webkit-align-items: center;
		align-items: center;
		margin: 15px 15px 0;
	}

	.keyword-block {
		padding: 15px;

		.keyword-list-header {
			font-size: 16px;
			font-weight: 500;
			color: #eb3b3b;
		}

		.keyword {
			display: -webkit-box;
			display: -webkit-flex;
			display: flex;
			-webkit-flex-flow: wrap;
			flex-flow: wrap;
			-webkit-box-align: center;
			-webkit-align-items: center;
			align-items: center;

			view {
				margin: 15px 10px 0 0;
				height: 34px;
				background: rgba(235,51,59,.04);
				border-radius: 3px;
				display: -webkit-box;
				display: -webkit-flex;
				display: flex;
				-webkit-box-align: center;
				-webkit-align-items: center;
				align-items: center;
				-webkit-box-pack: center;
				-webkit-justify-content: center;
				justify-content: center;
				padding: 0 10px;
				font-size: 14px;
				font-family: PingFangSC-Regular, PingFang SC;
				font-weight: 400;
				color: #eb3b3b;
			}
		}
	}

	.nodata {
		padding: 100px 0;
	}

	.no-img {
		width: 164px;
		height: 122px;
		background: url(/static/none.png) no-repeat 50%/100%;
		margin: 0 auto 20px;
	}

	.box .top {
		padding: 10px;

		view {
			color: #91a2b1;
		}
	}

	.box .box-item {
		padding: 10px;

		.list-name-txt {
			font-weight: 700;
			color: #333;

			span {
				background: #f0f3fa;
				border-radius: 5px;
				padding: 2px 5px;
				margin-left: 5px;
				font-size: 12px;
				font-weight: 400;
				color: #333;
			}
		}

		.per {
			font-weight: 700;
			border-radius: 10px;
			padding: 5px;
		}

		.per.bg-red {
			background: #f7e7e7;
			color: #FF0000;
		}

		.red {
			font-weight: 700;
			color: #FF0000;

		}

		.per.bg-green {
			background: #e7f1f9;
			color: #228B22;
		}

		.green {
			font-weight: 700;
			color: #228B22;
		}

	}
	.txt{
		color: #333;
		text-align: center;
	}
</style>