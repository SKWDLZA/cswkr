<template>
	<view>
		<EmptyData v-if="list.length<=0"></EmptyData>
		<block v-for="(item,index) in list" :key="index">
			<view class="line common_block" style="margin:0 10px 20px 10px;padding:10px;">
				<view style="display: flex;align-items: center;">
					<view style="flex:30%;" :style="{color:$util.THEME.TIP}">출금</view>
					<view :style="{color:$util.THEME.PRIMARY}" style="flex:40%;font-size: 18px;font-weight: 700;">
						{{$util.formatNumber(item.money)}}
					</view>
					<view style="flex:20%;text-align: center;" :style="{color:$util.THEME.RISE}">
						{{item.desc_type}}
					</view>
				</view>

				<view style="display: flex;align-items: center;">
					<view style="flex:30%;" :style="{color:$util.THEME.TIP}">주문 번호:</view>
					<view style="flex:70%;" :style="{color:$util.THEME.TEXT}">
						{{item.order_sn}}
					</view>
				</view>
				<view style="display: flex;align-items: center;">
					<view style="flex:30%;" :style="{color:$util.THEME.TIP}">날짜 시간:</view>
					<view style="flex:70%;" :style="{color:$util.THEME.TEXT}">
						{{item.created_at}}
					</view>
				</view>
				<view style="display: flex;align-items: center;">
					<view style="flex:30%;" :style="{color:$util.THEME.TIP}">거부 이유:</view>
					<view style="flex:70%;" :style="{color:$util.THEME.TEXT}">
						{{item.reason}}
					</view>
				</view>
				<view style="display: flex;align-items: center;">
					<view style="flex:3%;">
						<image :src="item.icon" :style="$util.calcImageSize(12)"></image>
					</view>
					<view style="flex:97%;" :style="{color:item.color}">{{item.text}}</view>
				</view>
				<view style="display: flex;align-items: center;">
					<u-button text="취소" type="error" @click="handleCancel(item.id)" v-if="item.status==0"></u-button>
				</view>
			</view>
		</block>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: "LogWithdraw",
		components: {
			EmptyData,
		},
		data() {
			return {
				list: [],
			};
		},
		mounted() {
			this.getList()
		},
		methods: {
			handleCancel(id){
				let _this = this;
				uni.showModal({
					title: "정말로 인출을 취소하시겠습니까?",
					cancelText: "취소",
					confirmText: "확인",
					success: function(res) {
						if (res.confirm) {
							_this.qx_post(id);
						} else if (res.cancel) {
							console.log('사용자가 취소를 클릭합니다.');
						}
					}
				})
			},
			async qx_post(id) {
				uni.showLoading({
					title: '처리',
				})
				const result = await this.$http.post(this.$http.API_URL.APP_QX, {
					id: id
				});
				if (result.data.code == 0) {
					uni.$u.toast(result.data.message);
					uni.hideLoading()
					this.getList()
				} else {
					uni.$u.toast(result.data.message);
					uni.hideLoading()
				}
			},
			async getList() {
				uni.showLoading({
					title: this.$lang.LOADING,
				})
				const result = await this.$http.get(this.$http.API_URL.USER_WITHDRAW, {})
				if (result.data.code == 0) {
					this.list=result.data.data
					uni.hideLoading()
				} else {
					uni.$u.toast(result.data.message);
					uni.hideLoading()
				}
			},
		}
	}
</script>

<style>

</style>