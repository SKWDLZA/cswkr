<template>
	<view class="common_header flex">

		<view class="flex-4 flex" @click="$u.route({url:'/pages/search'});">
			<u--input shape="circle" suffixIconStyle="font-size: 24px;color: #fff;margin-right:10px"
				suffixIcon="/static/sousuo.png" type="number" maxlength="11" border="none" :disabled="true"
				customStyle="background: #fff;height:60rpx;width:70%;margin-left: auto;"></u--input>
		</view>
		<view class="primary_header_right flex flex-2">

			<image class="flex-1" mode="aspectFit" src="/static/service.png" :style="$util.calcImageSize(20)"
				@click="linkService()" style="padding-left: 6px;"></image>
			<image class="flex-1" mode="aspectFit" src="/static/sign_out.png" :style="$util.calcImageSize(20)"
				@click="handleSignOut()" style="padding-left: 6px;"></image>
		</view>
	</view>
</template>

<script>
	export default {
		name: "Header",
		data() {
			return {};
		},
		methods: {
			linkService() {
				uni.navigateTo({
					url: this.$util.PAGE_URL.SERVICE
				})
			},

			handleSignOut() {
				this.$http.post(this.$http.API_URL.SIGN_OUT, );
				try {
					let version = uni.getStorageSync('version')
					uni.removeStorageSync('token');
					uni.setStorageSync('version', version)
				} catch (e) {
					// error
				}
				uni.$u.toast('성공적으로 종료');
				setTimeout(() => {
					uni.navigateTo({
						url: this.$util.PAGE_URL.ACCOUNT_SIGNIN
					});
					// 登录成功之后强制刷新页面
					this.$router.go(0)
				}, 500)
			}
		}
	}
</script>