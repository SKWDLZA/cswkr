<template>
	<view class="page">
		<view class="home"
			style="padding: 30px 10px 10px 20px;background: linear-gradient(to bottom, rgba(147, 156, 238, 1.0), rgba(189, 193, 238, 0));">
			<view class="flex flex-b">

				<view class="flex-1 flex " style="color: #000;font-size: 38rpx;">
					개인 센터
				</view>
				<view class="flex-1 flex justify-end margin-right-10"
					@click="$u.route({url:'/pages/searchFor/searchFor'});">
					<image src="../../static/sousuo.png" mode="widthFix" style="width: 20px;"></image>
				</view>

			</view>
			<view style="padding: 10px;margin-top: 20px;">

				<view class="flex">
					<u-avatar size='80' :src="userInformation.avatar" default-url="/static/logo.png"
						shape="circle"></u-avatar>
					<view class="margin-left-10">
						<view class="bold font-size-20">
							{{userInformation.real_name}}
						</view>
						<view class="text-center margin-bottom-10 margin-top-10" style="color: #999999;">
							{{userInformation.p_mobile}}
						</view>
					</view>

				</view>
			</view>


			<view style="border-radius: 10px;margin-bottom: 10px;margin-top: 20px;color: #fff;" class="my_bg">
				<view class="flex  flex-b ">
					<view class="padding-10">
						<view class="flex">
							총자산
							<u-image src="/static/my/biyan.png" style="margin-left: 5px;" width="20px" height="auto"
								mode="widthFix" @click="yan_show=false" v-if="yan_show"></u-image>

							<u-image src="/static/my/zhengyan.png" style="margin-left: 5px;" width="20px" height="auto"
								mode="widthFix" @click="yan_show=true" v-if="!yan_show"></u-image>
						</view>

						<view class="margin-top-10 bold font-size-16" v-if="yan_show">
							{{userInformation.totalZichan}}
						</view>
						<view class="margin-top-10 bold font-size-16" v-if="!yan_show">
							****
						</view>
					</view>
					<view class="padding-10 margin-right-10">
						<view class="flex  justify-end">
							가용 자금
						</view>

						<view class="margin-top-10 bold font-size-16" v-if="yan_show">
							{{userInformation.money}}
						</view>
						<view class="margin-top-10 bold font-size-16" v-if="!yan_show">
							****
						</view>
					</view>
				</view>

				<view class="padding-10 flex flex-b"
					style="background-color: #dee5fe;border-radius: 0 0 10px 10px;color: #2E67F6"
					@click="$u.route({url:'/pages/my/components/aiBank/aiBank'});">
					<view class="flex align-center">
						AI 계정
					</view>

					<view class="bold font-size-16 margin-right-10" v-if="yan_show">
						{{userInformation.aiMoney}}
					</view>
					<view class="bold font-size-16 margin-right-10" v-if="!yan_show">
						****
					</view>
				</view>
			</view>
		</view>

		<view class="padding-20">
			<view class="bold">
				더 많은 기능
			</view>
			<view class="margin-top-10">
			
				<u-cell-group :border="false">
			
					<u-cell title="로그인 비밀번호 변경" :isLink="true" titleStyle="margin-left:20px;" :border="false"
						@tap="changePassword()">
						<u-icon slot="icon" size="20" name="/static/my/yaoshi.png" :bold="true"></u-icon>
					</u-cell>
			
			
					<u-cell title="결제 비밀번호 변경" :isLink="true" titleStyle="margin-left:20px;" :border="false" style="margin-top: 5px;"
						@tap="fundPassword()">
						<u-icon slot="icon" size="20" name="/static/my/suo.png" :bold="true"></u-icon>
					</u-cell>
			
					<u-cell title="연계은행 계좌" :isLink="true" titleStyle="margin-left:20px;" @tap="manages()" :border="false" style="margin-top: 5px;">
						<u-icon slot="icon" size="20" name="/static/my/ka.png" :bold="true"></u-icon>
					</u-cell>
			
			
					<u-cell title="입출금 내역" :isLink="true" titleStyle="margin-left:20px;" :border="false" style="margin-top: 5px;"
						@tap="capitalDetails()">
						<u-icon slot="icon" size="20" name="/static/my/jilu.png" :bold="true"></u-icon>
					</u-cell>
			
					<u-cell title="회사 소개" :isLink="true" titleStyle="margin-left:20px;" @tap="aboutUs()" :border="false" style="margin-top: 5px;">
						<u-icon slot="icon" size="20" name="/static/my/about.png" :bold="true"></u-icon>
					</u-cell>
			
			
				</u-cell-group>
			</view>
		</view>
		
		
		<!-- <view style="width: 90%;background-color: #4f61f5;margin-left: 5%;height: 40px;line-height: 40px;border-radius: 6px;text-align: center;color: #fff;margin-top: 20px;margin-bottom: 100px;" @click="clear">로그인 종료</view> -->
			<view style="padding: 0 20px;">
				<view style="background-color: #2E67F6;height: 30px;line-height: 30px;" class="padding-10 radius30 color-white bold flex-1 text-center"
					@click="silver()">
					입금신청
				</view>
				<view style="color: #FF533B;margin-top: 10px;"
					class="flex-1 radius10 padding-10 text-center" @click="clear">
					로그아웃
				</view>
			</view>
	</view>
</template>

<script>
	// import annular from "./components/annular/annular.vue"
	export default {

		data() {
			return {
				//是否更新
				// updateFlag: false,
				// //每次版本更新都要修改
				// version: '2.1',
				// popupshow: true,
				downloadUrl: '',
				updateDesc: "",
				update: '',
				closeOnClickOverlay: false,
				//手机号
				tel: '',
				userInformation: {},
				is_check: '',
				cardManagement: '',
				item: '',
				yan_show: true
			}
		},
		onShow() {
			this.phoneNumShow()
		},
		//下拉刷新
		onPullDownRefresh() {
			uni.showLoading({
				title: '로드 중',
			});
			//关闭加载提示
			setTimeout(() => {
				uni.hideLoading();
			}, 1000);
			this.gaint_info()
			uni.stopPullDownRefresh()
		},

		methods: {
			clear() {
				this.$http.post('api/app/logout', )
				//清理缓存
				try {
					let version = uni.getStorageSync('version')
					uni.clearStorageSync();
					uni.setStorageSync('version', version)
				} catch (e) {
					// error
				}
				uni.$u.toast('성공적으로 종료');
				setTimeout(() => {
					uni.navigateTo({
						url: '/pages/logon/logon/logon'
					});
					// 登录成功之后强制刷新页面
					this.$router.go(0)
				}, 500)

			},
			link(type, url) {
				if (type == 1) {
					uni.switchTab({
						url: url
					})
				} else if (type == 3) {
					uni.reLaunch({
						url: url
					})
				} else {
					uni.navigateTo({
						url: url
					})
				}
			},
			//客服
			customer() {
				uni.navigateTo({
					url: '/pages/index/components/customer/customer'
				});
			},
			//隐藏手机号
			phoneNumShow() {
				let that = this;
				let number = this.tel; //获取到手机号码字段
				let mphone = number.substring(0, 3) + '****' + number.substring(7);
				that.tel = mphone
			},
			setAiBank() {
				uni.navigateTo({
					url: '/pages/my/components/aiBank/aiBank'
				})
			},
			// 跳转到设置
			setUp(mobile, avatar) {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的设置
					url: '/pages/my/components/setUp/setUp'
					// url: '/pages/my/components/setUp/setUp' + `?mobile=${mobile}&avatar=${avatar}`
				});

			},
			// 银转证
			silver() {
				uni.navigateTo({
					url: "/pages/index/components/customer/customer"
				})
				// if (bank_card_info && idno !== null) {

				// uni.navigateTo({
				// 	url: '/pages/index/components/customer/customer'
				// });

				// } else if (bank_card_info == null) {
				// 	uni.$u.toast('은행 카드에 묶여 있지 않음');
				// 	setTimeout(() => {
				// 		uni.navigateTo({
				// 			//保留当前页面，跳转到应用内的某个页面
				// 			url: '/pages/my/components/bankCard/renewal'
				// 		});
				// 	}, 2000)
				// } else if (idno == null) {
				// 	uni.$u.toast('실명인증 불가');
				// 	setTimeout(() => {
				// 		uni.navigateTo({
				// 			//保留当前页面，跳转到应用内的某个页面
				// 			url: '/pages/index/components/openAccount/openAccount'
				// 		});
				// 	}, 2000)
				// }

			},
			// 실시간 이체
			prove(money) {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/my/components/certificateBank/prove' + `?money=${money}`
				});
			},
			//修改密码
			changePassword() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/my/components/commonFunctions/changePassword'
				});
			},
			//펀드 비밀번호
			fundPassword() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/my/components/commonFunctions/fundPassword'
				});
			},
			//资金流水
			capitalDetails() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/my/components/commonFunctions/capitalDetails?index=0'
				});
			},
			// 卡管理
			manage(bank_name, bank_sub_name, card_sn) {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/my/components/bankCard/binding' +
						`?bank_name=${bank_name}&bank_sub_name=${bank_sub_name}&card_sn=${card_sn}`
				});
				// console.log(bank_name, '22222');
			},
			manages() {
				if (this.cardManagement) {
					uni.navigateTo({
						url: '/pages/my/components/bankCard/binding'
					});
				} else {
					uni.navigateTo({
						//保留当前页面，跳转到应用内的某个页面
						url: '/pages/my/components/bankCard/renewal'
					});
				}

			},
			//版本更新
			Update() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/my/components/other/versionUpdate'
				});
			},
			//用户协议
			userAgreement() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/my/components/other/userAgreement'
				});
			},
			//隐私协议
			privacyAgreement() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/my/components/other/privacyAgreement'
				});
			},

			//关于我们
			aboutUs() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/my/components/other/aboutUs'
				});
			},
			//实名认证
			notCertified() {
				console.log('?');
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/marketQuotations/authentication'
				});
			},


			//用户信息
			async gaint_info() {
				let list = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				})
				const _fmtTotal = list.data.data.totalZichan.toString().length < 3 ? list.data.data.totalZichan : list
					.data.data.totalZichan.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
				const _fmtMoney = list.data.data.money.toString().length < 3 ? list.data.data.money : list.data.data
					.money.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
				this.userInformation = {
					...list.data.data,
					totalZichan: _fmtTotal,
					money: _fmtMoney
				}
				this.cardManagement = list.data.data.bank_card_info
			},

			//版本更新
			is_token() {
				let token = uni.getStorageSync('token') || '';
			},


		},

		onShow() {
			this.gaint_info()
			this.is_token()
		},

	}
</script>

<style lang="scss">
	page {
		background-color: #f3f4f8;
	}

	.my_bg {
		background-image: url(/static/new/my_bg.png);
		background-size: cover;
		background-position: center;
		background-repeat: no-repeat;
	}
</style>