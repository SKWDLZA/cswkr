<!-- 펀드 비밀번호 -->
<template>
	<view>
		<view class="college-bg">
			<image src="@/static/zuojiantou.png" mode="" @tap="home()"></image>
			<view class="college-text">Fund password</view>
			<view class=""></view>
		</view>
		<view class="college-content">
			<view class="cipher">
				<input placeholder="Please enter a new password" type="password" v-model="value2"></input>
			</view>
			<view class="cipher">
				<input placeholder="Please confirm your new password" type="password" v-model="value3"></input>
			</view>
		</view>

		<view class="purchase" @click="transactionPassword()">
			Confirm
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {

				value2: "",
				value3: "",
			};
		},
		methods: {
			home() {
				uni.switchTab({
					url: '/pages/my/my'
				});
			},
			//修改交易密码
			async transactionPassword() {
				let list = await this.$http.post('api/user/updatePayPassword', {

					newpass: this.value2,
					confirmpass: this.value3,
				})
				if (list.data.code == 0) {
					uni.$u.toast('It is changed');
					setTimeout(() => {
						uni.switchTab({
							url: '/pages/my/my'
						});
					}, 1000)
				} else {
					uni.$u.toast(list.data.message);
				}
			},
		}
	}
</script>

<style lang="scss">
	.college-bg {
		padding: 60rpx 30rpx 0;
		height: 100rpx;
		// background-image: url("../../../../static/my/zijimima.png");
		background-image: linear-gradient(to right, #1a73e8, #014b8d);
		background-repeat: no-repeat;
		background-size: 100% 100%;
		display: flex;
		justify-content: space-between;
		// align-items: center;
		text-align: center;

		image {
			width: 20rpx;
			height: 40rpx;
		}

		.college-text {

			color: #fff;
			font-weight: 800;
			font-size: 36rpx;
		}

	}

	.college-content {
		margin-top: -30rpx;
		border-radius: 30rpx 30rpx 0 0;
		background: #fff;
		padding: 30rpx;

		.cipher {
			padding: 20rpx;
			margin: 30rpx 0;
			background: #f5f5f5;
			border-radius: 10rpx;

		}

	}

	/deep/.uni-input-placeholder {
		color: #C0C4CC;
		font-size: 28rpx;
	}

	.purchase {
		background-image: linear-gradient(to right, #1a73e8, #014b8d);
		margin: 60rpx 30rpx;
		border-radius: 10rpx;
		padding: 20rpx 0;
		text-align: center;
		color: #fff;
		font-weight: 600;
	}
</style>
