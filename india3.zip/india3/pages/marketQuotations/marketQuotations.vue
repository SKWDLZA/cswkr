<template>
	<view  class="page">
		<view >
			<view class="flex flex-b header">
				<view class="icon"></view>
				<view class="title">Info</view>
				<view class="icon ss" @click="$u.route({url:'/pages/searchFor/searchFor'});"></view>
			</view>
		</view>
		
		<!-- <u-tabs :list="tablist" lineColor="#014bab"  activeStyle="color:#014bab;font-size:18px;font-weight: 700;"  inactiveStyle="font-size:18px;font-weight: 700;" @change="change" :current="current"></u-tabs> -->
		
		<TabOne v-if="current==0"></TabOne>
<!-- 		<TabTwo v-if="current==1"></TabTwo>
		<TabThree v-if="current==2"></TabThree>
		<TabFour v-if="current==3"></TabFour> -->
	</view>
</template>

<script>
	// import applyPurchase from "../../../../components/new-shares/applyPurchase.vue";
	import  TabOne   from '@/components/market/TabOne.vue'
	// import  TabTwo   from '@/components/market/TabTwo.vue'
	// import  TabThree   from '@/components/market/TabThree.vue'
	// import  TabFour   from '@/components/market/TabFour.vue'
	export default {
		components: {
			TabOne,
			// TabTwo,
			// TabThree,
			// TabFour
		},
		data() {
			return {
				tablist: [{
					name: '시장요약'
				}, {
					name: '특징종목'
				}, {
					name: '시장지표'
				}, {
					name: '시장이슈'
				}],
				current:0
			}
		},
		onShow() {},
	
		
		methods: {
			change(index) {
				console.log(index)
				this.current = index.index;
			},
		},

		mounted() {},
		
		onLoad(op) {
			if(op.type){
				this.current=op.type
			}
		},
		onUnload() {
			clearInterval(this.timerId);
		},
		onHide() {
			clearInterval(this.timerId);
		},
	}
</script>

<style lang="scss">
	
	.page{
	    min-height: 100vh;
	    background-color: #fff;
	    padding: 60px 0 70px;
	}
	view, text {
	    box-sizing: border-box;
	}
	.charts{
		width: 100%;
		height: 200px;
	}
	.header{
	    height: 55px;
	    background: linear-gradient(148deg,#ffeed4,#aaaaff);
	    box-shadow: 0px 1px 4px 0px rgba(0,0,0,.1);
	    padding: 0 16px;
	    width: 100vw;
	    position: fixed;
	    top: 0;
	    left: 0;
	    z-index: 999;
		.title{
		    font-size: 16px;
		    font-weight: 700;
		    color: #333;
		}
	}
	
	

	.flex.flex-b {
	    -webkit-box-pack: justify;
	    -webkit-justify-content: space-between;
	    justify-content: space-between;
	}
	.flex {
	    display: -webkit-box;
	    display: -webkit-flex;
	    display: flex;
	    -webkit-box-align: center;
	    -webkit-align-items: center;
	    align-items: center;
	}
	
	.line-box{
	    padding: 0 5px;
		.top{
		    padding: 16px 10px;
			.t {
			    font-size: 19px;
			    font-weight: 700;
			    color: #333;
			}
			.t1{
			    font-size: 12px;
			    color: #999;
			}
		}
	}
	.pdd {
	    padding: 0 5px;
	}
	.nav-boxs{
	    height: 32px;
	    line-height: 32px;
		.nav-items{
		    font-size: 17px;
			font-weight: 700;
		    color: #999;
		    background: #f1f2f4;
		    border-radius: 5px;
		    padding: 0 10px;
		    margin-right: 10px;
		}
		.active {
		    color: #014b8d;
		    background: #e0e3eb;
		}
		
	}
	.line-box .nums{
	    background: #f0f3fa;
	    border-radius: 10px;
	    padding: 5px;
	    text-align: center;
	    margin: 16px 0;
		.nums-item{
		    width: 32%;
		    background: #fff;
		    border-radius: 8px;
		    padding: 16px 0;
			.name {
			    color: #014b8d;
			}
			.icon{
			    margin: 5px auto;
			}
			
			.t {
			    font-size: 17px;
			    font-family: Roboto;
			    font-weight: 700;
			    color: #ff3636;
			}
			.t.die{
				color: #014b8d;
			}
			.t1 {
			    font-size: 17px;
			    font-family: Roboto;
			    font-weight: 400;
			    color: #ff3636;
			}
			.t1.die{
			    color: #014b8d;
			}
			
		}
	}
	.line-box .last{
	    padding: 10px;
		view{
		    font-size: 12px;
		    color: #333;
		}
		span{
		    font-size: 12px;
		    color: red;
		    margin-left: 5px;
		}
	}
	.list{
	    padding: 16px 0;
	    // border-top: 5px solid #f5f5f5;
	    border-bottom: 5px solid #f5f5f5;
	    margin-top: 10px;
		.tt {
			font-size: 19px;
			font-weight: 700;
			color: #333;
			padding: 0 10px 16px;
			
		}
		.pdd{
		    padding: 0 10px 16px;
		    border-bottom: 1px solid #ccc;
			.item {
			    width: 49%;
				uni-image {
				    width: 100%;
				    height: 117px;
				    border-radius: 5px;
				    margin-bottom: 10px;
				}
			}
			
		}
	
		.items {
		    padding: 16px 10px;
		    border-bottom: 1px solid #ccc;
		}
		.tt {
			font-size: 19px;
			font-weight: 700;
			color: #333;
			padding: 0 10px 16px;
			.t {
			    font-size: 19px;
			    font-weight: 700;
			    color: #333;
			}
			.t1 {
			    font-size: 12px;
			    color: #999;
			}
			.cot .tab {
			    padding: 16px 0 0;
				
				.tab-item {
				    background: #f1f2f4;
				    border-radius: 5px;
				    color: #999;
				    height: 32px;
				    line-height: 32px;
				    text-align: center;
				    min-width: 20%;
				    margin-right: 10px;
				}
				.tab-item.active {
				    background: #e7f1f9;
				    color: #014b8d;
				}
			}
		}
	}
	
	.show{
	    overflow: hidden;
	    text-overflow: ellipsis;
	    display: -webkit-box;
	    -webkit-box-orient: vertical;
	    -webkit-line-clamp: 2;
		font-weight: 500;
	}
	.more{
	    padding: 16px 0;
	    color: #333;
		 .icon {
		    margin-left: 5px;
		}
	}
	.flex.flex-c {
	    -webkit-box-pack: center;
	    -webkit-justify-content: center;
	    justify-content: center;
	}
	.lists{
	    padding: 16px 10px 10px;
		.item {
		    margin-bottom: 16px;
		}
		.t{
		    font-size: 19px;
		    font-weight: 700;
		    color: #333;
		    margin-right: 10px;
		}
		.name{
		    font-size: 14px;
		    font-weight: 600;
		    color: #333;
		    margin-bottom: 5px;
		}
		.code {
		    background: #f0f3fa;
		    border-radius: 5px;
		    padding: 5px 10px;
		    font-size: 12px;
		    font-family: Roboto;
		    font-weight: 400;
		    color: #333;
		}
		.nums{
		    background: #f7e8e8;
		    border-radius: 10px;
		    padding: 5px 10px;
		    -webkit-box-flex: 1;
		    -webkit-flex: 1;
		    flex: 1;
			.t1{
			    font-size: 14px;
			    font-family: Roboto;
			    font-weight: 400;
			    color: #ff3636;
			}
		}
	}
	.tb{
	    height: 32px;
	    background: #f1f2f4;
	    border-radius: 5px;
	    padding: 0 5px;
	    margin-top: 16px;
		.it {
		    -webkit-box-flex: 1;
		    -webkit-flex: 1;
		    flex: 1;
		    text-align: center;
		    height: 26px;
		    border-radius: 3px;
		    color: #014b8d;
		    line-height: 26px;
		}
		.it.active{
		    background: #fff;
		}
	}
	.top1 {
	    border-bottom: 1px solid #ccc;
	    padding: 16px 10px;
		.t {
		    font-size: 19px;
		    font-weight: 700;
		    color: #333;
		}
		.t1{
		    margin-top: 16px;
		}
	}
	.list{
		padding: 16px 10px;
		.item {
		
			margin-bottom: 16px;
			.red {
				font-weight: 600;
				color: #ff3636;
			}
			.red.die{
				color: #014b8d;
			}
		}
	}
	.ct {
	    width: 149px;
		 .bg {
		    background: #e7f1f9;
		    border-radius: 5px;
		    overflow: hidden;
			.b-bg {
			    height: 21px;
			    background: #014b8d;
			}
			.r-bg{
			    height: 21px;
			    background: red;
			}
		}
	}
</style>