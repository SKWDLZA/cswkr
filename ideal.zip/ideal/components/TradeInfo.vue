<!-- 个人交易 交易信息 -->
<template>
	<view class="common_block" style="padding:10px;">
		<view class="flex padding-top-10 padding-bottom-10">
			<view style="border-radius: 0 16rpx 16rpx 0;width: 5px;height: 30px;"></view>
			<view class="margin-left-10 bold font-size-16" :style="{color:$util.THEME.TEXT}">205-01-{{info.uid}}</view>
			<!-- <view class="margin-left-5 hui font-size-10 ">[위탁]{{info.real_name}}</view> -->
			<!-- <view class="left-auto margin-right-10 flex gap5" @click="gp_show=true">
				{{gp_select[0][gp_index]}}
				<u-icon name="arrow-down" :bold="true"></u-icon>
			</view> -->
		</view>
		<view style="display: flex;align-items: center;justify-content: space-between;padding:0 10px 10px 10px;">
			<view style="font-size: 24px;font-weight: 700;" :style="{color:$util.THEME.PRIMARY}">
				{{$util.formatNumber(info.money)}}
			</view>
			<view class="common_btn btn_primary" style="width: 20%;" @click="handleDeposit">{{$lang.DEPOSIT}}</view>
		</view>

		<view style="background-color: #E2F3FF;padding:10px;border-radius:6px;">
			<view style="display: flex;align-items: center;line-height: 1.8;">
				<view style="flex:40%;" :style="{color:$util.THEME.LABEL}">
					{{$lang.TOTAL_BUY_AMOUNT}}
				</view>
				<view style="text-align: right;" :style="{color:$util.THEME.TEXT}">
					{{$util.formatNumber(info.frozen)}}
				</view>
			</view>
			<view style="display: flex;align-items: center;line-height: 1.8;">
				<view style="flex:40%;" :style="{color:$util.THEME.LABEL}">
					{{$lang.VALUATION_GAIN_LOSS}}
				</view>
				<view style="display: inline-block;text-align: right;" :style="{color:$util.THEME.TEXT}">
					{{$util.formatNumber(info.holdYingli)}}
				</view>
			</view>
			<view style="display: flex;align-items: center;line-height: 1.8;">
				<view style="flex:40%;" :style="{color:$util.THEME.LABEL}">
					{{$lang.VALUATION_GAIN_LOSS_AMOUNT}}
				</view>
				<view style="display: inline-block;text-align: right;" :style="{color:$util.THEME.TEXT}">
					{{$util.formatNumber(info.guzhi)}}
				</view>
			</view>
			<view style="display: flex;align-items: center;line-height: 1.8;">
				<view style="flex:40%;" :style="{color:$util.THEME.LABEL}">
					{{$lang.RATE_RESPONSE}}
				</view>
				<view style="display: inline-block;text-align: right;" :style="{color:$util.THEME.TEXT}">
					{{info.huibao}}%
				</view>
			</view>

			<view style="display: flex;align-items: center;line-height: 1.8;">
				<view style="flex:40%;" :style="{color:$util.THEME.LABEL}">
					{{$lang.AMOUNT_TOTAL}}
				</view>
				<view style="display: inline-block;text-align: right;" :style="{color:$util.THEME.TEXT}">
					{{$util.formatNumber(info.totalZichan)}}
				</view>
			</view>
			<view style="display: flex;align-items: center;line-height: 1.8;">
				<view style="flex:40%;" :style="{color:$util.THEME.LABEL}">{{$lang.TOTAL_GAIN}}
				</view>
				<view style="display: inline-block;text-align: right;"
					:style="$util.calcStyleRiseFall(info.totalYingli>0)">
					{{$util.formatNumber(info.totalYingli)}}
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		name: "TradeInfo",
		data() {
			return {
				info: {},
			};
		},
		mounted() {
			this.getUserInfo()
		},
		methods: {
			handleDeposit() {
				uni.navigateTo({
					url: this.$util.PAGE_URL.ACCOUNT_DEPOSIT
				});
			},
			async getUserInfo() {
				uni.showLoading({
					title: this.$lang.LOADING,
				})
				const result = await this.$http.get(this.$http.API_URL.USER_INFO, {})

				if (result.data.code == 0) {
					this.info = result.data.data;
					uni.hideLoading()
				} else {
					uni.$u.toast(result.data.message);
					uni.hideLoading()
				}
			},
		}
	}
</script>