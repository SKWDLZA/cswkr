<!-- 日内交易 -->
<template>
<view >
		<view class="header_wrapper_10">
			<CustomHeader title="단타 급등주" @action="handleBack()"></CustomHeader>
		</view>

		<view class="common_block" style="padding: 10px;margin-top: 20px;">
			<block v-for="(item,index) in btns" :key="index">
				<view @click="handleChangeTab(index)"
					style="display: inline-block; width:max-content;height: 20px;padding:8px 20px;text-align: center;font-size: 16px;"
					:style="$util.calcStyleTabActive(current === index)">
					{{item}}
				</view>
			</block>

			<view style="margin-top: 20px;">
				<template v-if="current==0">
					<view style="padding:20px;">
						<view class="common_input_wrapper"
							style="background-color: rgba(198, 198, 198,0.2);border: 1px solid #C6C6C6;">
							<image mode="aspectFit" src="/static/symbols.png" :style="$util.setImageSize(28)">
							</image>
							<input v-model="amount" type="number" placeholder="금액을 입력하세요"
								:placeholder-style="$util.setPlaceholder()" maxlength="11"></input>
						</view>
					</view>
					<view class="common_btn btn_primary" @click="handleBuy()"
						style="border-radius: 20rpx;text-align: center">
						{{$lang.CONFIRM}}
					</view>

					<view style="margin-top:20px;line-height: 1.5;padding:10px 20px;color:#959393;">
						<view style="padding-bottom: 6px;">가이드:</view>
						<view style="padding-bottom: 6px;">단타 급등주 투자자들이 당일 주식을 매매하고 거래 차익에 따라 정산하는 매매기법입니다.</view>
						<view style="padding-bottom: 6px;">투자자는 주가를 일률적으로 매매하고 정산을 합니다.</view>
						<view style="padding-bottom: 6px;">매수후 이익이 발생하면 "장중거래주"에 바로 표시가되며 매도 및 이익을 선택할수 있습니다.</view>
						<view style="padding-bottom: 6px;">단타 급등주 이익 및 기밀유지를 위해 구매기간 동안 주식코드 및 세부 정보는 제공되지 않습니다.</view>
					</view>
				</template>

				<template v-else-if="current==1">
					<view style="display: flex;align-items: center;padding:10px;" :style="{color:$util.THEME.TITLE}">
						<view style="flex: 40%;">금액</view>
						<view style="flex: 30%;">통과금액</view>
						<view style="flex: 30%;">상태</view>
					</view>
					<view>
						<EmptyData v-if="list && list.length<=0"></EmptyData>
						<block v-for="(item,index) in list" :key="index">
							<view
								style="display: flex;align-items: center;border-bottom:1px solid #e0e0e0;margin-top:10px;padding: 0 6px 10px 6px;">
								<view style="flex: 40%;">
									<image src="/static/kr_symbol.png" mode="aspectFit"
										:style="$util.calcImageSize(26)"></image>
									{{$util.formatNumber(item.money)}}
								</view>
								<view style="flex: 30%;font-size: 16px;" :style="{color:$util.THEME.PRIMARY}">
									<image src="/static/kr_symbol.png" mode="aspectFit" :style="$util.calcImageSize(26)"></image>
									{{$util.formatNumber(item.success)}}
								</view>
								<view style="flex: 30%;font-size: 13px;">{{item.zt}}</view>
							</view>
						</block>
					</view>
				</template>
				<template v-else-if="current==2">
					<EmptyData v-if="list && list.length<=0"></EmptyData>
					<block v-for="(item,index) in list" :key="index">
						<view style="border-top:1px solid #e0e0e0;margin-top:10px;padding:10px 0;">
							<view style="display: flex;align-items: center;">
								<view style="flex:15%;" :style="{color:$util.THEME.TITLE}">금액</view>
								<view style="flex:35%;text-align: right;padding-right: 16px;">
									<image src="/static/kr_symbol.png" mode="aspectFit" :style="$util.calcImageSize(26)"></image>
									{{$util.formatNumber(item.money)}}
								</view>
								<view style="flex:15%;" :style="{color:$util.THEME.TITLE}">유효량</view>
								<view style="flex:35%;font-size: 16px;text-align: right;"
									:style="{color:$util.THEME.PRIMARY}">
									<image src="/static/kr_symbol.png" mode="aspectFit" :style="$util.calcImageSize(26)"></image>
									{{$util.formatNumber(item.success)}}
								</view>
							</view>
							<view style="display: flex;align-items: center;" :style="{color:$util.THEME.TITLE}">
								<view style="flex:30%;">주문 번호</view>
								<view style="flex:70%;font-size: 12px;text-align: right;">{{item.ordersn}}
								</view>
							</view>
							<view style="display: flex;align-items: center;">
								<view style="flex:30%;">날짜 시간</view>
								<view style="flex:70%;font-size: 12px;text-align: right;">
									{{item.created_at}}
								</view>
							</view>
						</view>
					</block>
				</template>
			</view>
		</view>

		<u-modal :show="showBuyConfirm" title="" @cancel="handleBuyCancel" @confirm="handleBuyConfirm()"
			:showCancelButton='true' content='클릭하여 작업을 확인하세요.' cancel-text="취소" confirm-text="확인">
		</u-modal>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	import EmptyData from '@/components/EmptyData.vue';
	import Tbas from '@/components/Tbas.vue';
	export default {
		components: {
			CustomHeader,
			Tbas,
			EmptyData,
		},
		data() {
			return {
				options: {},
				current: 0,
				amount: '',
				list: [],
				showBuyConfirm: false,
				btns: ['단타 급등주', '신청상태', '기록'],
			}
		},
		onLoad(opts) {
			this.options = opts;
		},
		mounted() {},
		onShow() {},
		computed: {
			title() {
				return this.options.tag;
			}
		},
		methods: {
			handleBack() {
				uni.navigateBack({
					delta: 1,
				})
			},
			handleChangeTab(val) {
				this.list = [];
				this.current = val;
				if (this.current == 1) {
					this.getSQList();
				} else if (this.current == 2) {
					this.getOrderList();
				}
			},
			// 购买
			handleBuy() {
				if (this.amount == '') {
					uni.$u.toast('금액을 입력해주세요');
					return false;
				}
				this.showBuyConfirm = true;
			},

			// 购买弹层取消
			handleBuyCancel() {
				this.showBuyConfirm = false;
			},
			// 确认购买
			handleBuyConfirm() {
				this.buy()
				this.showBuyConfirm = false;
			},

			async buy() {
				const result = await this.$http.post('api/rinei/buy', {
					money: this.amount,
				});
				if (result.data.code == 0) {
					uni.$u.toast(result.data.message);
					this.amount = '';
					this.handleChangeTab(1);

				} else {
					uni.$u.toast(result.data.message);
				}
			},

			// 申请列表
			async getSQList() {
				const result = await this.$http.get('api/rinei/sq-list', {});
				if (result.data.code == 0) {
					this.list = result.data.data;
				} else {
					uni.$u.toast(result.data.message);
				}
			},
			// 持仓列表
			async getOrderList() {
				const result = await this.$http.get('api/rinei/order-list', {});
				if (result.data.code == 0) {
					this.list = result.data.data;
				} else {
					uni.$u.toast(result.data.message);
				}
			},
		},
	}
</script>