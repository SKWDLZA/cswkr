<template>
	<view class="page"><!---->
		<view class="topSearch flex">
			<view class="search flex flex-1"  @click="$u.route({url:'/pages/searchFor/searchFor'});">
				<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADgAAAA4CAMAAACfWMssAAAAAXNSR0IArs4c6QAAAcVQTFRFAAAA////qqqqf39/mZmZf3+qkpKSgJmZf5WViYmdkpKSiIiZj4+Ph4eWjo6chpSUjIyZi4uXhZCQioqVhY+ZiYmTjY2ViJCZi4uTh46WioqSioqYho2UiZCWhoyTjIyYiI6Ui4uXiI6Ti4uWh42Xh4yVi4+UiI2Vio6Wio6Wh4uXio6Vio6ViIyWiIuWiY2WiI6UiYyWio2TiI6WiYyVio2ViY6Wio2ViY6WioyUiI2ViY6WiI2UiY6ViI2WioyWiY2UiY6ViI2ViIyViIyVioyUiY2Vio6UiY2ViY2ViIyUiY2ViIyWiY2ViY2Uio2ViI6ViY2ViI2Uio2WiYyVio2ViY6UiY2ViYyUiI2ViYyUiY6Wio2ViY2ViY2ViYyWiY2ViY6ViI2WiY6ViI2Vio2ViY2UioyViY2ViY2ViY2WiIyVio6UiY2ViY2ViY2ViI6ViY2Uio2ViY2ViYyViY6ViY2ViY2ViY6ViY2ViY2WiY2ViY2ViY2ViY6ViY2ViY2ViY2ViY2ViY2ViY2ViY2ViYyViY2ViY2ViI2ViY2ViY2ViY2ViY2ViY2ViY2ViY2ViY2UiY2ViY2ViY2ViY2ViY2VaTGK1QAAAJZ0Uk5TAAEDBAUGBwoMDQ4PEBESExQWFxgZGh0eISIjJSYnKCorLC0uMTU5Oj0/QkZISUtOT1BTWlteX2BhZGVoaWprbW5zdHZ4ent8f4CBgoOEhomQkZKWl5iZnJ6foKKjpKanqKusra6wsbK1t7i7vcDCx8jJys7P0dPU2tvc3d7f4+Xm5+jp6uvs7/Dx8vP09fb3+Pn6/P3+0PklMQAAArNJREFUGBmdwYtfk2UcxuFbk4EG9ZptCWSiRlioQRaUo5R8LM+nRAuKKBMtD6AFGlIzjWpsooPt+/f2e8dp5z0fr0sVNHafGPs1Mb+UejR99WxPs/xs7r+1SKHs5OFAdW05k6bc4qVtqqnhyByVpU82qbr9D1lx/8qpeE/XgUPHL9/NsexJn6o5miWUvTPYpnXR+C8Z8i5uVCWREfKu71Sp2HCW0M0Wlds6SWhiryrZfYPQg3aVikxicl+qmv7nmNlXVWIEk+5VdV2PMbc3qchRzJ97VEtsCjOkQvuzQGqPaosmMHGta3gI5HpVT+czIBlozRHMF6rvIOaCVm2ZAybkYxTItGrFGcxe+dieAUa1bHMauC4/54Fcu/I+BrI75SdIAqeVdwu4I1/DwKxCjYvAoHz1YnbIdGPa5KtxARiQOQHcl79xYERmDLgif8eAezK/Aafkrx/4TyYBxOWvGxORNA+8L3+7MIGkJaBL/l7DxCSlgAPy9xamSdJfwCH5ew94KjMNHJe/D4FZmavAkPx9DkzInAXuyt9PwLcyPUAuKl+RFPCRTHMWiMvXPszrCk0CP8vXV8CU8g4DmZj8tPwLnFNesAh8Iz/ngKVWLbsEZHfLR3QB+E4rtqWBG/JxGch1aNVJTJ/q+wBzTWuangDP31E9HSlgvk3r+jCPY6qt5XdMnwpdxExFVdMPmDEVeekmJtGpGl7G/NOsYi0PMM8OqrqGpxinEm/OEhrdrqo+I+RUIrhNKHM+UDWOkFOJTUPkJYd7G1XglY1a5Qg5lRpIsmxh/Fh/966trZ37Bn98ROJtrXKEnEoFFzJUMK41jpBTmdbvc5S5pnWOkFO59tN/UGymQwUcIadKdgyM3Etiluamv/6kY4OKOEIDqiYSvNG8QZU4zN96AQ6Y0Yv4dG7m3f8BVXiGR2BnPL8AAAAASUVORK5CYII=">
					Find stock code
			</view>
			<uni-image style="height: 20px;"  @click="$u.route({type:'switchTab',url:'/pages/marketQuotations/marketQuotations'});">
				<div
					style="background-image: url(&quot;data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEQAAABSCAMAAADaQoIGAAAAAXNSR0IArs4c6QAAAblQTFRFAAAAAAAAAAAAAFVVQEBAMzMzKioqJCRJIEBAHDk5KipAJzs7JDc3IjNEKzk5JjNAJDE9IDVAJC5AITFCKDBAJy4+JTQ8JDNCIzJAIjA+KC88JzQ7JjNAJTI+JDE9JC87IzRAJzI9JTBAJjA/JjQ9JTM8JDE/IzA+JzQ9JTE+JDE9IzM/JzI+JTQ/JDM+JDI9IzJAJjE/JjQ+JTI8JjM9JjI/JTE9JDE9JDM/JTI/JDE+JDE+JTI+JDM/JDM/JTE/JTM/JTM+JDI9JjE/JjM+JTI/JDM+JjM9JTI+JDI9JjE+JTI9JTE9JTM+JTI+JTI+JTI9JTI/JTE+JDM+JjI9JTI+JTE+JTI/JjI+JTE9JTM/JTI+JTI+JTI+JTI/JTI+JTE+JDI+JjI9JTI+JTI+JTE+JTI9JTI+JDI+JTI+JTI+JTI9JDE+JjI+JTI+JTI+JTI/JTI+JDI+JTI+JTM/JTI+JTI+JTI+JTI+JTM+JTI+JjI9JTI+JTM+JTI+JTI+JjI+JTI+JTI+JTI+JTE+JTI+JTI+JTI+JTI+JTI+JTI+JTI+JTI+JTI+JTI+JTI+JTI+JTI+JTI+k23G1wAAAJJ0Uk5TAAECAwQFBgcICQwNDg8SFBUYHB8gISIjJCUmJygpKissLjA1Njc5Ojs+P0FCRUZHSElKTFBRU1RVYWJjZ2lqbW5vcHJzdnh5e4WHiZaXmZ2en6ChoqSlp6mqq6yusbO0tba3uLm6u7y9wMHDxMXHytDR0tPU1tfa3d7f4OLj5Obn6evs7e/x8/T19vf5+vv8/f7/fmX/AAACl0lEQVRYw+2Y6V/TMBzGw7jGoRNhwlC8T5jbPLCCIpfIzRgeU6aoMAVBAcvAqQwYOmUIsuUv9kV+66euSZssL+nz8vc8+TZtjjZFyExFHasZjDOrHUWocD3EoF4JyI8cZLtwRjXWVF045VuO8V3idu5kCSOrSEBQ86Qai6mTzcgWqEEZCEai0UhwQGkoCFAcmEhgnRKhQLEgwtm3hQ3a6nMKIBxtCUxVos3By2iJYaZiLXyMngNsooMeDkRZEFsoWGbFcH3SxX9HupUrbvfVu90vd3Tljy6Lfixo0cyzm+W64boVzmrWgnlfxrXg23P53vkZzRw3Y/RqO5mPZt/4ybFdejOQUd30wInc4Ge8zDm2ApHpSlak6h1EVlizrh0CnyvZna3KXaid7ldsEDtZa/bY3NsktVFBtfvhGl7zWeCDWD917W8S85XVfHxNcpu0nSEAa6PJCnIG1laA4oWIFbJeXk/YyXViXbeG+Ely3ejUEydVyrHQf5FsvcFpJcZTnh0nTLKtrAF+wAPpJNlHBmOMGLe5XtEkO8bq4kUeyGWSDRuMKWIc54HUkuyUwYAd5ygP5BjJztgQG2JDbMghgETFIdH8elNaHJLOe/c7VVL/W8oDKYfvAvX/A8MoZt0mVe8hPqovKpjeQZbO/oEGulNqXQpq93gPIvehQaouVylZxKz3IlMvoMliCRSGoRAXOMsf+QqNhuHDB7789y+IHPAu7cPh3Y8QQjVJYA66hDQEzZI1CDlmsaRmHagLS6sLxeUhcbQrD9lF8/KQeeRJyjKSHoQaR+Y+SGhupPGw/H85+Xh5LU/LEx4xxuk0bRx2TglBIvTRfC4E+UKHrAlBpumQN2J/+rI0Rvaa2JP1L+3lI/aWfIzwP1V7ePJ7bIXsAAAAAElFTkSuQmCC&quot;); background-size: 100% 100%; background-repeat: no-repeat;">
				</div><img
					src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEQAAABSCAMAAADaQoIGAAAAAXNSR0IArs4c6QAAAblQTFRFAAAAAAAAAAAAAFVVQEBAMzMzKioqJCRJIEBAHDk5KipAJzs7JDc3IjNEKzk5JjNAJDE9IDVAJC5AITFCKDBAJy4+JTQ8JDNCIzJAIjA+KC88JzQ7JjNAJTI+JDE9JC87IzRAJzI9JTBAJjA/JjQ9JTM8JDE/IzA+JzQ9JTE+JDE9IzM/JzI+JTQ/JDM+JDI9IzJAJjE/JjQ+JTI8JjM9JjI/JTE9JDE9JDM/JTI/JDE+JDE+JTI+JDM/JDM/JTE/JTM/JTM+JDI9JjE/JjM+JTI/JDM+JjM9JTI+JDI9JjE+JTI9JTE9JTM+JTI+JTI+JTI9JTI/JTE+JDM+JjI9JTI+JTE+JTI/JjI+JTE9JTM/JTI+JTI+JTI+JTI/JTI+JTE+JDI+JjI9JTI+JTI+JTE+JTI9JTI+JDI+JTI+JTI+JTI9JDE+JjI+JTI+JTI+JTI/JTI+JDI+JTI+JTM/JTI+JTI+JTI+JTI+JTM+JTI+JjI9JTI+JTM+JTI+JTI+JjI+JTI+JTI+JTI+JTE+JTI+JTI+JTI+JTI+JTI+JTI+JTI+JTI+JTI+JTI+JTI+JTI+JTI+JTI+k23G1wAAAJJ0Uk5TAAECAwQFBgcICQwNDg8SFBUYHB8gISIjJCUmJygpKissLjA1Njc5Ojs+P0FCRUZHSElKTFBRU1RVYWJjZ2lqbW5vcHJzdnh5e4WHiZaXmZ2en6ChoqSlp6mqq6yusbO0tba3uLm6u7y9wMHDxMXHytDR0tPU1tfa3d7f4OLj5Obn6evs7e/x8/T19vf5+vv8/f7/fmX/AAACl0lEQVRYw+2Y6V/TMBzGw7jGoRNhwlC8T5jbPLCCIpfIzRgeU6aoMAVBAcvAqQwYOmUIsuUv9kV+66euSZssL+nz8vc8+TZtjjZFyExFHasZjDOrHUWocD3EoF4JyI8cZLtwRjXWVF045VuO8V3idu5kCSOrSEBQ86Qai6mTzcgWqEEZCEai0UhwQGkoCFAcmEhgnRKhQLEgwtm3hQ3a6nMKIBxtCUxVos3By2iJYaZiLXyMngNsooMeDkRZEFsoWGbFcH3SxX9HupUrbvfVu90vd3Tljy6Lfixo0cyzm+W64boVzmrWgnlfxrXg23P53vkZzRw3Y/RqO5mPZt/4ybFdejOQUd30wInc4Ge8zDm2ApHpSlak6h1EVlizrh0CnyvZna3KXaid7ldsEDtZa/bY3NsktVFBtfvhGl7zWeCDWD917W8S85XVfHxNcpu0nSEAa6PJCnIG1laA4oWIFbJeXk/YyXViXbeG+Ely3ejUEydVyrHQf5FsvcFpJcZTnh0nTLKtrAF+wAPpJNlHBmOMGLe5XtEkO8bq4kUeyGWSDRuMKWIc54HUkuyUwYAd5ygP5BjJztgQG2JDbMghgETFIdH8elNaHJLOe/c7VVL/W8oDKYfvAvX/A8MoZt0mVe8hPqovKpjeQZbO/oEGulNqXQpq93gPIvehQaouVylZxKz3IlMvoMliCRSGoRAXOMsf+QqNhuHDB7789y+IHPAu7cPh3Y8QQjVJYA66hDQEzZI1CDlmsaRmHagLS6sLxeUhcbQrD9lF8/KQeeRJyjKSHoQaR+Y+SGhupPGw/H85+Xh5LU/LEx4xxuk0bRx2TglBIvTRfC4E+UKHrAlBpumQN2J/+rI0Rvaa2JP1L+3lI/aWfIzwP1V7ePJ7bIXsAAAAAElFTkSuQmCC"
					draggable="true"><uni-resize-sensor>
					<div>
						<div></div>
					</div>
					<div>
						<div></div>
					</div>
				</uni-resize-sensor>
			</uni-image>
		</view><!---->
		<view class="list flex flex-b">
			<view class="list-item" @click="link(3,'/pages/marketQuotations/marketQuotations')">
				<view class="icon hla"></view>
				<view class="t">AI Smart Trading</view>
			</view>
			<view class="list-item" @click="link(2,'/pages/index/components/fund/fund')">
				<view class="icon gd"></view>
				<view class="t">Intelligent Trading</view>
			</view>
			<view class="list-item" @click="$u.route({url:'/pages/index/components/newShares/newShares'});">
				<view class="icon sg"></view>
				<view class="t">IPO</view>
			</view>
			<view class="list-item" @click="$u.route({url:'/pages/index/bigzong'});">
				<view class="icon hl"></view>
				<view class="t">Bulk Trade</view>
			</view>
			<view class="list-item" @click="$u.route({url:'/pages/index/rinei'});">
				<view class="icon hlg"></view>
				<view class="t">Intraday Trading</view>
			</view>
			<view class="list-item" @click="link(2,'/pages/free/free')">
				<view class="icon zx"></view>
				<view class="t">Watchlist</view>
			</view>
			<!-- <view class="list-item" @click="link(2,'/pages/index/components/fund/fund')">
				<view class="icon gd"></view>
				<view class="t">스마트 거래</view>
			</view> -->
			<!-- <view class="list-item" @click="$u.route({url:'/pages/index/components/newShares/newShares'});">
				<view class="icon sg"></view>
				<view class="t">신규 주식 구매</view>
			</view> -->
			<!-- <view class="list-item" @click="link(3,'/pages/marketQuotations/marketQuotations')">
				<view class="icon hla"></view>
				<view class="t">AI 스마트 거래</view>
			</view> -->
			<!-- <view class="list-item" @click="link(2,'/pages/marketQuotations/authentication')">
				<view class="icon sm"></view>
				<view class="t">본인 인증</view>
			</view> -->
			<view class="list-item" @click="silver(userinfo.money,userinfo.bank_card_info,userinfo.idno)">
				<view class="icon cza"></view>
				<view class="t">Deposit</view>
			</view>
			<!-- <view class="list-item" @click="$u.route({url:'/pages/index/rinei'});">
				<view class="icon hlg"></view>
				<view class="t">일중 거래</view>
			</view> -->
			<view class="list-item" @click="prove(userinfo.money,userinfo.bank_card_info,userinfo.idno)">
				<view class="icon txa"></view>
				<view class="t">Withdraw</view>
			</view>
			<view class="list-item" @click="link(2,'/pages/marketQuotations/authentication')">
				<view class="icon sm"></view>
				<view class="t">KYC</view>
			</view>
			<view class="list-item" @click="link(2,'/pages/my/components/commonFunctions/capitalDetails')">
				<view class="icon jl"></view>
				<!-- <image class="icon" src="/static/jl.png" style="width: 24px;height: 24px;justify-content: center;"></image> -->
				<view class="t">Transaction Records</view>
			</view>
		</view>
		<view class="zhishuList">
			<view class="itemBox flex flex-b">
				<view class="item text-center" :class="item.perchg>0?'red':'green'" v-for="(item,index) in zhishu" v-if="index<3" >
					<view class="name">{{item.indxnm}}</view>
					<view class="price">{{item.ltp}}</view>
					<view>
						<image :src="item.perchg>0?'/static/hong.png':'/static/lv.png'" ></image>
					</view>
					<view class="per">[{{item.perchg}}%]</view>
				</view>
			
				<!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!----><!---->
			</view>
		</view>
		<!-- <view class="banner flex"> -->
			<!-- <view>
				<view class="t">Achieve 50% profit on the same day!</view>
				<view class="t1">Interpretation of popular stocks, market trend answers</view>
			</view>
		</view> -->
		<view class="point-out">
		<view><text>Achieve 50% profit on the same day!</text></view>
		<view><text>Interpretation of popular stocks, market trend answers</text></view>
		</view>
	
		<view class="stockList">
			<u-tabs :list="top_list" @click="click"></u-tabs>
		
			
			<view class="box">
				<view class="top flex flex-b">
					<view class="flex-1">Stock</view>
					<view class="flex-1 t-r">Recency</view>
					<view class="flex-1 t-r">Fluctuation Rate</view>
				</view>
				<view class="box-item flex flex-b" v-for="(item,index) in top2"  @click="$u.route('/pages/marketQuotations/productDetails',{code:item.co_code,type:current2*1+1});">
					<view class="list-name flex-1">
						<view class="list-name-txt ">{{item.co_name}}<view class="txt">{{item.co_code}}</view>
						</view>
					</view>
					<view class="flex-1 t-r num-font " :class="item.per_chg>0?'red':'green'">{{item.current_price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</view>
					<view class="per flex-1 t-r " :class="item.per_chg>0?'red':'green'">{{item.per_chg}}%</view>
				</view>
			</view><!---->
		</view><!----><!----><!---->
	
	</view>
</template>

<script>
	import {
		TYPES
	} from '../../consts/index.js'
	export default {

		data() {
			return {
				userinfo: [],
				show_money: true,
				page: 1,
				list: [],
				top_list:[{
                    name: 'NSE Top',
                }, {
                    name: 'BSE Top',
                }],
				current2:0,
				top2:'',
				top1:'',
				zhishu:""
			}
		},

		methods: {
			click(item) {
			    console.log('item', item);
				this.current2=item.index
				this.good_list()
			},
			getshi(item){
				let close=item.close.replace(",","");
				let zf=item.rate*0.01*close;
				let fh=''
				if(zf>0){
					fh="+";
				}
				
				return fh+zf.toFixed(2);
			},
			link(type, url) {
				if (type == 1) {
					uni.switchTab({
						url: url
					})
				} else if (type == 3) {
					uni.reLaunch({
						url: url
					})
				} else {
					uni.navigateTo({
						url: url
					})
				}
			},
			async top_one() {
				// uni.showLoading({
			
				// })
				let suiji=Math.floor(Math.random() * 3);
				console.log(suiji);

				
				let list = await this.$http.post('api/goods/top1', {
					current1: suiji
			
				})
			
				this.top1 = list.data.data.top1
				this.article = list.data.data.article
				this.bottom = list.data.data.bottom
			
				this.$forceUpdate()
			},
			// 银转证
			silver(money, bank_card_info, idno) {
				if (bank_card_info && idno !== null) {
					uni.navigateTo({
						//保留当前页面，跳转到应用内的某个页面
						url: '/pages/my/components/certificateBank/silver' + `?money=${money}`
					});
				}
				 else if (idno == null) {
					uni.$u.toast('No authentication');
					setTimeout(() => {
						uni.navigateTo({
							//保留当前页面，跳转到应用内的某个页面
							url: '/pages/marketQuotations/authentication'
						});
					}, 2000)
				}
				 else if (bank_card_info == null) {
					uni.$u.toast('Unlinked Bank Card');
					setTimeout(() => {
						uni.navigateTo({
							//保留当前页面，跳转到应用内的某个页面
							url: '/pages/my/components/bankCard/renewal'
						});
					}, 2000)
				}

			},
			prove(money, bank_card_info, idno) {
				if (bank_card_info && idno !== null) {
					uni.navigateTo({
						//保留当前页面，跳转到应用内的某个页面
						url: '/pages/my/components/certificateBank/prove' + `?money=${money}`
					});
				}
				else if (idno == null) {
					uni.$u.toast('No authentication');
					setTimeout(() => {
						uni.navigateTo({
							//保留当前页面，跳转到应用内的某个页面
							url: '/pages/marketQuotations/authentication'
						});
					}, 2000)
				}
				else if (bank_card_info == null) {
					uni.$u.toast('Unlinked Bank Card');
					setTimeout(() => {
						uni.navigateTo({
							//保留当前页面，跳转到应用内的某个页面
							url: '/pages/my/components/bankCard/renewal'
						});
					}, 2000)
				}
			
			},
			/* 数字金额逢三加， 比如 123,464.23 */
			numberToCurrency(value) {
				if (!value) return '0'
				// 将数值截取，保留两位小数
				value = value.toFixed(2)
				// 获取整数部分
				const intPart = Math.trunc(value)
				// 整数部分处理，增加,
				const intPartFormat = intPart.toString().replace(/(\d)(?=(?:\d{3})+$)/g, '$1,')

				return intPartFormat
			},
			//定时器
			startTimer() {
				const storedTimerId = uni.getStorageSync('timerId');
				if (storedTimerId) {
					clearInterval(storedTimerId);
				}
				this.timerId = setInterval(() => {
					this.good_list()
					this.top_one()
				}, 3000);
				uni.setStorageSync('timerId', this.timerId);
				// 在这里立即执行一次请求
			},

			async zhishu_list() {
				let list = await this.$http.post('api/goods/zhishu', {
					
				})
				console.log(list);
				this.zhishu=list.data.data
			
			},	
			async good_list1() {
				let list = await this.$http.post('api/goods/top3', {
					current: 0,
					limit:50
				})
				this.top2 = list.data.data
				uni.hideLoading()
			
			},	
			async good_list() {
				let list = await this.$http.post('api/goods/top2', {
					current: this.current2,
					limit:50
				})
				this.top2 = list.data.data
				uni.hideLoading()
			},
			//用户信息
			async gaint_info() {
				let list = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				})
				this.userinfo = list.data.data
			},
			is_token() {
				let token = uni.getStorageSync('token') || '';
				if (!token) {
					try {
						uni.clearStorageSync();
					} catch (e) {
						// error
					}
					uni.showLoading({
						title: 'Please log in first',
						duration: 1000,
					})
					setTimeout(() => {
						uni.navigateTo({
							url: '/pages/logon/logon/logon'
						});
					}, 1000)
				} else {

				}
			},


		},
		
		onUnload() {
			clearInterval(this.timerId);
		},
		onHide() {
			clearInterval(this.timerId);
		},
		async onShow() {
			this.page = 1;
			this.is_token()
			this.gaint_info()
			this.good_list()
			this.zhishu_list()
		},
		

	}
</script>

<style lang="scss">
	.page {
		min-height: 100vh;
		background-color: #fff;
		padding: 50px 0 70px;
		overflow-x: hidden;
	}
	.topSearch {
	    height: 50px;
	    width: 100%;
	    background: -webkit-linear-gradient(302deg,#ffeed4,#ffe0bb);
	    background: linear-gradient(148deg,#ffeed4,#aaaaff);
	    position: fixed;
	    top: 0;
	    left: 0;
	    z-index: 500;
		.search{
		    height: 31px;
		    border-radius: 15px;
		    background: hsla(0,0%,100%,.5);
		    display: -webkit-box;
		    display: -webkit-flex;
		    display: flex;
		    -webkit-box-align: center;
		    -webkit-align-items: center;
		    align-items: center;
		    padding: 0 10px;
		    margin: 0 15px;
		    font-size: 12px;
		    font-family: PingFangSC-Regular,PingFang SC;
		    font-weight: 400;
		    color: #999;
			img {
			    width: 14px;
			    height: 14px;
			    margin-right: 10px;
			}
		}
		uni-image {
		    width: 17px;
		    margin-right: 15px;
		}
	}
	.list {
	    width: 100%;
	    padding: 10px 0 20px 0;
	    margin-bottom: 20px;
	    -webkit-flex-wrap: wrap;
	    flex-wrap: wrap;
	    font-size: 12px;
	    font-weight: 400;
	    position: relative;
		.list-item{
		    width: 20%;
		    margin: 10px 0;
		    -webkit-align-self: flex-start;
		    align-self: flex-start;
		    position: relative;
		    z-index: 200;
			.icon {
			    margin: 0 auto 10px;
			}
			.t {
			    color: #5c6772;
			    text-align: center;
			}
		}
	}
	.list::after {
	    content: "";
	    width: 140%;
	    height: 100%;
	    position: absolute;
	    left: -20%;
	    top: 0;
	    border-radius: 0 0 50% 50%;
	    background: -webkit-linear-gradient(302deg,#ffeed4,#ffe0bb);
	    background: linear-gradient(148deg,#ffeed4,#aaaaff);
	}
	.zhishuList {
	    background: #fff;
	    border-radius: 0px 0px 18px 18px;
	    padding: 15px;
	    padding-top: 0;
	    margin-bottom: 15px;
		.item {
		    width: 32%;
		    border-radius: 10px;
		    padding-bottom: 10px;
			
			
			.name {
			    padding: 10px 0 5px 0;
			    font-size: 13px;
			    color: #333;
			}
			.price {
			    font-size: 16px;
			    font-weight: 600;
			}
			uni-image {
			    width: 100px;
			    height: 26px;
			}
			.per {
			    font-size: 10px;
			}
		}
		
	}
	.item.green {
	    background:  #d8efff;
	    color: #1677ff;
	}
	.item.red{
	    background: linear-gradient(180deg,rgba(253,67,49,.06),rgba(255,120,95,.06));
	    color: #fd4331;
	}
	.banner {
	    height: 100px;
	    background: url(/static/chuanggai/banner.png) no-repeat 50%/100%;
	    margin: 0 10px 10px;
	}
	.banner {
	    padding: 0 10px;
		.t {
		    font-size: 16px;
		    font-weight: 700;
		    background: -webkit-linear-gradient(left,#965c2e,#d59358 54%,#bb7e44);
		    background: linear-gradient(90deg,#965c2e,#d59358 54%,#bb7e44);
		    -webkit-background-clip: text;
		    -webkit-text-fill-color: transparent;
		}
		.t1 {
		    font-size: 13px;
		    font-weight: 400;
		    color: #c59573;
		    margin-top: 5px;
		}
	}
	.stockList{
	    background: #fff;
	    border-radius: 18px 18px 0px 0px;
	    margin-top: 15px;
	}
	.point-out {
		margin: 40rpx;
		color: #666;
		font-size: 28rpx;
	
		text {
			color: #cb1a1e;
			font-size: 35rpx;
		}
		text {
			color: #cb1a1e;
			font-size: 25rpx;
		}
		}
	.box {
		.top {
		    padding: 10px 15px;
			uni-view {
			    color: #91a2b1;
			}
		}
		.box-item {
		    padding: 10px 0;
		    margin: 0 15px;
		    border-bottom: 1px solid #f1f1f1;
		    font-size: 19px;
			.list-name-txt {
			    font-size: 17px;
			    color: #333;
				.txt{
				    font-size: 12px;
				    color: #5f6671;
				}
			}
			.red {
			    font-family: Roboto;
			    font-weight: 700;
			    color: #008000;
			}
			.per {
			    font-weight: 700;
			    padding: 5px 0;
			}
			
		}
	}
	
</style>