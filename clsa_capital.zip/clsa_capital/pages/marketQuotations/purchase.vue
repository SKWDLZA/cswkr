<!-- 下单 -->
<template>
	<view>
		<CustomHeader :title="detailedData.name" @action="home()"></CustomHeader>
		<view class="common_block" style="padding:20px 10px;">
			<view class="text-center">
				<view style="padding: 5px;width: 26%;margin-left: 37%;" :style="{color:$util.THEME.TEXT}">
					현재 잔액</view>
				<view class="margin-top-10 font-size-20 bold" :style="{color:$util.THEME.SECONDARY}">
					{{$util.formatNumber(userinfo.money)}}
				</view>
			</view>
		</view>
		<view class="common_block" style=";margin-top: 20px;padding:20px 10px;" v-if="detailedData">
			<view class="flex padding-bottom-10">
				<view style="margin-left: 10px;" :style="{color:$util.THEME.TEXT}">{{detailedData.name}}</view>

				<view class="text-right flex-1 bold margin-right-20">
					<view :style="{color:$util.THEME.TEXT}">
						{{$util.formatNumber(detailedData.current_price)}}
					</view>
					<view :style="$util.calcStyleRiseFall(detailedData.rate>0)">{{detailedData.rate}}%</view>
				</view>
			</view>

			<view class="margin-top-20 bold" :style="{color:$util.THEME.LABEL}">
				수량
			</view>
			<view class="margin-top-10 text-center">
				<u-row justify="space-between" gutter="10">
					<u-col span="4">
						<view :class="quantity==50?'actity':'noactity'" @click="quantity=50;quantity1=''">50</view>
					</u-col>
					<u-col span="4">
						<view :class="quantity==100?'actity':'noactity'" @click="quantity=100;quantity1=''">100
						</view>
					</u-col>
					<u-col span="4">
						<view :class="quantity==150?'actity':'noactity'" @click="quantity=150;quantity1=''">150
						</view>
					</u-col>
				</u-row>
				<u-row justify="space-between" gutter="10">
					<u-col span="4">
						<view :class="quantity==200?'actity':'noactity'" @click="quantity=200;quantity1=''">200
						</view>
					</u-col>
					<u-col span="4">
						<view :class="quantity==250?'actity':'noactity'" @click="quantity=250;quantity1=''">250
						</view>
					</u-col>
					<u-col span="4">
						<view :class="quantity==300?'actity':'noactity'" @click="quantity=300;quantity1=''">300
						</view>
					</u-col>
				</u-row>
			</view>
			
			<view class="common_input_wrapper">
				<image mode="aspectFit" src="/static/money.png" :style="$util.calcImageSize(20)">
				</image>
				<input v-model="quantity1" type="number" placeholder="수량을 입력해주세요" maxlength="11"  @input="sl_input"></input>
			</view>
			
			<!-- <input placeholder="수량을 입력해주세요" type="number" class="common_input_wrapper" v-model="quantity1" @input="sl_input" /> -->

			<view class="margin-top-20 bold" :style="{color:$util.THEME.LABEL}">
				레버리지를 선택하세요
			</view>
			<view class="margin-top-10 text-center">
				<u-grid :border="false" col="3">
					<u-grid-item v-for="(item,index) in userinfo.ganggan">
						<view style="width: 90%;" :class="ganggan==item?'actity':'noactity'" @click="ganggan=item">
							{{item}}
						</view>
					</u-grid-item>
				</u-grid>


			</view>
			<view class="flex" style="font-size: 28rpx;" :style="{color:$util.THEME.TEXT}">
				<view class="flex-1">결제 금액</view>
				<view class="flex-2 text-right"><text
						v-if="detailedData.project_type_id==2">$</text>{{detailedData.current_price*this.quantity/this.ganggan|addZero}}
				</view>
			</view>
			<view class="flex" style="font-size: 28rpx;" :style="{color:$util.THEME.TEXT}">
				<view class="flex-1">수수료</view>
				<view class="flex-2 text-right"><text
						v-if="detailedData.project_type_id==2">$</text>{{detailedData.current_price*this.quantity/this.ganggan*0.0015|addZero}}
				</view>
			</view>
		</view>


		<u-picker :show="show" :columns="columns" @cancel="show = false" @confirm="confirm" cancelText="취소"
			confirmText="확신하는"></u-picker>

		<view class="common_btn" style="margin: 20px;" @click="placeOrder()">
			주문
		</view>

	</view>
	</view>
</template>

<script>
	var flag = false;
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components: {
			CustomHeader,
		},
		data() {
			return {
				flag: 0,
				rise: "rise",
				fall: "fall",
				title: "1",
				show: false,
				columns: [
					// ["1", "5", "10", "20"]
				],
				list: '',
				quantity: '50',
				detailedData: "",
				quantity1: "",
				ganggan: 1,
				userinfo: ''
			};
		},
		methods: {
			sl_input(e) {
				console.log(e.detail.value);
				this.quantity = e.detail.value
			},
			// 是否选择
			chooseEmer(itype) {
				if (itype === 0) {
					this.flag = 0
				} else {
					this.flag = 1
				}
			},
			confirm(e) {
				this.title = e.value[0]
				this.show = false
				// this.columns = this.detailedData.ganggan
				// console.log(this.title, '99999');
			},
			home() {
				uni.navigateBack({
					delta: 1, //返回层数，2则上上页
				});
			},
			//实名认证
			authentication() {
				uni.navigateTo({
					url: '/pages/index/components/openAccount/openAccount'
				});
			},
			// 产品详情
			async product(code) {

				let list = await this.$http.get('api/product/info', {
					code: code,
				})
				this.list = list
				this.detailedData = list.data.data[0]

			},
			//购买
			placeOrder() {
				if (flag) return;

				let money = (this.detailedData.current_price * this.quantity * 1).toString().replace(
					/\B(?=(\d{3})+(?!\d))/g, ",")
				uni.showModal({
					title: "매수 확인",
					content: this.detailedData.name + ' ' + this.quantity.toString().replace(
						/\B(?=(\d{3})+(?!\d))/g, ",") + "주 결제 금액 " + money + "원",
					cancelText: "취소", // 取消按钮的文字
					confirmText: "확인", // 确认按钮的文字
					showCancel: true, // 是否显示取消按钮，默认为 true
					confirmColor: '#f55850',
					cancelColor: '#39B54A',
					success: (res) => {
						if (res.confirm) {
							console.log('comfirm') //点击确定之后执行的代码
							this.buy()
						} else {
							console.log('cancel') //点击取消之后执行的代码
						}
					}
				})


			},
			buy() {
				flag = true;
				uni.showLoading({

					mask: true, // 显示透明蒙层，防止触摸穿透
				});
				this.$http.post('api/product/purchase', {
					num: this.quantity || 0,
					gid: this.detailedData.gid,
					price: this.detailedData.current_price,
					ganggan: this.ganggan
				}).then(res => {
					flag = false;
					uni.hideLoading();
					if (res.data.code == 0) {
						uni.$u.toast(res.data.data.message);
						setTimeout(() => {
							uni.switchTab({
								url: this.$util.PAGE_URL.ACCOUNT_TRADE,
							});
						}, 1000)
					} else {
						uni.$u.toast(res.data.message);
					}
					setTimeout(() => {
						flag = false;
					}, 2000)
				}).catch(er => {
					setTimeout(() => {
						flag = false;
					}, 2000)
				})
			},
			//实名认证
			async userInfo() {
				let list = await this.$http.get('api/user/info', {})


				this.userinfo = list.data.data
			},
		},
		filters: {
			addZero: function(data) {
				return data.toFixed(0).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")
			}
		},
		mounted() {
			this.userInfo()
		},
		onLoad(option) {
			this.product(option.code)
			// const item = JSON.parse(decodeURIComponent(option.item));
			// this.objData = item;
			// this.columns = [item.ganggan]
			// const productDetails = JSON.parse(decodeURIComponent(option.productDetails));
			// this.detailedData = productDetails
			// this.columns = [productDetails.ganggan]

		}
	}
</script>

<style lang="scss">
	.gp_type {
		position: fixed;
		top: 220rpx;
		background-color: #ed4344;
		color: #fff;
		width: 80rpx;
		padding: 14rpx;
		right: 40rpx;
		text-align: center;
	}

	.purchase {
		width: 90%;
		height: 80rpx;
		// background: url(../../static/anniu.png);
		background-size: 100% 100%;
		border-radius: 20rpx;
		font-weight: 700;
		color: #fff;
		font-size: 40rpx;
		display: -webkit-box;
		display: -ms-flexbox;
		display: flex;
		-webkit-box-align: center;
		-ms-flex-align: center;
		align-items: center;
		-webkit-box-pack: center;
		-ms-flex-pack: center;
		justify-content: center;
		margin: 40rpx 5%;
	}

	.actity {
		background-color: #fffac0;
		color: #3c1f20;
		font-weight: 700;
		height: 80rpx;
		line-height: 80rpx;
		text-align: center;
		margin-bottom: 20rpx;
	}

	.noactity {
		background-color: #fff;
		color: #979898;
		border: 1px solid #f1f5f9;
		height: 80rpx;
		line-height: 80rpx;
		text-align: center;
		margin-bottom: 20rpx;
	}

	.f-dis-input {
		padding: 26rpx 24rpx;
		background: #f6f6f6;
		border-radius: 10rpx;
		color: #262626;
		font-size: 32rpx;
	}

	.yue {
		margin: 10px 20px;
		color: #fff;
		font-size: 56rpx;
		font-weight: 700;
	}
</style>