# ideal


![LOGO](https://github.com/github1413/ideal/raw/main/static/logo.png)