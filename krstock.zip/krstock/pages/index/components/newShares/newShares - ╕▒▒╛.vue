<template>
	<view>
		<!-- 头部选项卡 -->
		<view class="college-bg">
			<view class="account">
				<!-- <image src="../../../../static/zuojiantou.png" mode="" @tap="home()"></image> -->
				<u-icon name="arrow-left" color="#fff" size="20" @tap="home()" class="icon"></u-icon>
				<view class="">
					<u-tabs :list="list" lineWidth="30" lineColor="#fff" :current="current"
						:activeStyle="{color: '#fff',fontWeight: 'bold',transform: 'scale(1.05)'}"
						:inactiveStyle="{color: '#fff',transform: 'scale(1)'}"
						itemStyle="padding-left: 15px; padding-right: 15px; height: 34px;" @click="select">
					</u-tabs>
				</view>
			</view>

			<view class="suo" @tap="searchFor()">
				<image src="../../../../static/sousuo.png" mode=""></image>
			</view>
		</view>

		<!-- 内容 -->
		<view class="">
			<view v-if="current == 0">
				<applyPurchase :newShares_list2='newShares_list2' :newShares_list='newShares_list'></applyPurchase>
			</view>
			<view v-if="current == 1">
				<newShareRaising></newShareRaising>
			</view>
			<view v-if="current == 2">
				<blockTrade></blockTrade>
			</view>
			<!-- 	<view v-if="current == 3">
				<newBondPlacement></newBondPlacement>
			</view> -->
			<view v-if="current == 3">
				<vipScramble></vipScramble>
			</view>
			<!-- 	<view v-if="current == 4">
				<subscriptionBonds></subscriptionBonds>
			</view> -->
		</view>
	</view>

	</view>
</template>

<script>
	import applyPurchase from "../../../../components/new-shares/applyPurchase.vue";
	import newShareRaising from "../../../../components/new-shares/newShareRaising.vue";
	// import subscriptionBonds from "../../../../components/new-shares/subscriptionBonds.vue";
	// import newBondPlacement from "../../../../components/new-shares/newBondPlacement.vue";
	import blockTrade from "../../../../components/new-shares/blockTrade.vue";
	import vipScramble from "../../../../components/new-shares/vipScramble.vue";
	export default {
		components: {
			applyPurchase,
			newShareRaising,
			// subscriptionBonds,
			// newBondPlacement,
			blockTrade,
			vipScramble,

		},
		data() {
			return {
				current: this.current,
				list: [{
						name: '청약 신청'
					}, {
						name: '청약 내역'
					},
					// {
					// 	name: '新债申购',
					// },
					// {
					// 	name: "新债配售",
					// },
					{
						name: '기관 거래 우선가',
					}, {
						name: 'VIP 우대'
					},
				],
				newShares_list: "",
				newShares_list2: "",

			};
		},
		onLoad(option) {

		},
		onLoad(item) {
			this.newShares()
			this.newShares2()
			if (item.index == 0) {
				this.current = 0
				// this.current = item.index;
			}
			if (item.index == 1) {
				this.current = 1
				// this.current = item.index;
			}
			if (item.index == 2) {
				this.current = 2
				// this.current = item.index;
			}
			// if (item.index == 3) {
			// 	this.current = 3
			// 	// this.current = item.index;
			// }
			if (item.index == 3) {
				this.current = 3
			}
			// if (item.index == 4) {
			// 	this.current = 4
			// }

		},
		methods: {
			home() {
				uni.switchTab({
					url: '/pages/index/index'
				});
			},
			searchFor() {
				uni.navigateTo({
					url: '/pages/searchFor/searchFor'
				});
			},
			select(item) {
				this.current = item.index;
			},
			//新股申购
			async newShares() {
				let list = await this.$http.post('api/goods-shengou/calendar', {
					type: 1,
				})
				this.newShares_list = list.data.data
			},
			async newShares2() {
				let list = await this.$http.post('api/goods-shengou/calendar', {
					type: 2,
				})
				this.newShares_list2 = list.data.data
				// console.log(list.data.data, '구독 예정');
			},
		},

	}
</script>

<style lang="scss">
	//公共css 开始
	.display {
		display: flex;
		justify-content: space-between;
		align-items: center;
	}


	.college-bg {
		padding: 60rpx 30rpx 0;
		height: 280rpx;
		background-color: #4f61f5;

		.account {
			display: flex;
			justify-content: flex-start;
			align-items: center;
			text-align: center;

			//去掉选项卡下面的滚动条  (仅pc端会出现)
			/deep/.u-tabs ::-webkit-scrollbar {
				width: 0;
				height: 0;
				color: transparent;
				// display: none;
			}

		}

		.suo {
			background: hsla(0, 0%, 100%, .1);
			border-radius: 10rpx;
			padding: 10rpx 40rpx;
			margin: 40rpx 0 0;

			image {
				width: 40rpx;
				height: 40rpx;
				margin-top: 10rpx;
			}
		}
	}
</style>