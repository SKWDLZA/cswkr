<!-- 실시간 이체 -->
<template style="background: #f0f0f0;">
	<view>
		<view class="college-bg">
			<view class="account">
				<image src="../../../../static/zuojiantou.png" mode="" @tap="home()"></image>
				<view class="college-text">실시간 이체</view>
				<view class=""></view>
			</view>
			<view class="progress"> {{userInformation.money.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}원</view>
			<view class="vacancies">현재 이체 가능한 잔액</view>
		</view>

		<view class="cash-withdrawal">
			<view class="withdrawal">출금금액</view>
			<view class="money">
				<input placeholder="출금 금액 입력" v-model="value1"></input>
				<view class="" @click="whole(userInformation.money)">전액</view>
			</view>
		</view>
		<view class="cash-withdrawal">
			<view class="withdrawal">증권 비밀번호</view>
			<view class="money">
				<input placeholder="비밀번호 6자리 입력" type="password" v-model="value2"></input>
			</view>
		</view>
		<!-- <view class="cash-withdrawal">
			<view class="withdrawal">메시지를 남겨주세요(선택사항)</view>
			<view class="money">
				<input placeholder="请输入" type="text" v-model="value3"></input>
			</view>
		</view> -->
		<view class="purchase" @click="to_withdraw()">
			출금 확인
		</view>

		<view class="point-out">
			<view>1. 현재 보유주식 매도전에는 출금이 불가능합니다.</view>
			<view>2. 출금을 위해서는 실명인증 및 본인 계좌 확인 후 출금 진행이 됩니다.</view>
			<view>3. 출금 거래 가능 시간 : 평일 오전 09시 ~ 오후 18시 (*주말, 대체공휴일 출금 불가)</view>
			<view>4.  각 현금 인출의 최소 금액은 10,000단위 입니다.</view>
			<view>
				5. <text>출금 신청 후, 당일 입금을 원칙으로 하며, 2시간 이내 입금이 완료 됩니다. </text>
			</view>
		</view>



	</view>
</template>

<script>
	export default {
		data() {
			return {
				value1: '',
				value2: '',
				value3: "",
				userInformation: ''
			};
		},
		methods: {
			async to_withdraw() {
				uni.showLoading({
					title: "출금중이니 기다려주세요....",
					mask: true, // 显示透明蒙层，防止触摸穿透
				});
				let list = await this.$http.post('api/app/withdraw', {
					type: 1,
					total: this.value1,
					pay_pass: this.value2,
					remakes: this.value3,
				})
				// console.log(list.data.code, 'code');
				if (list.data.code == 0) {

					uni.$u.toast(list.data.message);
					setTimeout(() => {
						uni.switchTab({
							url: '/pages/my/my'
						});
						uni.hideLoading();
					}, 500)
				} else {
					uni.$u.toast(list.data.message);
				}
			},
			home() {
				uni.switchTab({
					url: '/pages/my/my'
				});
			},
			whole(money) {
				this.value1 = money
				// console.log(this.value1, '123');
			},
			//用户信息
			async gaint_info() {
				let list = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				})
				this.userInformation = list.data.data
			},
			

		},
		onShow() {
			this.gaint_info()
		},
		onLoad(option) {
			
		}
	}
</script>

<style lang="scss">
	.college-bg {
		padding: 60rpx 30rpx 0;
		height: 280rpx;
		background-image: linear-gradient(to right, #1a73e8, #014b8d);

		.account {
			display: flex;
			text-align: center;
			justify-content: space-between;
			align-items: center;

			image {
				width: 20rpx;
				height: 40rpx;

			}

			.college-text {

				color: #fff;
				font-weight: 800;
				font-size: 36rpx;
			}
		}

		.progress {
			text-align: center;
			font-size: 52rpx;
			color: #fff;
			// font-weight: 600;
			margin: 60rpx 0 10rpx;
		}

		.vacancies {
			text-align: center;
			color: #ffffff;
			font-size: 26rpx;
		}
	}

	.cash-withdrawal {
		border-radius: 30rpx 30rpx 0 0;
		margin-top: -30rpx;
		background: #fff;
		padding: 30rpx;
		font-size: 28rpx;

		.withdrawal {
			color: #333;
		}

		.money {
			display: flex;
			justify-content: space-between;
			align-items: center;
			background: #f5f5f5;
			padding: 30rpx;
			margin: 20rpx 0;
			border-radius: 10rpx;

			input {
				font-size: 28rpx;
			}

		}
	}

	.purchase {
		background-image: linear-gradient(to right, #1a73e8, #014b8d);
		margin: 30rpx;
		border-radius: 10rpx;
		padding: 20rpx 0;
		text-align: center;
		color: #fff;
		font-weight: 600;
		font-size: 30rpx;
	}

	.point-out {
		margin: 30rpx;
		color: #666;
		font-size: 28rpx;

		text {
			color: #cb1a1e;
		}
	}
</style>