<!-- 用户基本信息 -->
<template>
	<view class="common_block" style="padding: 6px;display: flex;flex-direction: column;align-items: center;">
		<view style="display: flex;align-items: center;width: 100%;">
			<view style="flex:10%">
				<image style="width: 60px; height: 80px;" mode="aspectFit" src="/static/applogo.png"></image>
			</view>
			<view style="flex:90%;padding-left: 10px;">
				<view style="font-size: 20px;text-align: left;font-weight: 700;color: #333;">
					{{info.real_name}}
				</view>
				<view style="font-size: 12px;text-align: left;font-weight: 700;color: #999;">
					{{info.p_mobile}}
				</view>
			</view>
		</view>
		<view 
			style="width: 90%;background-color: #eef4ff;border: 1px #181945 solid;margin-left: 5%;border-radius: 10px;margin-bottom: 10px;"
			class="flex">
			<view class="padding-10 flex-1">
				<view class="flex align-center">
					総資産
					<u-image src="/static/zhengyan.png"  style="margin-left: 5px;" width="20px" height="auto"
						mode="widthFix" @click="yan_show=false" v-if="yan_show"></u-image>

					<u-image src="/static/biyan.png" style="margin-left: 5px;" width="20px" height="auto"
						mode="widthFix" @click="yan_show=true" v-if="!yan_show"></u-image>
				</view>

				<view class="margin-top-10 bold font-size-16" v-if="yan_show" style="color: #4b5fcc;">
					{{$util.formatNumber(info.totalZichan)}}
				</view>
				<view class="margin-top-10 bold font-size-16" v-if="!yan_show">
					****
				</view>
			</view>
			<view class="padding-10 flex-1">
				<view class="flex align-center">
					利用可能な資金
				</view>

				<view class="margin-top-10 bold font-size-16" v-if="yan_show" style="color: #4b5fcc;">
					{{$util.formatNumber(info.money)}}
				</view>
				<view class="margin-top-10 bold font-size-16" v-if="!yan_show">
					****
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		name: "Profile",
		props: ['info'],
		data() {
			return {
				yan_show: true
			};
		},
	}
</script>

<style>

</style>