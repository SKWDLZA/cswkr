<template>
	<view class="page">
		<view>
			<view class="header flex flex-b" style="background: linear-gradient(148deg,#ffeed4,#aaaaff);">
				<view class="icon jiantou" @click="$u.route({type:'navigateBack'});"></view>
				<view class="header-center flex-1">Profile</view><!---->
			</view>
		</view>
		

		<view class="head" @tap="sculpture()">
			<view class="sculpture">Avatar</view>
			<!-- <image class="picture" src="../../../../static/logo.png" mode=""></image> -->
			<u-avatar size='50' :src="userInformation.avatar" shape="circle"></u-avatar>
		</view>
		<view class="head" >
			<view class="sculpture">Email address</view>
			<view class="">{{userInformation.mobile}}</view>
		</view>
		
		<view class="head" @click="$u.route({url:'/pages/my/components/commonFunctions/changePassword'});">
			<view class="sculpture">Change login password</view>
			<image @click="clear" src="/static/jiantou.png" mode="" style="width: 15px;height: 15px;"></image>
		</view>
		
		<view class="head" @click="$u.route({url:'/pages/my/components/commonFunctions/fundPassword'});">
			<view class="sculpture">Change payment password</view>
			<image @click="clear" src="/static/jiantou.png" mode="" style="width: 15px;height: 15px;"></image>
		</view>
		
		<view class="head">
			<view class="sculpture">Log out</view>
			<image class="withdraw" @click="clear" src="/static/my/tuichu.png" mode=""></image>
		</view>

	</view>
</template>

<script>
	export default {
		data() {
			return {
				userInformation: ""

			};
		},
		methods: {

			//用户信息
			async gaint_info() {
				let list = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				})
				this.userInformation = list.data.data
				// this.cardManagement = list.data.data.bank_card_info
			},
			home() {
				uni.switchTab({
					url: '/pages/my/my'
				});
			},
			sculpture() {
				uni.navigateTo({
					url: '/pages/my/components/setUp/modifyAvatar'
				});
			},
			clear() {
				this.$http.post('api/app/logout', )
				//清理缓存
				try {
					let version = uni.getStorageSync('version')
					// uni.clearStorageSync();
					uni.removeStorageSync('token');
					uni.setStorageSync('version', version)
				} catch (e) {
					// error
				}
				uni.$u.toast('Completed successfully');
				setTimeout(() => {
					uni.navigateTo({
						url: '/pages/logon/logon/logon'
					});
					// 登录成功之后强制刷新页面
					this.$router.go(0)
				}, 500)

			},

		},

		onLoad(option) {
			this.gaint_info()
			this.userInformation = {
				mobile: option.mobile || '',
				avatar: option.avatar || ','
			}
			// console.log(option.avatar, '1111'); //打印出上个页面传递的参数。
		}
	}
</script>

<style lang="scss">
	uni-view, uni-text {
	    box-sizing: border-box;
	}
	.page {
	    padding: 50px 0 0;
	}
	.header{
	    height: 55px;
	    background: #fff;
	    box-shadow: 0px 1px 4px 0px rgba(0,0,0,.1);
	    padding: 0 16px;
	    width: 100vw;
	    position: fixed;
	    top: 0;
	    left: 0;
	    z-index: 999;
	
		.header-left {
		    position: absolute;
		    top: 18px;
		    left: 16px;
		    width: 10px;
		    height: 18px;
		}
		.header-center {
		    font-size: 16px;
		    font-weight: 700;
		    color: #333;
		    text-align: center;
		}
	}
	.college-bg {
		padding: 20rpx;
		height: 80rpx;
		// background-image: linear-gradient(to right, #1a73e8, #014b8d);
		background-color:  #045097;
		display: flex;
		justify-content: space-between;
		align-items: center;
		text-align: center;

		image {
			width: 20rpx;
			height: 40rpx;
		}

		.college-text {

			color: #fff;
			font-weight: 800;
			font-size: 36rpx;
		}
	}

	.head {
		display: flex;
		justify-content: space-between;
		align-items: center;
		padding: 30rpx;
		border-bottom: 2rpx solid #e9e9e9;

		.picture {
			width: 120rpx;
			height: 120rpx;
			border-radius: 50%;
		}

		.withdraw {
			width: 40rpx;
			height: 40rpx
		}
	}
</style>
