<!-- 主页 -->
<template>
	<view :style="$util.setPageBG('bg_head')">
		<Header></Header>
		
		<view>
			<view class="home_bnner" ></view>
			<ButtonGroup :btns="$util.BTNS_CONFIG_HOME"></ButtonGroup>
			<view style="height: 10px;background-color: #ebebeb;"></view>
			<view
				style="padding:4px 20px;display: flex;flex-wrap: nowrap;align-items: center;">
				<!-- <image src="/static/anniu.png" mode="widthFix" style="width: 20px;margin-right: 10px;"></image> -->
				<text style="font-size: 14px;font-weight: 700;" :style="{color:$util.THEME.TIP}">{{ $lang.STOCK_HOT}}</text>
				
			</view>
			<GoodsList ref="goods"></GoodsList>
		</view>
	</view>
</template>

<script>
	import Header from '@/components/Header.vue';
	import ButtonGroup from '@/components/ButtonGroup.vue';
	import EmptyData from '@/components/EmptyData.vue';
	import Favorites from '@/components/Favorites.vue';
	import GoodsList from '@/components/GoodsList.vue';
	export default {
		components: {
			Header,
			ButtonGroup,
			EmptyData,
			Favorites,
			GoodsList,
		},
		data() {
			return {
				timer: null,
				page: 1,
				gp_index: 0,
			}
		},
		onLoad() {
			let token = uni.getStorageSync('token')
			if(!token){
				uni.reLaunch({
					url:"/pages/account/sigin"
				})
			}
		},
		onShow() {
			this.startTimer();
			// if (this.$refs.free) {
			// 	this.$refs.free.getList();
			// 	this.$refs.goods.getList();
			// }
		},
		onHide() {
			clearInterval(this.timer);
		},
	
		// onReachBottom() {
		// 	this.page = this.page + 1;
		// 	this.$refs.goods.getList(this.page);
		// },
		onUnload() {
			uni.$off('onSuccess');
		},
		methods: {
			startTimer() {
				this.timer = setInterval(() => {
					// this.$refs.free.getList();
					this.$refs.goods.getList();
				}, 3000);
			},
			// 银转证
			async silver() {
				uni.navigateTo({
					url: this.$util.PAGE_URL.SERVICE
				});
			},
		},
	}
</script>