<template>
	<view class="">
		<view class="white-background">
			<view class="take-notes">
				<view class="" style="text-align: center;margin: 60rpx 0; font-size: 28rpx;padding-bottom: 60rpx;">
					이 서비스가 필요한 경우 계정 관리자에게 문의하세요.
				</view>
			</view>
		</view>
		<!-- 		<view class="white-background">
			<view class="take-notes">
				<view class="purchase" @tap="applyPurchase()">
					<image src="../../static/erceng/shengou.png" mode=""></image>
					<view class="">공모 내역</view>
				</view>
				<view class="purchase" @tap="luckyNumber()">
					<image src="../../static/erceng/shengou.png" mode=""></image>
					<view class="">
						우승기록
					</view>
				</view>
			</view>
		</view>

		<view class="tab-header">
			<block v-for="(item,index) in items" :key="index">
				<view :class="['tab-content',content== index?'content-selection':'']" @click="content=index">
					{{item}}
				</view>
			</block>
		</view>
		<view class="" v-show="content == 0">
			
			<view style="border-bottom: 0.01rem solid #e0e0e0;">
				<view class="approve treat">
					<view class="subscription">
						<view class="corporation">百甲科技</view>
						<view class="area">
							<view class="shanghai">상하이</view>
							<view class="shanghai-number">SZ</view>
						</view>
					</view>
					<view class="subscription-time">구독 시간<text>2023-03-02</text> </view>
				</view>
				<view class="display">
					<view class="price">
						<view class="">100元/涨</view>
						<view class="text">구독 가격</view>
					</view>
					<view class="price">
						<view class="">64.83</view>
						<view class="text">转股가격</view>
					</view>
				</view>
				<view class="display">
					<view class="price">
						<view class="">62.88</view>
						<view class="text">正股价值</view>
					</view>
					<view class="price">
						<view class="">0.03%</view>
						<view class="text">溢价率</view>
					</view>
					<view class="price">
						<view class="">96.99</view>
						<view class="text">转股价值</view>
					</view>
				</view>
				<view class="display">
					<view class=""></view>
					<view class="subscription-button">
						申购
					</view>
				</view>
			</view>

		</view>
		<view class="" v-show="content == 1">
			
			<view style="border-bottom: 0.01rem solid #e0e0e0;">
				<view class="approve treat">
					<view class="subscription">
						<view class="corporation">百甲科技</view>
						<view class="area">
							<view class="shanghai">상하이</view>
							<view class="shanghai-number">SZ</view>
						</view>
					</view>
					<view class="subscription-time">구독 시간<text>2023-03-02</text> </view>
				</view>
				<view class="display">
					<view class="price per-cent">
						<view class="">100元/涨</view>
						<view class="text">구독 가격</view>
					</view>
					<view class="price per-cent">
						<view class="">64.83</view>
						<view class="text">转股가격</view>
					</view>
					<view class="price per-cent">
						<view class="">0.00</view>
						<view class="text">发行规模(亿元)</view>
					</view>
				</view>
				<view class="display">
					<view class="price per-cent">
						<view class="">62.88</view>
						<view class="text">正股价值</view>
					</view>
					<view class="price per-cent">
						<view class="">0.03%</view>
						<view class="text">溢价率</view>
					</view>
					<view class="price per-cent">
						<view class="">96.99</view>
						<view class="text">转股价值</view>
					</view>
				</view>
			</view>

		</view> -->
	</view>

</template>

<script>
	export default {
		data() {
			return {
				content: 0,
				items: ['구독 가능', '구독 예정']
			};
		},
		methods: {
			applyPurchase() {
				uni.navigateTo({
					url: '/pages/index/components/newShares/applyPurchase/applyPurchase'
				});
			},

			luckyNumber() {
				uni.navigateTo({
					url: '/pages/index/components/newShares/luckyNumber/luckyNumber'
				});
			},
		}
	}
</script>

<style lang="scss">
	//公共css 开始
	.display {
		display: flex;
		justify-content: space-between;
		align-items: center;
	}

	//깊은북쪽상하이
	.area {
		display: flex;
		justify-content: flex-start;
		align-items: center;
	}

	//깊은
	.deep {
		width: 30rpx;
		height: 30rpx;
		background: #f85252;
		border-radius: 0.4rpx;
		text-align: center;
		line-height: 30rpx;
		color: #fff;
		font-size: 24rpx;
		display: inline-block;
	}

	.deep-number {
		display: inline-block;
		padding: 0 0.04rem;
		background: rgba(59, 79, 222, .1);
		border-radius: 10rpx;
		color: #f85252;
		font-size: 24rpx;
		vertical-align: middle;
	}

	//북쪽
	.north {
		width: 30rpx;
		height: 30rpx;
		background: #ea6248;
		border-radius: 0.4rpx;
		text-align: center;
		line-height: 30rpx;
		color: #fff;
		font-size: 24rpx;
		display: inline-block;
	}

	.north-number {
		display: inline-block;
		padding: 0 0.04rem;
		border-radius: 10rpx;
		font-size: 24rpx;
		vertical-align: middle;
		color: #ea6248;
		background: rgba(234, 98, 72, .1);
	}

	//상하이
	.shanghai {
		width: 30rpx;
		height: 30rpx;
		background: #aa3bde;
		border-radius: 0.4rpx;
		text-align: center;
		line-height: 30rpx;
		color: #fff;
		font-size: 24rpx;
		display: inline-block;
	}

	.shanghai-number {
		display: inline-block;
		padding: 0 0.04rem;
		border-radius: 10rpx;
		font-size: 24rpx;
		vertical-align: middle;
		color: #aa3bde;
		background: rgba(170, 59, 222, .1);
	}

	//公共css 结束

	// 新购申购 开始
	.white-background {
		background: #fff;
		margin-top: -50rpx;
		border-radius: 20rpx 20rpx 0 0;

		.take-notes {
			display: flex;
			justify-content: space-around;
			align-items: center;
			text-align: center;
			padding: 60rpx 60rpx 30rpx;

			.purchase {
				image {
					width: 40rpx;
					height: 40rpx;
				}
			}
		}
	}

	.tab-header {
		background-color: #ffe2dc;
		height: 60rpx;
		display: flex;
	}

	.tab-content {
		font-size: 28rpx;
		flex: 1;
		text-align: center;
		color: #999;
		height: 60rpx;
		line-height: 60rpx;
		position: relative;
	}

	.content-selection {
		font-size: 28rpx;
		font-family: PingFang SC;
		font-weight: bold;
		color: #ec4b58;
	}

	.approve {
		padding: 30rpx 30rpx 0;

		.corporation {
			font-size: 30rpx;
			font-weight: 800;
			margin-bottom: 10rpx;
			margin-right: 20rpx;
		}

		.zero {
			display: flex;
			justify-content: space-around;
			align-items: center;
			// background-image: url('../../static/sheng1.png');
			background-size: cover;
			color: #fff;
			margin: 20rpx 0rpx 20rpx 20rpx;
			height: 50rpx;
			width: 220rpx;
			font-size: 24rpx;

		}

		.thousand {
			display: flex;
			justify-content: space-around;
			align-items: center;
			// background-image: url('../../static/shen2.png');
			background-size: cover;
			color: #fff;
			margin: 20rpx 20rpx;
			height: 50rpx;
			width: 220rpx;
			font-size: 24rpx;
		}
	}

	.treat {
		display: flex;
		justify-content: flex-start;
		align-items: center;

		.subscription {
			margin-right: 100rpx;
			display: flex;
		}
	}

	.subscription-time {
		margin: 6rpx 20rpx;
		font-size: 28rpx;

		text {
			color: #f85252;
			margin-left: 10rpx;
		}
	}

	.price {
		margin: 6px 20rpx;
		font-size: 28rpx;

		.text {
			color: #999;
			margin-top: 10rpx;
		}


	}

	.per-cent {
		width: 33%;
		// text-align: right;
	}

	.subscription-button {
		background: #ea3544;
		font-size: 30rpx;
		padding: 20rpx 30rpx;
		color: #fff;
		border-radius: 10rpx;
		text-align: center;
		// float: right;
		margin: 30rpx 20rpx;
	}

	// 新购申购 结束
</style>
